"""Real-browser tests (Playwright + Chromium): setup/login, customer accounts and product ownership, permission switches,
POS sale -> database, everything survives a server restart and shows up in a brand-new browser profile.
    pip install playwright && playwright install chromium
    python3 tests/test_browser.py        (run from the project root; screenshots go to a temp folder)"""
import os, subprocess, time, sys, json, tempfile
from playwright.sync_api import sync_playwright
T = tempfile.mkdtemp(prefix="alix_e2e_"); os.makedirs(T + "/shots")
PORT = 5078; BASE = f"http://127.0.0.1:{PORT}"
ENV = dict(os.environ, ALIX_DB=T + "/a.db", ALIX_BACKUP_DIR=T + "/bk", ALIX_PORT=str(PORT), ALIX_SECRET_KEY="e2e")
R = []; errors = {}; srv = None

def start():
    global srv
    srv = subprocess.Popen([sys.executable, "server.py"], env=ENV, stdout=open(T + "/out.log", "a"), stderr=subprocess.STDOUT); time.sleep(2.5)
def stop(): srv.terminate(); srv.wait()
def check(n, c, x=""):
    R.append(bool(c)); print(("PASS " if c else "FAIL ") + n + (f"   [{x}]" if (x and not c) else ""))
def watch(page, label):
    page.on("pageerror", lambda e: errors.setdefault(label, []).append("JS: " + str(e)[:160]))
    page.on("console", lambda m: errors.setdefault(label, []).append("console: " + m.text[:160]) if m.type == "error" and "Failed to load resource" not in m.text else None)
def answers(page, values):
    q = [str(v) for v in values]
    h = lambda d: d.accept(q.pop(0) if q else "")
    page.on("dialog", h); return h
def server_products(ctx): return ctx.request.get(BASE + "/api/products").json()
def add_product(ctx, page, name, sku, cat, price, stock, low=5):
    h = answers(page, [name, sku, cat, price, stock, low]); page.click("header .primary")
    page.wait_for_selector(f"#productsTable >> text={name}"); page.remove_listener("dialog", h)
    for _ in range(50):                                            # wait until the SERVER has it
        if any(p["name"] == name for p in server_products(ctx)): return
        time.sleep(0.1)
def rows(page): return 0 if page.locator("#productsTable td[colspan]").count() else page.locator("#productsTable tr").count()
def login(browser, user, pw, land):
    c = browser.new_context(viewport={"width": 1280, "height": 800}); p = c.new_page(); watch(p, "login-" + user)
    p.goto(BASE + "/login.html"); p.fill("#loginUsername", user); p.fill("#loginPassword", pw); p.click("#btnLogin"); p.wait_for_url("**/" + land); return c, p
def open_products(p):
    p.goto(BASE + "/products.html"); p.wait_for_load_state("networkidle"); p.wait_for_function("window.ALIX_USER"); time.sleep(0.4)

start()
try:
  with sync_playwright() as pw:
    b = pw.chromium.launch(); ctx = b.new_context(viewport={"width": 1280, "height": 800}); pg = ctx.new_page(); watch(pg, "flow")

    # ---------- first run, login, logout ----------
    pg.goto(BASE + "/"); pg.wait_for_url("**/setup.html"); check("fresh install lands on setup.html", True)
    pg.fill("#fullName", "Shop Owner"); pg.fill("#username", "owner"); pg.fill("#password", "Shop#Owner2026"); pg.fill("#password2", "Shop#Owner2026")
    pg.click("#btnSetup"); pg.wait_for_url("**/index.html"); pg.wait_for_function("document.getElementById('profileName').textContent==='Shop Owner'")
    check("admin dashboard shows the real name and role", pg.inner_text("#profileRole") == "Administrator")
    m = pg.locator(".metrics article h2").all_inner_texts()
    check("dashboard has NO made-up numbers on a fresh install", m == ["KSh 0", "0", "0", "0"], m)
    check("top sellers / recent sales are empty, not sample data", "No sales yet" in pg.inner_text(".top-products") and "No completed transactions" in pg.inner_text("#recentTransactions"))
    check("no sample chart values", "22,000" not in pg.content() and "46,850" not in pg.content())
    pg.click("#logoutBtn"); pg.wait_for_url("**/login.html"); check("logout works", True)
    pg.fill("#loginUsername", "Admin"); pg.fill("#loginPassword", "admin123"); pg.click("#btnLogin"); pg.wait_for_selector("#loginError.show"); check("old Admin/admin123 rejected", True)
    pg.fill("#loginUsername", "owner"); pg.fill("#loginPassword", "Shop#Owner2026"); pg.click("#btnLogin"); pg.wait_for_url("**/index.html")

    # ---------- every page loads without JS errors ----------
    for name in ["index","dashboard","pos","receipt","sales","invoice","products","inventory","customers","suppliers","quotations","expenses","reports","settings","users","account"]:
        q = ctx.new_page(); watch(q, name); q.goto(f"{BASE}/{name}.html"); q.wait_for_load_state("networkidle"); time.sleep(0.3)
        check(f"admin can open {name}.html", q.url.endswith(f"/{name}.html"), q.url); q.close()
    q = ctx.new_page(); q.goto(BASE + "/pos.html"); q.wait_for_load_state("networkidle")
    check("POS starts with no products (nothing hardcoded)", q.locator("#productsGrid [data-product]").count() == 0 and "No products found" in q.inner_text("#productsGrid")); q.close()
    for name, what in (("suppliers", "Metro Electrical"), ("customers", "Kamau"), ("expenses", "KPLC"), ("inventory", "Copper Cable")):
        q = ctx.new_page(); q.goto(f"{BASE}/{name}.html"); q.wait_for_load_state("networkidle"); check(f"{name}.html shows no built-in sample rows", what not in q.content() and what not in q.inner_text("body")); q.close()

    # ---------- admin creates accounts through the Users page ----------
    u = ctx.new_page(); watch(u, "users"); u.goto(BASE + "/users.html"); u.wait_for_load_state("networkidle")
    def add_account(role, full, biz, user, pw_):
        u.select_option("#nRole", role); u.fill("#nFull", full); u.fill("#nBiz", biz); u.fill("#nUser", user); u.fill("#nPass", pw_); u.click("#addBtn")
        u.wait_for_function(f"document.getElementById('rows').innerText.includes('{user}')")
    add_account("customer", "Ann Acme", "Acme Traders", "acme", "Acme#Pass12345")
    add_account("customer", "Ben Beta", "Beta Co", "betaco", "Beta#Pass12345")
    add_account("cashier", "Till One", "", "till1", "Till#One12345")
    add_account("manager", "Mary M", "", "mary", "Mary#Manager1")
    check("admin created 2 customers, a cashier and a manager from the UI", u.locator("#rows tr").count() == 5)
    check("customer rows show the business name", "Acme Traders" in u.inner_text("#rows"))
    u.screenshot(path=T + "/shots/users.png")

    # ---------- admin adds a product (owner = admin) ----------
    ap = ctx.new_page(); watch(ap, "admin-products"); open_products(ap)
    check("admin products page starts empty with a hint", "No products yet" in ap.inner_text("#productsTable"))
    add_product(ctx, ap, "Admin LED Bulb", "LED-1", "Lighting", 280, 10, 3)

    # ---------- customer Acme ----------
    ca, cp = login(b, "acme", "Acme#Pass12345", "products.html"); check("customer login lands on products.html", True)
    open_products(cp)
    check("customer sees no sidebar/other menus, only their links", cp.locator("aside").count() == 0 and cp.locator("#acctLinks").count() == 1)
    check("customer does NOT see the admin's product", "Admin LED Bulb" not in cp.inner_text("body"))
    check("customer sees an empty list with a hint", "Add Product" in cp.inner_text("#productsTable"))
    check("customer has no Owner column", cp.locator("th", has_text="Owner").count() == 0)
    add_product(ca, cp, "Acme Cable", "C1", "Cables", 250, 40); add_product(ca, cp, "Acme Socket", "S1", "Electrical", 850, 12)
    check("customer sees exactly their 2 products", rows(cp) == 2 and "Acme Cable" in cp.inner_text("#productsTable"))
    check("customer can edit their own products", cp.locator("button[data-edit-p]").count() == 2)
    cp.goto(BASE + "/pos.html"); cp.wait_for_url("**/products.html"); check("customer typing /pos.html is sent back to products.html", True)
    cp.goto(BASE + "/index.html"); cp.wait_for_url("**/products.html"); check("customer typing /index.html is sent back to products.html", True)
    open_products(cp)
    h = answers(cp, ["Acme Cable", "C1", "250", "35"]); cp.locator("button[data-edit-p]").first.click(); time.sleep(0.5); cp.remove_listener("dialog", h)
    cp.wait_for_function("document.querySelector('#productsTable').innerText.includes('35')")
    check("customer edits stock; the SERVER has the new value", any(p["name"] == "Acme Cable" and p["stock"] == 35 for p in server_products(ca)) or (time.sleep(0.6) or any(p["name"] == "Acme Cable" and p["stock"] == 35 for p in server_products(ca))))
    cp.screenshot(path=T + "/shots/customer.png")

    # ---------- customer Beta: cannot see Acme's; same SKU is fine ----------
    cb, bp = login(b, "betaco", "Beta#Pass12345", "products.html"); open_products(bp)
    check("second customer sees none of Acme's products", "Acme" not in bp.inner_text("body") and "No products yet" in bp.inner_text("#productsTable"))
    add_product(cb, bp, "Beta Bulb", "C1", "Lighting", 90, 5)
    check("second customer sees only their own", rows(bp) == 1)

    # ---------- admin sees everything, with owners ----------
    open_products(ap)
    check("admin sees all 4 products from 3 accounts", rows(ap) == 4, rows(ap))
    check("admin has an Owner column showing business names", "Acme Traders" in ap.inner_text("#productsTable") and "Beta Co" in ap.inner_text("#productsTable"))
    ap.select_option("select[title='Filter by owner']", label="Acme Traders"); time.sleep(0.3)
    check("admin can filter the list by owner", rows(ap) == 2 and "Beta" not in ap.inner_text("#productsTable"))
    ap.select_option("select[title='Filter by owner']", label="All owners"); ap.screenshot(path=T + "/shots/admin_all.png")

    # ---------- permission switch: cashier see-all on/off from the Users page ----------
    tc, tp = login(b, "till1", "Till#One12345", "index.html"); open_products(tp)
    check("cashier (default permission) sees all 4 products", rows(tp) == 4, rows(tp))
    check("cashier cannot edit others' products (no Edit buttons)", tp.locator("button[data-edit-p]").count() == 0 and "View only" in tp.inner_text("#productsTable"))
    h = answers(tp, ["x"]); tp.click("header .primary"); time.sleep(0.4); tp.remove_listener("dialog", h)
    check("cashier cannot add a product", "cannot add" in tp.inner_text("body"))
    u.reload(); u.wait_for_load_state("networkidle")
    u.locator("#rows tr", has_text="till1").locator("label", has_text="See all products").locator("input").uncheck(); u.wait_for_selector("#msg.ok"); time.sleep(0.4)
    open_products(tp)
    check("admin unticks 'See all products' -> cashier now sees none", "No products" in tp.inner_text("#productsTable"))
    u.reload(); u.wait_for_load_state("networkidle")
    u.locator("#rows tr", has_text="till1").locator("label", has_text="See all products").locator("input").check(); u.wait_for_selector("#msg.ok"); time.sleep(0.4)
    open_products(tp); check("ticking it again restores the list", rows(tp) == 4)
    check("admin row's permission ticks are locked on", u.locator("#rows tr", has_text="owner").locator("input[type=checkbox]").first.is_disabled())

    # ---------- POS: dashboards + sale reduce the SERVER stock, sale is stored in the database ----------
    tp.goto(BASE + "/pos.html"); tp.wait_for_load_state("networkidle"); time.sleep(0.4)
    check("POS grid is filled from the database", tp.locator("#productsGrid > *").count() == 4, tp.locator("#productsGrid > *").count())
    tp.locator("#productsGrid > *", has_text="Admin LED Bulb").first.click(); tp.once("dialog", lambda d: d.accept("280")); tp.click("#checkoutBtn")
    tp.wait_for_selector("text=Receipt Preview")
    info = tp.evaluate("""()=>{const h=[...document.querySelectorAll('h3')].find(e=>e.textContent.trim()==='Receipt Preview');
      let m=h; while(m && !/Official Sales Receipt/.test(m.innerText)) m=m.parentElement;
      return {logos:m.querySelectorAll('img').length, titles:(m.innerText.match(/alix power enterprise/gi)||[]).length}}""")
    check("receipt preview: one logo, one business title", info["logos"] == 1 and info["titles"] == 1, str(info))
    for _ in range(50):
        stock = [p["stock"] for p in server_products(ctx) if p["name"] == "Admin LED Bulb"]
        if stock == [9]: break
        time.sleep(0.1)
    check("sale took 1 off the stock in the database (10 -> 9)", stock == [9], stock)
    for _ in range(50):
        boot = ctx.request.get(BASE + "/api/bootstrap").json()
        if boot["records"]["alixSales"]: break
        time.sleep(0.1)
    check("the sale itself is stored in the database", len(boot["records"]["alixSales"]) == 1 and boot["records"]["alixSales"][0]["invoice"] == "INV-000001", boot["records"]["alixSales"])
    check("invoice counter is stored server-side", boot["kv"].get("alixInvoiceSequence") == "1", boot["kv"])
    tp.screenshot(path=T + "/shots/receipt.png")
    raw = tp.evaluate("Object.keys(localStorage).filter(k=>k.startsWith('alix'))")
    check("the browser keeps no shop data of its own (only the device's cart)", not any(k in raw for k in ("alixProducts","alixSales","alixCustomers")), raw)

    # ---------- manager (edit_all default) ----------
    mc, mp = login(b, "mary", "Mary#Manager1", "index.html"); open_products(mp)
    check("manager sees all and can edit all (4 Edit buttons)", mp.locator("button[data-edit-p]").count() == 4)
    mp.goto(BASE + "/settings.html"); check("manager can open settings.html", mp.url.endswith("/settings.html"))
    mp.goto(BASE + "/users.html"); mp.wait_for_url("**/index.html"); check("manager cannot open users.html", True)

    # ---------- customer profile ----------
    cp.goto(BASE + "/account.html"); cp.wait_for_function("document.getElementById('pBiz').value==='Acme Traders'")
    cp.fill("#pPhone", "0712345678"); cp.click("#pSave"); cp.wait_for_selector("#pmsg.ok")
    check("customer edits their own contact details", True)

    # ---------- everything is in the DATABASE: restart the server, use a brand-new browser profile ----------
    stop(); start()
    nb, np_ = login(b, "owner", "Shop#Owner2026", "index.html"); watch(np_, "after-restart"); open_products(np_)
    check("new browser profile + restarted server: admin still sees all 4 products", rows(np_) == 4, rows(np_))
    check("the sale's stock change survived (Admin LED Bulb = 9)", "9" in np_.locator("#productsTable tr", has_text="Admin LED Bulb").inner_text())
    np_.goto(BASE + "/index.html"); np_.wait_for_load_state("networkidle"); time.sleep(0.4)
    check("dashboard in the new profile shows the sale", "INV-000001" in np_.inner_text("#recentTransactions") and np_.locator(".metrics article h2").first.inner_text() == "KSh 280", np_.locator(".metrics article h2").all_inner_texts())
    r = nb.request.get(BASE + "/api/users").json()
    check("users, business names and phone survived the restart", any(x["username"] == "acme" and x["phone"] == "0712345678" and x["business_name"] == "Acme Traders" for x in r))
    np_.screenshot(path=T + "/shots/dashboard_after.png")
    b.close()
finally:
    stop()

print("\n--- JavaScript errors seen while browsing:")
print(json.dumps(errors, indent=1) if errors else "none")
check("no uncaught JS errors on any page", not errors)
print(f"\n{sum(R)}/{len(R)} passed   (screenshots: {T}/shots)"); sys.exit(0 if all(R) else 1)
