"""Backend tests: setup, login, lock-out, roles, users, backup.  Run from the project root:
    python3 tests/test_backend.py
Uses a temporary database; never touches alix_pos.db."""
import os, sys, tempfile
d = tempfile.mkdtemp()
os.environ.update(ALIX_DB=f"{d}/t.db", ALIX_SECRET_KEY="test-key", ALIX_BACKUP_DIR=f"{d}/bk", ALIX_LOGIN_MAX_FAILS="3")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import server; server.setup()
c = server.app.test_client()
J = dict(content_type="application/json")
res = []
def check(name, cond, extra=""):
    res.append(cond); print(("PASS " if cond else "FAIL ") + name + (f"  [{extra}]" if extra and not cond else ""))

r = c.get("/index.html");                check("no users -> pages redirect to setup", r.status_code==302 and r.location.endswith("/setup.html"), r.status_code)
check("setup page is reachable", c.get("/setup.html").status_code==200)
check("api without login = 401", c.get("/api/products").status_code==401)
check("weak password rejected", c.post("/api/setup", json={"username":"boss","password":"admin123"}).status_code==400)
check("short username rejected", c.post("/api/setup", json={"username":"a","password":"Strong#Pass1"}).status_code==400)
check("first admin created", c.post("/api/setup", json={"username":"boss","password":"Strong#Pass1","full_name":"The Boss"}).status_code==201)
check("setup cannot run twice", c.post("/api/setup", json={"username":"xyz2","password":"Strong#Pass1"}).status_code==409)
check("setup logs the admin in", c.get("/api/me").json["role"]=="admin")
c.post("/api/logout"); 
check("after logout /api/me = 401", c.get("/api/me").status_code==401)
r = c.get("/pos.html");                  check("pages redirect to login when logged out", r.status_code==302 and r.location.endswith("/login.html"))
check("static assets stay public", c.get("/style.css").status_code==200)
check("old default admin/admin123 does NOT work", c.post("/api/login", json={"username":"Admin","password":"admin123"}).status_code==401)
check("form-encoded post refused (CSRF guard)", c.post("/api/login", data={"username":"boss","password":"Strong#Pass1"}).status_code==415)
check("good login works", c.post("/api/login", json={"username":"BOSS","password":"Strong#Pass1"}).status_code==200)   # case-insensitive username
check("admin reaches users.html gate (404 only because page not built yet)", c.get("/users.html").status_code in (200,404))

# user management
check("create manager", c.post("/api/users", json={"username":"mary","password":"Mary#Pass123","role":"manager"}).status_code==201)
check("create cashier", c.post("/api/users", json={"username":"joe","password":"Jo#Pass1234","role":"cashier"}).status_code==201)
check("duplicate username -> 409", c.post("/api/users", json={"username":"JOE","password":"Jo#Pass1234","role":"cashier"}).status_code==409)
check("bad role rejected", c.post("/api/users", json={"username":"zed","password":"Zed#Pass123","role":"god"}).status_code==400)
users = {u["username"]:u for u in c.get("/api/users").json}
check("password hash never returned", all("password" not in u and "password_hash" not in u for u in users.values()))
check("cannot demote the last admin", c.patch(f"/api/users/{users['boss']['id']}", json={"role":"cashier"}).status_code==409)
check("cannot deactivate the last admin", c.patch(f"/api/users/{users['boss']['id']}", json={"active":False}).status_code==409)

# cashier permissions
cj = server.app.test_client()
check("cashier login", cj.post("/api/login", json={"username":"joe","password":"Jo#Pass1234"}).status_code==200)
check("cashier can read products", cj.get("/api/products").status_code==200)
check("cashier cannot add products", cj.post("/api/products", json={"name":"x","sku":"x","category":"x","price":1}).status_code==403)
check("cashier cannot list users", cj.get("/api/users").status_code==403)
check("cashier cannot read expenses", cj.get("/api/expenses").status_code==403)
r = cj.get("/settings.html");            check("cashier redirected away from settings.html", r.status_code==302 and r.location.endswith("/index.html"))
check("cashier can open pos.html", cj.get("/pos.html").status_code==200)
r = cj.get("/users.html");               check("cashier redirected away from users.html", r.status_code==302)

# manager permissions
cm = server.app.test_client(); cm.post("/api/login", json={"username":"mary","password":"Mary#Pass123"})
check("manager can add product", cm.post("/api/products", json={"name":"Bulb","sku":"B1","category":"Lighting","price":100}).status_code==201)
check("manager can open settings.html", cm.get("/settings.html").status_code==200)
check("manager cannot manage users", cm.get("/api/users").status_code==403)

# deactivation takes effect immediately, password change + reset
check("admin deactivates cashier", c.patch(f"/api/users/{users["joe"]['id']}", json={"active":False}).status_code==200)
check("deactivated cashier's live session is dead", cj.get("/api/me").status_code==401)
check("deactivated cashier cannot log in", server.app.test_client().post("/api/login", json={"username":"joe","password":"Jo#Pass1234"}).status_code==401)
check("wrong current password refused", cm.post("/api/me/password", json={"current":"nope","new":"Newer#Pass99"}).status_code==400)
check("password change works", cm.post("/api/me/password", json={"current":"Mary#Pass123","new":"Newer#Pass99"}).status_code==200)
check("old password now fails", server.app.test_client().post("/api/login", json={"username":"mary","password":"Mary#Pass123"}).status_code==401)
check("admin resets a password", c.patch(f"/api/users/{users['mary']['id']}", json={"password":"Reset#Pass77"}).status_code==200)
check("reset password logs in", server.app.test_client().post("/api/login", json={"username":"mary","password":"Reset#Pass77"}).status_code==200)

# brute-force lock-out (limit set to 3 for the test)
b = server.app.test_client(); codes=[b.post("/api/login", json={"username":"mary","password":"wrong"}).status_code for _ in range(4)]
check("lock-out after repeated failures", codes==[401,401,401,429], codes)
check("even the right password is refused while locked", b.post("/api/login", json={"username":"mary","password":"Reset#Pass77"}).status_code==429)

# health + backup
check("health is public", server.app.test_client().get("/api/health").status_code==200)
import backup; p = backup.make_backup(); check("backup file written", p is not None and p.exists() and p.stat().st_size>0)
import sqlite3; check("backup contains the users", sqlite3.connect(p).execute("select count(*) from users").fetchone()[0]==3)
print(f"\n{sum(res)}/{len(res)} passed"); sys.exit(0 if all(res) else 1)
