"""Backend tests: customer accounts, product ownership, permission switches, in-place upgrade of an older database,
shop records + counters.  Run from the project root:   python3 tests/test_products.py
Uses temporary databases only."""
import os, sys, tempfile, sqlite3
d = tempfile.mkdtemp()
os.environ.update(ALIX_DB=f"{d}/new.db", ALIX_SECRET_KEY="test-key", ALIX_BACKUP_DIR=f"{d}/bk")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from werkzeug.security import generate_password_hash
res = []
def check(name, cond, extra=""):
    res.append(bool(cond)); print(("PASS " if cond else "FAIL ") + name + (f"  [{extra}]" if extra and not cond else ""))

# ---------- 1. build a genuine v2-shaped database, then upgrade it in place ----------
old = sqlite3.connect(f"{d}/old.db")
old.executescript("""
CREATE TABLE products(id INTEGER PRIMARY KEY,name TEXT NOT NULL,sku TEXT NOT NULL UNIQUE,category TEXT NOT NULL,price REAL NOT NULL,cost REAL DEFAULT 0,stock INTEGER DEFAULT 0,low_stock_level INTEGER DEFAULT 5,barcode TEXT UNIQUE,active INTEGER DEFAULT 1,created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE sale_items(id INTEGER PRIMARY KEY,sale_id INTEGER,product_id INTEGER REFERENCES products(id),product_name TEXT);
CREATE TABLE users(id INTEGER PRIMARY KEY,username TEXT NOT NULL UNIQUE COLLATE NOCASE,full_name TEXT,password_hash TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'cashier' CHECK(role IN ('admin','manager','cashier')),active INTEGER NOT NULL DEFAULT 1,created_at TEXT DEFAULT CURRENT_TIMESTAMP,last_login TEXT);
""")
old.execute("INSERT INTO users(username,full_name,password_hash,role) VALUES('boss','The Boss',?, 'admin')", (generate_password_hash("Strong#Pass1"),))
old.execute("INSERT INTO users(username,full_name,password_hash,role) VALUES('joe','Joe',?, 'cashier')", (generate_password_hash("Jo#Pass1234"),))
old.execute("INSERT INTO products(name,sku,category,price,stock) VALUES('Old Bulb','OB1','Lighting',100,7)")
old.execute("INSERT INTO sale_items(sale_id,product_id,product_name) VALUES(1,1,'Old Bulb')")
old.commit(); old.close()
os.environ["ALIX_DB"] = f"{d}/old.db"
import config; config.DATABASE = __import__("pathlib").Path(f"{d}/old.db")
import server; server.DATABASE = config.DATABASE; server.setup()
c = server.app.test_client(); J = dict(content_type="application/json")
check("upgrade: old user still logs in with the same password", c.post("/api/login", json={"username":"boss","password":"Strong#Pass1"}).status_code == 200)
me = c.get("/api/me").json
check("upgrade: admin keeps role and gains permission flags", me["role"] == "admin" and me["can_see_all_products"] and me["can_edit_all_products"])
pl = c.get("/api/products").json
check("upgrade: old product kept and now owned by the admin", len(pl) == 1 and pl[0]["name"] == "Old Bulb" and pl[0]["stock"] == 7 and pl[0]["owner_id"] == me["id"], pl)
check("upgrade: sale_items still points at the product", sqlite3.connect(f"{d}/old.db").execute("select count(*) from sale_items where product_id=1").fetchone()[0] == 1)
server.setup()   # running it a second time must be harmless
check("upgrade: setup is idempotent", len(c.get("/api/products").json) == 1)
cj = server.app.test_client(); cj.post("/api/login", json={"username":"joe","password":"Jo#Pass1234"})
check("upgrade: old cashier can see all products (default)", len(cj.get("/api/products").json) == 1)

# ---------- 2. fresh database: nothing hardcoded ----------
os.environ["ALIX_DB"] = f"{d}/new.db"; config.DATABASE = __import__("pathlib").Path(f"{d}/new.db"); server.DATABASE = config.DATABASE
server.setup()
c = server.app.test_client()
check("fresh install has no products and no users", sqlite3.connect(f"{d}/new.db").execute("select (select count(*) from products)+(select count(*) from users)").fetchone()[0] == 0)
check("first admin created", c.post("/api/setup", json={"username":"boss","password":"Strong#Pass1","full_name":"The Boss"}).status_code == 201)
def mk(role, user, pw, **kw): return c.post("/api/users", json=dict(username=user, password=pw, role=role, full_name=user.title(), **kw))
r = mk("customer", "acme", "Acme#Pass123", business_name="Acme Traders", phone="0700111222"); check("admin creates customer Acme", r.status_code == 201 and r.json["business_name"] == "Acme Traders")
check("customer defaults: cannot see/edit all", not r.json["can_see_all_products"] and not r.json["can_edit_all_products"])
check("admin creates customer Beta", mk("customer", "betaco", "Beta#Pass123", business_name="Beta Co").status_code == 201)
check("admin creates cashier + manager", mk("cashier", "till1", "Till#Pass123").status_code == 201 and mk("manager", "mary", "Mary#Pass123").status_code == 201)
def login(u, p):
    x = server.app.test_client(); assert x.post("/api/login", json={"username":u,"password":p}).status_code == 200; return x
ca, cb, ct, cm = login("acme","Acme#Pass123"), login("betaco","Beta#Pass123"), login("till1","Till#Pass123"), login("mary","Mary#Pass123")
P = lambda n, s, **k: dict(name=n, sku=s, category="General", price=100, stock=10, **k)

# ---------- 3. ownership + visibility ----------
check("admin adds a product (owner = admin)", c.post("/api/products", json=P("Admin Bulb","A1")).status_code == 201)
ra = ca.post("/api/products", json=P("Acme Cable","C1")); check("customer adds own product", ra.status_code == 201 and ra.json["can_edit"])
check("customer adds a second one", ca.post("/api/products", json=P("Acme Socket","S1")).status_code == 201)
rb = cb.post("/api/products", json=P("Beta Bulb","C1")); check("another customer may reuse the same SKU", rb.status_code == 201)
check("same SKU twice for one owner -> 409", ca.post("/api/products", json=P("Dup","C1")).status_code == 409)
check("customer sees only their own 2", sorted(p["name"] for p in ca.get("/api/products").json) == ["Acme Cable","Acme Socket"])
check("other customer sees only theirs", [p["name"] for p in cb.get("/api/products").json] == ["Beta Bulb"])
allp = c.get("/api/products").json
check("admin sees all 4 with owner names", len(allp) == 4 and {"Acme Traders","Beta Co"} <= {p["owner_name"] for p in allp}, [p["owner_name"] for p in allp])
check("admin can filter by owner", len(c.get(f"/api/products?owner_id={ra.json['owner_id']}").json) == 2)
check("cashier (default) sees all 4", len(ct.get("/api/products").json) == 4)
check("manager sees all 4", len(cm.get("/api/products").json) == 4)
users = {u["username"]: u for u in c.get("/api/users").json}

# ---------- 4. who may change what ----------
acme_id, beta_id = ra.json["id"], rb.json["id"]
check("customer cannot edit another owner's product (404, invisible)", ca.patch(f"/api/products/{beta_id}", json={"price": 1}).status_code == 404)
check("customer cannot delete another's product", ca.delete(f"/api/products/{beta_id}", json={}).status_code == 404)
check("customer edits own product", ca.patch(f"/api/products/{acme_id}", json={"price": 250}).json["price"] == 250)
check("cashier cannot add products", ct.post("/api/products", json=P("X","X1")).status_code == 403)
check("cashier cannot rename a product", ct.patch(f"/api/products/{acme_id}", json={"name": "hacked"}).status_code == 403)
r = ct.patch(f"/api/products/{acme_id}", json={"stock_delta": -3}); check("cashier can sell (stock_delta -3): 10 -> 7", r.status_code == 200 and r.json["stock"] == 7, r.json)
check("cannot oversell (409, stock unchanged)", ct.patch(f"/api/products/{acme_id}", json={"stock_delta": -99}).status_code == 409 and ca.get("/api/products").json[0]["stock"] in (7,))
check("customer cannot use stock_delta on someone else's (invisible)", cb.patch(f"/api/products/{acme_id}", json={"stock_delta": -1}).status_code == 404)
check("manager can edit any product", cm.patch(f"/api/products/{beta_id}", json={"price": 95}).json["price"] == 95)
check("negative price refused", ca.patch(f"/api/products/{acme_id}", json={"price": -5}).status_code == 400)
check("garbage stock refused", ca.patch(f"/api/products/{acme_id}", json={"stock": "lots"}).status_code == 400)

# ---------- 5. permission switches on the Users page ----------
r = c.patch(f"/api/users/{users['till1']['id']}", json={"can_see_all_products": False}); check("admin unticks 'see all' for the cashier", r.status_code == 200 and not r.json["can_see_all_products"])
check("cashier now sees none (owns nothing)", ct.get("/api/products").json == [])
check("...and cannot reach a product by id", ct.patch(f"/api/products/{acme_id}", json={"stock_delta": -1}).status_code == 404)
c.patch(f"/api/users/{users['till1']['id']}", json={"can_see_all_products": True}); check("ticking it again restores the list", len(ct.get("/api/products").json) == 4)
c.patch(f"/api/users/{users['till1']['id']}", json={"can_edit_all_products": True})
check("admin grants 'edit all' -> cashier can now edit", ct.patch(f"/api/products/{beta_id}", json={"name": "Beta Bulb v2"}).status_code == 200)
r = c.patch(f"/api/users/{users['till1']['id']}", json={"role": "customer"}); check("changing role resets permissions to that role's defaults", not r.json["can_see_all_products"] and not r.json["can_edit_all_products"])
c.patch(f"/api/users/{users['till1']['id']}", json={"role": "cashier"})
r = c.post("/api/products", json=dict(P("For Beta","FB1"), owner_id=beta_id and rb.json["owner_id"])); check("admin can add a product on behalf of a customer", r.status_code == 201 and r.json["owner_name"] == "Beta Co")
check("customer cannot add on behalf of someone else", ca.post("/api/products", json=dict(P("Sneaky","SN1"), owner_id=rb.json["owner_id"])).status_code == 403)
check("removed product disappears and frees its SKU", ca.delete(f"/api/products/{ra.json['id']}", json={}).status_code == 200 and ca.post("/api/products", json=P("Acme Cable 2","C1")).status_code == 201)

# ---------- 6. customers are fenced in ----------
for path in ("/pos.html","/index.html","/settings.html","/users.html","/sales.html"):
    r = ca.get(path); check(f"customer sent away from {path}", r.status_code == 302 and r.location.endswith("/products.html"), (r.status_code, r.location))
check("customer may open products.html and account.html", ca.get("/products.html").status_code == 200 and ca.get("/account.html").status_code == 200)
for path in ("/api/users","/api/customers","/api/expenses","/api/settings","/api/invoices","/api/inventory/movements","/api/records/alixSales","/api/kv"):
    code = (ca.post(path, json={}) if path in ("/api/records/alixSales","/api/kv") else ca.get(path)).status_code
    check(f"customer blocked from {path}", code == 403, code)
bs = ca.get("/api/bootstrap").json
check("customer bootstrap = own user + own products only", bs["user"]["role"] == "customer" and len(bs["products"]) == 2 and bs["records"] == {} and bs["kv"] == {})
check("old server-side sale cannot sell an invisible product", ct.post("/api/sales", json={"items":[{"product_id": beta_id, "quantity":1}]}).status_code in (200, 201, 400))
c.patch(f"/api/users/{users['till1']['id']}", json={"can_see_all_products": False, "can_edit_all_products": False})
check("cashier without 'see all' cannot sell an invisible product via /api/sales", ct.post("/api/sales", json={"items":[{"product_id": beta_id, "quantity":1}]}).status_code == 400)
c.patch(f"/api/users/{users['till1']['id']}", json={"can_see_all_products": True})

# ---------- 7. profile ----------
r = ca.patch("/api/me", json={"phone": "0712345678", "business_name": "Acme Traders Ltd"}); check("customer edits own contact details", r.status_code == 200 and r.json["phone"] == "0712345678")
check("admin sees the new details", {u["username"]: u for u in c.get("/api/users").json}["acme"]["business_name"] == "Acme Traders Ltd")

# ---------- 8. shop records + counters ----------
sale = {"invoice": "INV-000001", "total": 500, "items": []}; sale2 = {"invoice": "INV-000002", "total": 700, "items": []}
check("cashier saves a sale", ct.post("/api/records/alixSales", json={"upserts": [{"rid": "k:INV-000001", "data": sale}]}).status_code == 200)
check("cashier saves a 2nd sale", ct.post("/api/records/alixSales", json={"upserts": [{"rid": "k:INV-000002", "data": sale2}]}).status_code == 200)
b = ct.get("/api/bootstrap").json; check("sales come back newest first", [s["invoice"] for s in b["records"]["alixSales"]] == ["INV-000002", "INV-000001"])
sale["total"] = 550; ct.post("/api/records/alixSales", json={"upserts": [{"rid": "k:INV-000001", "data": sale}]})
b = ct.get("/api/bootstrap").json; check("editing a record keeps its place", [s["total"] for s in b["records"]["alixSales"]] == [700, 550])
ct.post("/api/records/alixSales", json={"deletes": ["k:INV-000002"]}); check("delete works", len(ct.get("/api/bootstrap").json["records"]["alixSales"]) == 1)
check("cashier cannot write expenses (manager only)", ct.post("/api/records/alixExpenses", json={"upserts": [{"rid": "1", "data": {}}]}).status_code == 403)
check("manager can write expenses", cm.post("/api/records/alixExpenses", json={"upserts": [{"rid": "1", "data": {"amount": 5}}]}).status_code == 200)
check("unknown collection refused", ct.post("/api/records/whatever", json={}).status_code == 404)
check("counter goes up", ct.post("/api/kv", json={"key": "alixInvoiceSequence", "value": "5"}).json["value"] == "5")
check("counter never goes back down", ct.post("/api/kv", json={"key": "alixInvoiceSequence", "value": "2"}).json["value"] == "5")
check("cashier cannot change settings", ct.post("/api/kv", json={"key": "alixSettings", "value": "{}"}).status_code == 403)
check("manager saves settings; cashier can read them", cm.post("/api/kv", json={"key": "alixSettings", "value": '{"businessName":"X"}'}).status_code == 200 and ct.get("/api/bootstrap").json["kv"]["alixSettings"] == '{"businessName":"X"}')
check("cashier does not receive manager-only collections", ct.get("/api/bootstrap").json["records"]["alixExpenses"] == [])
check("admin gets them", c.get("/api/bootstrap").json["records"]["alixExpenses"] == [{"amount": 5}])
check("bad record payload -> 400", ct.post("/api/records/alixSales", json={"upserts": [{"nope": 1}]}).status_code == 400)
print(f"\n{sum(res)}/{len(res)} passed"); sys.exit(0 if all(res) else 1)
