# ALIX Power Enterprise — Get Started

This is your copy of the POS, up to date with the shared-database rebuild
(products, customers, sales, everything — no more per-browser data) and your
own license signing tool. Read `STATUS.md` too — it's the running log of
what's been done, what's still open, and what to be careful with.

---

## 1. First install & start

Copy this whole `ALIX.2` folder onto the PC (or phone, via Termux) that will
act as the server, then:

- **Windows:** double-click `start.bat`
- **Mac/Linux:** open a terminal here and run `./start.sh`
- **Termux (Android):** same `./start.sh`, from inside this folder

First run creates a virtual environment and installs `Flask`, `waitress`,
and `cryptography` (~15 MB). Every run after that starts instantly. Leave
the terminal/app open while it's running — closing it stops the server.
`Ctrl+C` stops it cleanly.

**Termux notes:**
- If `pip install cryptography` ever fails to build, use Termux's own
  package instead: `pkg install python-cryptography`.
- Android kills background apps to save battery. Run `termux-wake-lock`
  (needs `pkg install termux-api` + the Termux:API app) before starting the
  server so it isn't killed when you switch apps or lock the screen.
- Find the phone's LAN IP with `ip addr show wlan0` — that's what other
  devices on the same Wi-Fi will use to reach it.

## 2. First login — create the admin

Open **http://127.0.0.1:5000** (or the server's LAN IP — see §4). There's no
default password baked in. You'll land on a setup page and create the first
account, which becomes admin automatically.

## 3. Accounts — two different kinds

**Staff accounts** (`admin` / `manager` / `cashier`) — log into the full
POS: dashboard, sales, inventory, etc. Add these from **Users** (admin only):
- `admin` — everything, including managing users and licensing
- `manager` — everything except managing users
- `cashier` — POS/sales only, can't touch settings

**Customer accounts** (`customer`) — for the businesses you host on your
server. Each one logs in and sees *only* their own products and their own
account page — nothing else, no other menu. When you add one, you also set:
- **See all products** (off by default for customers)
- **Edit all products** (off by default for customers)

Turn those on if a customer should see/edit everyone's stock instead of
just their own. Admin/manager have both on by default; cashiers see all but
can't edit others' by default. Changes apply immediately, no re-login
needed. Every product is tagged with who added it — admin always sees an
**Owner** column with a filter.

## 4. Letting other devices connect (0.0.0.0)

Already the default — no config needed. The server binds `0.0.0.0`, so any
phone, tablet, or PC on the same Wi-Fi/LAN reaches it at
`http://<server's-LAN-IP>:5000`.

**Every device must use the same address consistently** — `127.0.0.1`,
`localhost`, and the LAN IP are different sites for login cookies. Pick the
LAN IP and have every device use that one.

To lock it back to just this one PC, set `ALIX_HOST=127.0.0.1` in a `.env`
file (copy `.env.example` first). There's no HTTPS — keep this on a
private/trusted network only, never port-forward it to the internet.

## 5. Licensing — set up once, then issue/renew as needed

`license_tool.py` is already in this folder. Full walkthrough:

**Setup (once, ever):**
```
python3 license_tool.py genkey
```
Writes `license_private.pem` — **never share it, never commit it, back it
up somewhere safe.** It's the only thing that can sign a license this app
will trust. It also prints a `PUBLIC_KEY_PEM` block — paste that into
`licensing.py`, replacing the existing block near the top, and save.

> The `license.json` already in this folder was signed by a different key
> (from an earlier session) — it'll stop verifying the moment you swap the
> public key. That's expected; issue a fresh one next.

**Issue a license:**
```
python3 license_tool.py issue --customer "Friend's Shop" --days 30
```
Writes `license.json` right there. Options: `--warn 7`, `--grace 3`,
`--message "Pay via M-Pesa to renew"`, `--out somefile.json`.

**Renew:** run `issue` again with a new `--days` count.

**Cut someone off immediately:**
```
python3 license_tool.py suspend --in license.json
```

**Auto-renewal without manual copying:** set `ALIX_LICENSE_URL` in `.env`
to a URL hosting the current `license.json`. The app checks it every few
hours and installs newer signed licenses automatically.

## 6. Testing the POS now

1. Run `start.sh` / `start.bat`, open the address it prints.
2. Go through setup, create your admin account.
3. **Products** → add a couple of real products (or set `ALIX_SEED_DEMO=1`
   in `.env` before first run to get sample data instead).
4. **Users** → add a cashier and try logging in as them on a second
   browser/device — confirm they can sell but not reach Settings.
5. **POS** → ring up a sale, confirm stock drops on the Inventory page.
6. Open the same URL from a second device on the same Wi-Fi to confirm the
   product/sale you just made is visible there too.
7. Check `backups/` after a day (or run `python3 backup.py` manually) to
   confirm backups are being written.

## 7. Day-to-day

- Backups run automatically once a day (`backups/`, keeps 14 by default).
- Products page → Add Product; Inventory page → stock adjustments (logged
  with who did it and why).
- Everything is in the real database now — survives restarts, browser
  changes, and is identical across every device connecting to this server.

---

Read `STATUS.md` for the detailed technical log — what's confirmed working
with test evidence, what's still on localStorage-free but untested on real
hardware, and the open decisions (server-side sale totals, the two data
models) that are worth resolving before this goes live for real money.
