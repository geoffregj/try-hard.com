document.addEventListener("DOMContentLoaded", () => {
  const currency = new Intl.NumberFormat("en-KE", {
    style: "currency",
    currency: "KES",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  });

  const readStorage = (key, fallback) => {
    try {
      const saved = localStorage.getItem(key);
      return saved ? JSON.parse(saved) : fallback;
    } catch {
      return fallback;
    }
  };

  const products = readStorage("alixProducts", []);
  const sales = readStorage("alixSales", []);
  const today = new Date();
  const startOfToday = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  const isSameDay = (date) => new Date(date).toDateString() === today.toDateString();

  // Update the greeting date.
  document.querySelector("header p").textContent = today.toLocaleDateString("en-KE", {
    weekday: "long", year: "numeric", month: "long", day: "numeric"
  });

  // Today's total from the completed sales.
  const todaysTransactions = sales.filter((sale) => sale.createdAt && isSameDay(sale.createdAt));
  const todaysTotal = todaysTransactions.reduce((total, sale) => total + Number(sale.total || 0), 0);
  if (sales.length) document.getElementById("todaysSales").textContent = currency.format(todaysTotal);

  if (products.length) {
    const categories = new Set(products.map((product) => product.category).filter(Boolean));
    const lowStock = products.filter((product) => Number(product.stock) <= Number(product.lowStockLevel || 5));
    document.getElementById("totalProducts").textContent = products.length;
    document.getElementById("categoryCount").textContent = `Across ${categories.size} categories`;
    document.getElementById("lowStockProducts").textContent = lowStock.length;
  }

  // Calculate today versus yesterday where transaction history exists.
  const yesterday = new Date(startOfToday);
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayTotal = sales
    .filter((sale) => sale.createdAt && new Date(sale.createdAt).toDateString() === yesterday.toDateString())
    .reduce((total, sale) => total + Number(sale.total || 0), 0);
  if (sales.length && yesterdayTotal > 0) {
    const percent = ((todaysTotal - yesterdayTotal) / yesterdayTotal) * 100;
    const change = document.getElementById("salesChange");
    change.textContent = `${percent >= 0 ? "↑" : "↓"} ${Math.abs(percent).toFixed(1)}% from yesterday`;
    change.className = percent >= 0 ? "up" : "warn";
  }

  // Seven-day chart from completed sales (all zero until there are sales).
  const week = Array.from({ length: 7 }, (_, index) => {
    const date = new Date(startOfToday);
    date.setDate(date.getDate() - (6 - index));
    return { date, label: date.toLocaleDateString("en-KE", { weekday: "short" }), total: 0 };
  });
  sales.forEach((sale) => {
    if (!sale.createdAt) return;
    const item = week.find((day) => day.date.toDateString() === new Date(sale.createdAt).toDateString());
    if (item) item.total += Number(sale.total || 0);
  });

  const maximum = Math.max(...week.map((day) => day.total), 1);
  document.getElementById("salesChart").innerHTML = `
    <div class="dashboard-bars">
      ${week.map((day) => `<div class="bar-column"><span class="bar-value">${currency.format(day.total)}</span><i style="height:${Math.max(8, (day.total / maximum) * 100)}%"></i><small>${day.label}</small></div>`).join("")}
    </div>`;
});
