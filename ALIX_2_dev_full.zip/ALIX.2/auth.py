"""ALIX login, roles and page/API gating. Server-side — the browser is never trusted.

Roles (low -> high):  customer < cashier < manager < admin
  customer : a business you host; signs in, adds and edits ONLY its own products (Products page + own account)
  cashier  : sell, print receipts/invoices, view products, add customers
  manager  : + change products, settings, expenses, suppliers, inventory, reports
  admin    : + manage users, sees and edits every product
Two per-user switches (Users page) decide product visibility:
  can_see_all_products  - see every owner's products, not just your own
  can_edit_all_products - edit any owner's products
Edit PAGE_MIN_ROLE / API_RULES below to change who can reach what.
"""
import re, time, threading
from datetime import datetime
from flask import g, jsonify, redirect, request, session
from werkzeug.security import check_password_hash, generate_password_hash
import config

RANK = {"customer": 0, "cashier": 1, "manager": 2, "admin": 3}
DEFAULT_PERMS = {"admin": (1, 1), "manager": (1, 1), "cashier": (1, 0), "customer": (0, 0)}   # (see all, edit all)
CUSTOMER_PAGES = {"products.html", "account.html"}
CUSTOMER_API = ("/api/me", "/api/logout", "/api/products", "/api/bootstrap")
USERNAME_RE = re.compile(r"^[A-Za-z0-9_.-]{3,32}$")
MIN_PASSWORD = 8

PUBLIC_PAGES = {"login.html", "setup.html", "license.html"}
PUBLIC_API = {"/api/login", "/api/setup", "/api/auth/status", "/api/health", "/api/license"}
ASSET_SUFFIXES = {".js", ".css", ".jpg", ".png", ".ico"}     # no secrets in these
PAGE_MIN_ROLE = {"users.html": "admin",
                 "settings.html": "manager", "reports.html": "manager", "expenses.html": "manager",
                 "suppliers.html": "manager", "inventory.html": "manager", "sales.html": "manager"}
# (method or "*", path prefix, minimum role) — first match wins, default is cashier
API_RULES = [("*", "/api/users", "admin"),
             ("PUT", "/api/settings", "manager"),
             ("*", "/api/expenses", "manager"),
             ("*", "/api/inventory", "manager")]

_DUMMY_HASH = generate_password_hash("not-a-real-password")   # equalises timing for unknown users
_fails, _fails_lock = {}, threading.Lock()


def _now(): return datetime.now().isoformat(timespec="seconds")


def _client_key(username):
    return (request.remote_addr or "?", (username or "").lower())


def _locked_for(key):
    """Seconds left on a login lock-out for this ip+username (0 = not locked)."""
    with _fails_lock:
        recent = [t for t in _fails.get(key, []) if time.time() - t < config.LOGIN_LOCK_SECONDS]
        _fails[key] = recent
        if len(recent) >= config.LOGIN_MAX_FAILS:
            return int(config.LOGIN_LOCK_SECONDS - (time.time() - recent[0])) + 1
    return 0


def _record_fail(key):
    with _fails_lock:
        _fails.setdefault(key, []).append(time.time())


def _public(u):
    role = u["role"]
    return {"id": u["id"], "username": u["username"], "full_name": u["full_name"] or u["username"],
            "business_name": u["business_name"] or "", "phone": u["phone"] or "", "email": u["email"] or "",
            "role": role, "active": bool(u["active"]), "created_at": u["created_at"], "last_login": u["last_login"],
            "can_see_all_products": role == "admin" or bool(u["can_see_all_products"]),
            "can_edit_all_products": role == "admin" or bool(u["can_edit_all_products"])}


def _text(x, key, limit=120):
    v = x.get(key)
    return None if v is None else str(v).strip()[:limit]


def _password_problem(pw):
    if not isinstance(pw, str) or len(pw) < MIN_PASSWORD:
        return f"Password must be at least {MIN_PASSWORD} characters."
    if pw.lower() in {"password", "admin123", "12345678", "alix2026", "password1"}:
        return "That password is too easy to guess."
    return None


def init(app, db):
    app.secret_key = config.SECRET_KEY
    app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
                      PERMANENT_SESSION_LIFETIME=config.SESSION_HOURS * 3600)

    def count_users():
        con = db()
        n = con.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        con.close()
        return n

    def load_user():
        uid = session.get("uid")
        if not uid:
            return None
        con = db()
        row = con.execute("SELECT * FROM users WHERE id=? AND active=1", (uid,)).fetchone()
        con.close()
        return row                                   # deactivated/deleted users lose access at once

    def need(role):
        u = g.get("user")
        return u is not None and RANK[u["role"]] >= RANK[role]

    @app.before_request
    def gate():
        path = request.path
        g.user = load_user()
        if path.startswith("/api/"):
            if request.method in ("POST", "PUT", "PATCH", "DELETE") and not request.is_json \
                    and path not in ("/api/logout",):
                return jsonify(error="JSON body required"), 415     # blocks cross-site form posts
            if path in PUBLIC_API:
                return None
            if not g.user:
                return jsonify(error="login_required"), 401
            if g.user["role"] == "customer" and not path.startswith(CUSTOMER_API):
                return jsonify(error="forbidden"), 403
            for method, prefix, role in API_RULES:
                if path.startswith(prefix) and method in ("*", request.method):
                    return None if need(role) else (jsonify(error="forbidden"), 403)
            return None
        page = path.lstrip("/") or "index.html"
        if Path_suffix(page) in ASSET_SUFFIXES:
            return None
        if count_users() == 0 and page != "setup.html":
            return redirect("/setup.html")
        if page in PUBLIC_PAGES:
            return None
        if not g.user:
            return redirect("/login.html")
        if g.user["role"] == "customer":
            return None if page in CUSTOMER_PAGES else redirect("/products.html")
        if not need(PAGE_MIN_ROLE.get(page, "cashier")):
            return redirect("/index.html")
        return None

    @app.after_request
    def headers(resp):
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("X-Frame-Options", "DENY")
        if request.path.startswith("/api/"):
            resp.headers["Cache-Control"] = "no-store"
        return resp

    @app.get("/api/auth/status")
    def auth_status():
        return jsonify(setup_needed=count_users() == 0, logged_in=g.user is not None)

    @app.post("/api/setup")
    def setup_admin():
        x = request.get_json(silent=True) or {}
        user, pw = (x.get("username") or "").strip(), x.get("password")
        if not USERNAME_RE.match(user):
            return jsonify(error="Username: 3-32 letters, numbers, . _ -"), 400
        problem = _password_problem(pw)
        if problem:
            return jsonify(error=problem), 400
        con = db()
        try:
            con.execute("BEGIN IMMEDIATE")                       # no race between two setup requests
            if con.execute("SELECT COUNT(*) FROM users").fetchone()[0]:
                con.rollback(); return jsonify(error="Setup already done."), 409
            cur = con.execute("INSERT INTO users(username,full_name,password_hash,role,can_see_all_products,can_edit_all_products) VALUES(?,?,?,'admin',1,1)",
                              (user, (x.get("full_name") or user).strip(), generate_password_hash(pw)))
            con.execute("UPDATE products SET owner_id=? WHERE owner_id IS NULL", (cur.lastrowid,))   # adopt any pre-existing products
            con.commit()
            session.clear(); session.permanent = True; session["uid"] = cur.lastrowid
        finally:
            con.close()
        return jsonify(ok=True), 201

    @app.post("/api/login")
    def login():
        x = request.get_json(silent=True) or {}
        username, pw = (x.get("username") or "").strip(), x.get("password") or ""
        key = _client_key(username)
        wait = _locked_for(key)
        if wait:
            return jsonify(error=f"Too many attempts. Try again in {wait // 60 + 1} min."), 429
        con = db()
        u = con.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        ok = check_password_hash(u["password_hash"] if u else _DUMMY_HASH, pw) and u is not None and u["active"]
        if not ok:
            con.close(); _record_fail(key)
            return jsonify(error="Incorrect username or password."), 401
        con.execute("UPDATE users SET last_login=? WHERE id=?", (_now(), u["id"])); con.commit(); con.close()
        with _fails_lock: _fails.pop(key, None)
        session.clear(); session.permanent = True; session["uid"] = u["id"]
        return jsonify(ok=True, user=_public(u))

    @app.post("/api/logout")
    def logout():
        session.clear()
        return jsonify(ok=True)

    @app.get("/api/me")
    def me():
        return jsonify(_public(g.user))

    @app.patch("/api/me")
    def update_profile():
        x = request.get_json(silent=True) or {}
        u = g.user
        pick = lambda k, old: old if _text(x, k) is None else _text(x, k)
        full = pick("full_name", u["full_name"])
        if not full:
            return jsonify(error="Name cannot be empty."), 400
        con = db()
        con.execute("UPDATE users SET full_name=?,business_name=?,phone=?,email=? WHERE id=?",
                    (full, pick("business_name", u["business_name"]), pick("phone", u["phone"]), pick("email", u["email"]), u["id"]))
        con.commit()
        out = _public(con.execute("SELECT * FROM users WHERE id=?", (u["id"],)).fetchone()); con.close()
        return jsonify(out)

    @app.post("/api/me/password")
    def change_own_password():
        x = request.get_json(silent=True) or {}
        u = g.user
        if not check_password_hash(u["password_hash"], x.get("current") or ""):
            return jsonify(error="Current password is wrong."), 400
        problem = _password_problem(x.get("new"))
        if problem:
            return jsonify(error=problem), 400
        con = db()
        con.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(x["new"]), u["id"]))
        con.commit(); con.close()
        return jsonify(ok=True)

    @app.route("/api/users", methods=["GET", "POST"])
    def users():
        con = db()
        if request.method == "GET":
            out = [_public(r) for r in con.execute("SELECT * FROM users ORDER BY username").fetchall()]
            con.close(); return jsonify(out)
        x = request.get_json(silent=True) or {}
        user, role = (x.get("username") or "").strip(), x.get("role", "cashier")
        problem = None if USERNAME_RE.match(user) else "Username: 3-32 letters, numbers, . _ -"
        problem = problem or (None if role in RANK else "Role must be admin, manager, cashier or customer.")
        problem = problem or _password_problem(x.get("password"))
        if problem:
            con.close(); return jsonify(error=problem), 400
        see, edit = DEFAULT_PERMS[role]
        see = int(bool(x.get("can_see_all_products", see))); edit = int(bool(x.get("can_edit_all_products", edit)))
        try:
            cur = con.execute("INSERT INTO users(username,full_name,business_name,phone,email,password_hash,role,can_see_all_products,can_edit_all_products) VALUES(?,?,?,?,?,?,?,?,?)",
                              (user, (x.get("full_name") or user).strip(), _text(x, "business_name"), _text(x, "phone", 40), _text(x, "email"),
                               generate_password_hash(x["password"]), role, see, edit))
            con.commit()
            out = _public(con.execute("SELECT * FROM users WHERE id=?", (cur.lastrowid,)).fetchone())
        except Exception:
            con.close(); return jsonify(error="That username already exists."), 409
        con.close(); return jsonify(out), 201

    @app.patch("/api/users/<int:uid>")
    def update_user(uid):
        x = request.get_json(silent=True) or {}
        con = db()
        u = con.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
        if not u:
            con.close(); return jsonify(error="User not found."), 404
        role = x.get("role", u["role"]); active = int(bool(x.get("active", u["active"])))
        if role not in RANK:
            con.close(); return jsonify(error="Role must be admin, manager, cashier or customer."), 400
        loses_admin = u["role"] == "admin" and u["active"] and (role != "admin" or not active)
        if loses_admin and con.execute("SELECT COUNT(*) FROM users WHERE role='admin' AND active=1").fetchone()[0] <= 1:
            con.close(); return jsonify(error="There must always be at least one active admin."), 409
        pw_hash = u["password_hash"]
        if x.get("password"):
            problem = _password_problem(x["password"])
            if problem:
                con.close(); return jsonify(error=problem), 400
            pw_hash = generate_password_hash(x["password"])
        see, edit = (u["can_see_all_products"], u["can_edit_all_products"]) if role == u["role"] else DEFAULT_PERMS[role]
        see = int(bool(x.get("can_see_all_products", see))); edit = int(bool(x.get("can_edit_all_products", edit)))
        pick = lambda k, old: old if _text(x, k) is None else _text(x, k)
        con.execute("UPDATE users SET full_name=?,business_name=?,phone=?,email=?,role=?,active=?,password_hash=?,can_see_all_products=?,can_edit_all_products=? WHERE id=?",
                    ((x.get("full_name") or u["full_name"]), pick("business_name", u["business_name"]), pick("phone", u["phone"]),
                     pick("email", u["email"]), role, active, pw_hash, see, edit, uid))
        con.commit()
        out = _public(con.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()); con.close()
        return jsonify(out)


def Path_suffix(name):
    i = name.rfind(".")
    return name[i:].lower() if i != -1 else ""
