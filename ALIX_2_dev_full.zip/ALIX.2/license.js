/* ALIX licensing banner + lock — talks to /api/license (server verifies the signature). */
(() => {
  if (location.pathname.endsWith("license.html")) return;
  const bar = (text, bg) => {
    const b = document.createElement("div");
    b.style.cssText = `position:fixed;top:0;left:0;right:0;z-index:99998;height:44px;display:flex;align-items:center;justify-content:center;gap:12px;padding:0 16px;background:${bg};color:#fff;font:600 14px Arial,sans-serif;text-align:center`;
    b.innerHTML = `<span></span><a href="license.html" style="color:#fff;text-decoration:underline">Renew / update license</a>`;
    b.firstChild.textContent = text;
    document.body.prepend(b);
    document.body.style.paddingTop = "44px";
    const s = document.createElement("style"); s.textContent = ".sidebar{top:44px!important}"; document.head.append(s);
  };
  const run = async () => {
    let s;
    try { s = await (await fetch("/api/license", { cache: "no-store" })).json(); }
    catch { document.body.innerHTML = "<div style='font:16px Arial;padding:40px;text-align:center'>Cannot reach the ALIX server.<br>Start it (<b>python3 server.py</b>) and open this same address again.</div>"; return; }
    if (s.state === "locked") { location.replace("license.html"); return; }
    const extra = s.message ? " — " + s.message : "";
    if (s.state === "warning") {
      const d = s.days_left;
      bar(d === 0 ? `Your subscription expires today${extra}` : `Your subscription expires in ${d} day${d === 1 ? "" : "s"} (${s.expires}). Please pay to renew${extra}`, "#c77700");
    } else if (s.state === "grace") {
      bar(`Subscription expired. The POS will lock in ${s.grace_left} day${s.grace_left === 1 ? "" : "s"} unless renewed${extra}`, "#be3e3e");
    }
  };
  document.readyState === "loading" ? document.addEventListener("DOMContentLoaded", run) : run();
})();
