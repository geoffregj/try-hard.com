# Changelog

Append new entries at the bottom of the relevant section (or start a new
`## Debugging history — <feature>` section for something not covered yet).
Don't edit or delete past entries — this file is a record of what was
already tried and why it did or didn't work, so nobody re-discovers the
same dead end twice. See `STATUS.md` for the current state; this file is
the history that got you there. (The same story is in `git log`.)

## History of the project so far

**1. Baseline — `ccc.zip` as received (2026-09-24).**
POS front end (HTML/JS pages, one shared `app.js`) plus a Flask/SQLite API. The
front end never called the API: no `fetch()` anywhere, everything in
`localStorage`. Hardcoded login `Admin`/`admin123` checked in `login.html`;
"logged in" was just `alixLoggedIn=1` in localStorage. Product edits asked for
a password, default `ALIX2026`, stored in plain text. `server.py` had no
authentication, `CORS(app)` wide open and `debug=True`. `app.js 2.js` was an
older leftover copy.

**2. Licensed variant added (from `files.zip`).**
`licensing.py`, `license.js`, `license.html`, `license.json`; `server.py` now serves
the pages and blocks everything when the signed licence is expired.
`ALIX_owner_tools.zip` (contains the licence *private key*) was **not** added to
the repo — it must never sit next to the customer build. Licensing code is left
untouched on purpose.

## Debugging history — duplicated business title on receipts

**Reported:** the receipt preview popup showed the logo + "ALIX POWER ENTERPRISE" twice.
Three separate causes, same mistake each time (an old template left in next to the new one):
- `app.js` receipt preview modal: the header row was written twice in a row.
- `app.js` `quotePrint()`: two `document.write` calls — old template, then the settings-aware one.
- `receipt.js` `print()`: same double write.

**Fixed:** kept the settings-aware version everywhere. A scan for other back-to-back
near-identical lines found nothing else. **Verified** in a real browser (receipt
preview has one logo, one title). The two print-window fixes have not been opened
in a browser.

## Debugging history — hardcoded config and credentials

**3. Config out of the code.** New `config.py` reads environment variables or a
`.env` file. Wrote a 10-line `.env` parser instead of adding `python-dotenv`: one
fewer dependency on a weak PC, and nothing to install. `ALIX_SECRET_KEY` is generated
on first run and appended to `.env` so logins survive a restart. Business
name/footers for the first profile row come from config; demo products and
customers are only inserted when `ALIX_SEED_DEMO=1`.

**4. Server hardening.** Removed `flask-cors` (pages and API are the same origin, so
it was only weakening things) and `debug=True` (Werkzeug's debugger is a remote-code
console if the port is reachable). Switched to **waitress**: pure Python, no compiler
needed on Windows, 4 threads by default. SQLite now runs in WAL mode with a 5 s busy
timeout so a power cut or a second reader can't corrupt or block the till.
Idle memory measured at ~44 MB.

**5. Real login (`auth.py`).**
- Passwords hashed with werkzeug's default (scrypt, ~32 MB for a fraction of a second at
  login only). Considered PBKDF2 for lower memory; kept scrypt because 32 MB is fine even on
  a 1 GB PC and it's the stronger choice.
- No default account. First visit with an empty `users` table redirects everything to
  `setup.html`; `/api/setup` runs in `BEGIN IMMEDIATE` so two simultaneous requests can't
  both create an admin.
- Unknown-username logins still run a dummy hash so response time doesn't reveal which
  usernames exist.
- Lock-out: 5 failures per IP+username in 5 min → HTTP 429. In memory on purpose (simple);
  resets on restart.
- Every mutating API call must be `application/json` (415 otherwise) — cheap CSRF defence on
  top of `SameSite=Lax` cookies.
- The user row is re-read on every request, so deactivating someone or changing their
  role takes effect immediately, not at cookie expiry.
- At least one active admin must always exist (demote/deactivate refused with 409).
- Page access is decided by the server (`PAGE_MIN_ROLE`), so a cashier typing
  `/settings.html` is redirected — hiding the menu link is only cosmetics.

**6. Client-side login removed.** The `alixLoggedIn` localStorage flag and the inline
guard scripts on 7 pages are gone; `auth.js` asks the server (`/api/me`) instead.
*Dead end noted:* I briefly believed three of those guard scripts were malformed JS
(stray backslashes). They weren't — that was just how the text was displayed while
inspecting. They worked; they were simply client-side and therefore bypassable.

**7. Product password replaced by roles.** The two `prompt("Enter product management
password")` checks and the Settings field are gone; product add/edit now requires role
manager/admin (`window.ALIX_USER`, set from `/api/me`). **Limit:** because product data is
still in localStorage this is a UI rule, not a server rule — see STATUS.md.
Also removed the fake prompt()-based "Manage Users"/"Manage Roles" (demo users "Alex
Mwangi"/"Jane Wambui" lived only in localStorage and could not log in). "Manage Users"
now opens the real `users.html`.

**8. Backups.** `backup.py` uses SQLite's online backup API (safe while the server runs),
runs once at start and every 24 h in a daemon thread, keeps the newest 14.

**9. Tests kept in the repo.** `tests/test_backend.py` (46 checks, Flask test client, temp DB)
and `tests/test_browser.py` (44 checks, real Chromium via Playwright).
*Dead ends while writing them — all test bugs, none were app bugs:* a 2-letter username
(`jo`) correctly failed the 3-character minimum and cascaded; the POS checkout uses a
`prompt()` for "Amount Received", which a headless browser dismisses (and Playwright's
`accept()` returns an empty string unless given text); a leftover dialog listener
swallowed that prompt; and a selector counting logos also counted the sidebar logo.

**10. Deployment helpers.** `start.sh` / `start.bat` (create a venv, install
requirements, run), `deploy/alix.service` (systemd auto-start), `README.md`.
Requirements are now just Flask, waitress, cryptography.

## Next up (not done)

- Phase 3: sales through the API — server computes prices/VAT/totals and issues receipt numbers.
- Phase 4: products, customers, suppliers, expenses, quotations, settings from `localStorage` to
  the database, with a one-time import of existing browser data.
- Phase 5: payment validation (amount check, reject a reused M-Pesa code).
- Record the logged-in user as the cashier on each sale.

## Debugging history — customer accounts, ownership and shop data in the database (2026-09-25)

**Asked for:** no hardcoded test data; customers get accounts and add their own products; the admin (and anyone
given permission) sees everyone's; users and everything else stored in a database.

**Approach and why.**
- *Products relational, with an owner.* `products.owner_id`, `UNIQUE(owner_id, sku)`. SQLite cannot drop the old
  global `UNIQUE(sku)`/`UNIQUE(barcode)` or widen the role `CHECK`, so `migrate()` rebuilds `users` and `products`
  (create new, copy, drop, rename, with foreign keys off) and leaves `sale_items` pointing at the same ids.
- *Everything else as JSON documents, via `store.js`.* The 1,500-line `app.js` and four other scripts read and write
  localStorage synchronously in ~60 places. Rewriting them for async calls was the risky option. Instead `store.js`
  replaces `Storage.prototype.getItem/setItem/removeItem` for the shop's keys: one blocking XHR to `/api/bootstrap`
  fills memory before any page script runs; each `setItem` is diffed against what the server has and only the
  changes are POSTed. Arrays are keyed per record (`id`, else `invoice`, else `number`, else a content hash) so two
  tills adding different sales don't overwrite each other.
- *Stock as deltas.* First version compared against the last server reply, so two sales inside one round trip
  double-counted (10 -> 9 -> 8 sent as -1 then -2). The tracking snapshot now advances when a change is queued.
  The server refuses to go below 0.
- *Permissions on the server.* The browser is never trusted: `/api/products` filters by owner unless the user has
  `can_see_all_products` (admin always), edits need ownership or `can_edit_all_products`, and the old
  `/api/sales` now looks products up through the same visibility filter.

**Dead ends / gotchas.**
- The DELETE endpoint returned 415 in tests: the CSRF guard requires a JSON body on every write, DELETE included.
- The permission checkboxes inherited `input{width:100%}` from the shared stylesheet; fixed inline.
- Browser test failed on `Dialog.accept(prompt_text=<int>)`: Playwright wants strings.
- The empty POS grid shows a "No products found." element, so tests must count `[data-product]`, not children.

**Hardcoded data removed:** `demoProducts/Customers/Suppliers/Movements/Expenses` (now `[]`), the KSh 46,850
fallback, static dashboard cards and top sellers in `index.html`/`dashboard.html`, chart `sampleValues`, and the
placeholder phone/email in default settings.

**Verified:** `test_backend.py` 46/46, `test_products.py` 77/77, `test_browser.py` 67/67 (real Chromium), including a
server restart and a brand-new browser profile seeing the same data.
