#!/usr/bin/env python3
"""ALIX license tool — for whoever holds the signing key (that's you, the builder).

Two things it does:
  1. genkey  — make a brand-new signing key pair (only ever do this ONCE per install of ALIX)
  2. issue   — sign a license.json for a customer, using that key

Keep license_private.pem secret. Never send it to a customer, never commit it
to git, never put it on the customer's PC. Only license.json (the signed
result) goes to the customer.

Usage:
    python3 license_tool.py genkey
    python3 license_tool.py issue --customer "Jane's Salon" --days 30
    python3 license_tool.py issue --customer "Jane's Salon" --days 30 --warn 5 --grace 2 \
        --message "Pay via M-Pesa to renew" --out jane_license.json
    python3 license_tool.py suspend --in jane_license.json          # mark an existing license suspended
"""
import argparse, base64, json, sys
from datetime import date, timedelta
from pathlib import Path
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec

ROOT = Path(__file__).resolve().parent
PRIVATE_KEY_FILE = ROOT / "license_private.pem"


def _canon(payload):
    return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()


def cmd_genkey(args):
    if PRIVATE_KEY_FILE.exists() and not args.force:
        sys.exit(f"{PRIVATE_KEY_FILE} already exists. Re-running this would let you sign licenses "
                  f"that OLD installs of ALIX (with the old public key baked in) can't verify.\n"
                  f"Pass --force only if you understand that and are prepared to update the "
                  f"PUBLIC_KEY_PEM in licensing.py on every install too.")
    private_key = ec.generate_private_key(ec.SECP256R1())
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    public_pem = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    PRIVATE_KEY_FILE.write_bytes(private_pem)
    try:
        PRIVATE_KEY_FILE.chmod(0o600)
    except OSError:
        pass
    print(f"Wrote {PRIVATE_KEY_FILE} — back this up somewhere safe and NEVER share it or commit it.\n")
    print("Now paste this into licensing.py, replacing the existing PUBLIC_KEY_PEM block")
    print("(every ALIX install that should trust licenses from this key needs this exact block):\n")
    print('PUBLIC_KEY_PEM = b"""' + public_pem.decode().strip() + '\n"""')


def _load_private_key():
    if not PRIVATE_KEY_FILE.exists():
        sys.exit(f"{PRIVATE_KEY_FILE} not found. Run 'python3 license_tool.py genkey' first "
                  f"(only once, ever — see its warning), or copy your existing license_private.pem here.")
    return serialization.load_pem_private_key(PRIVATE_KEY_FILE.read_bytes(), password=None)


def _sign(private_key, payload):
    signature = private_key.sign(_canon(payload), ec.ECDSA(hashes.SHA256()))
    return {"payload": payload, "signature": base64.b64encode(signature).decode()}


def cmd_issue(args):
    private_key = _load_private_key()
    payload = {
        "customer": args.customer,
        "issued": date.today().isoformat(),
        "expires": (date.today() + timedelta(days=args.days)).isoformat(),
        "warn_days": args.warn,
        "grace_days": args.grace,
        "status": "active",
        "message": args.message,
    }
    lic = _sign(private_key, payload)
    out = Path(args.out)
    out.write_text(json.dumps(lic, indent=2))
    print(f"Wrote {out}")
    print(f"  customer: {payload['customer']}")
    print(f"  active until {payload['expires']} ({args.days} days), "
          f"then {args.warn} days' warning, {args.grace} days' grace before it locks.")
    print(f"\nSend {out} to the customer — they drop it in as license.json next to server.py, "
          f"or you host it and point their ALIX_LICENSE_URL at it for auto-renewal.")


def cmd_suspend(args):
    private_key = _load_private_key()
    old = json.loads(Path(args.infile).read_text())["payload"]
    old["status"] = "suspended"
    old["issued"] = date.today().isoformat()   # must be newer than the current one to be accepted
    lic = _sign(private_key, old)
    out = Path(args.out or args.infile)
    out.write_text(json.dumps(lic, indent=2))
    print(f"Wrote {out} — status set to suspended. Re-deliver this file (or push it via ALIX_LICENSE_URL) "
          f"to lock the customer out immediately.")


p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
sub = p.add_subparsers(dest="cmd", required=True)

g = sub.add_parser("genkey", help="generate a new signing key pair (do this once, ever)")
g.add_argument("--force", action="store_true", help="overwrite an existing key (dangerous, see warning)")
g.set_defaults(func=cmd_genkey)

i = sub.add_parser("issue", help="sign a new license.json for a customer")
i.add_argument("--customer", required=True)
i.add_argument("--days", type=int, default=30, help="days until expiry (default 30)")
i.add_argument("--warn", type=int, default=7, help="days of warning before expiry (default 7)")
i.add_argument("--grace", type=int, default=3, help="days of grace after expiry before locking (default 3)")
i.add_argument("--message", default="Contact us to renew.")
i.add_argument("--out", default="license.json")
i.set_defaults(func=cmd_issue)

s = sub.add_parser("suspend", help="re-sign an existing license as suspended (instant lock)")
s.add_argument("--in", dest="infile", required=True)
s.add_argument("--out", help="defaults to overwriting --in")
s.set_defaults(func=cmd_suspend)

args = p.parse_args()
args.func(args)
