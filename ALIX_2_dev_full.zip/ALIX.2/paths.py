"""Where things live — and the one part of this project that PyInstaller
(or any "compile it to an .exe" tool) genuinely needs to know about.

There are two different kinds of "this app's folder":

  BUNDLE_DIR — read-only stuff shipped WITH the app (HTML/CSS/JS pages,
  schema.sql). Fine to live inside a compiled .exe's temp extraction dir,
  because it's never written to.

  DATA_DIR — everything the app WRITES: the real database, license.json,
  .env, backups. This must live in a normal, permanent folder next to the
  .exe on disk — never inside PyInstaller's temp extraction dir, which is
  deleted and recreated from scratch on every single run. Get this wrong
  and the database (and the login secret key, and the license) silently
  reset every time the app restarts.

Running normally with `python server.py`, both are just this folder, same
as before — nothing changes for you today. This file only starts doing
something different once the app is actually frozen into an executable.
"""
import sys
from pathlib import Path

if getattr(sys, "frozen", False):
    BUNDLE_DIR = Path(getattr(sys, "_MEIPASS", Path(sys.executable).resolve().parent))
    DATA_DIR = Path(sys.executable).resolve().parent
else:
    BUNDLE_DIR = Path(__file__).resolve().parent
    DATA_DIR = Path(__file__).resolve().parent
