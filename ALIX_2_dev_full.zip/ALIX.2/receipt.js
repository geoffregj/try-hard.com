(() => {
  const money = value => `KSh ${Number(value || 0).toLocaleString('en-KE', { maximumFractionDigits: 2 })}`;
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));
  const sales = () => { try { return JSON.parse(localStorage.getItem('alixSales') || '[]'); } catch { return []; } };
  const rows = document.getElementById('receiptsTable');
  const render = () => {
    const q = document.getElementById('receiptSearch').value.toLowerCase();
    const visible = sales().filter(s => `${s.receipt || ''} ${s.invoice || ''} ${s.customer || ''} ${s.payment || ''} ${s.paymentReference || ''}`.toLowerCase().includes(q));
    rows.innerHTML = visible.length ? visible.map(s => `<tr><td><b>${esc(s.receipt || `RCPT-${String(s.invoice || '').replace('INV-', '')}`)}</b></td><td>${esc(s.invoice)}</td><td>${esc(s.customer)}</td><td>${esc(s.payment)}</td><td>${esc(s.paymentReference || '')}</td><td>${new Date(s.createdAt).toLocaleString('en-KE')}</td><td>${money(s.total)}</td><td><button data-receipt="${esc(s.invoice)}" data-format="RECEIPT">Receipt</button></td></tr>`).join('') : '<tr><td colspan="8">No receipt records found.</td></tr>';
  };
  const print = (sale, format = 'RECEIPT') => {
    const settings = JSON.parse(localStorage.getItem('alixSettings') || '{}');
    const number = format === 'RECEIPT' ? (sale.receipt || sale.invoice) : sale.invoice;
    const subtotal = sale.subtotal ?? (sale.items || []).reduce((sum, item) => sum + Number(item.price || 0) * Number(item.quantity || 0), 0);
    const discount = Number(sale.discount || 0), tax = Number(sale.tax || 0), received = Number(sale.received ?? sale.total), balance = Math.max(0, Number(sale.total || 0) - received), change = Math.max(0, received - Number(sale.total || 0));
    const logo = new URL('IMG-20260803-WA0008~2.jpg', window.location.href).href;
    const win = window.open('', '_blank', 'width=760,height=700');
      const header = format === 'INVOICE' ? settings.invoiceHeader : settings.receiptHeader;
      const footer = format === 'INVOICE' ? (settings.invoiceFooter || settings.receiptFooter) : settings.receiptFooter;
      win.document.write(`<html><head><title>${format} ${esc(number)}</title><style>body{font-family:monospace;max-width:600px;margin:30px auto;color:#122746}.paper{border:1px dashed #b8cbe5;padding:20px}header{text-align:center;border-bottom:1px dashed #ccc;padding-bottom:10px}header img{width:58px;height:58px;object-fit:contain}table{width:100%;border-collapse:collapse}td,th{padding:6px 0;border-bottom:1px dashed #ddd;text-align:left}.total{text-align:right;font-weight:bold}</style></head><body><div class="paper"><header><div><img src="${logo}" alt="ALIX logo"><h2>${esc(settings.businessName || 'ALIX Power Enterprise')}</h2></div><p style="white-space:pre-line">${esc(header || (format === 'RECEIPT' ? 'Official Sales Receipt' : 'Invoice'))}<br>No.: <b>${esc(number)}</b> | ${new Date(sale.createdAt).toLocaleString('en-KE')}</p></header><p>Customer: ${esc(sale.customer)}<br>Payment: ${esc(sale.payment)}${sale.paymentReference ? `<br>Payment Details: ${esc(sale.paymentReference)}` : ''}</p><table><tr><th>Item</th><th>Qty</th><th>Price</th><th>Total</th></tr>${(sale.items || []).map(i => `<tr><td>${esc(i.name)}</td><td>${i.quantity}</td><td>${money(i.price)}</td><td>${money(i.price * i.quantity)}</td></tr>`).join('')}</table><p class="total">Subtotal: ${money(subtotal)}<br>Discount: ${money(discount)}<br>VAT: ${money(tax)}<br>Grand Total: ${money(sale.total)}<br>Received: ${money(received)}<br>${balance ? `Balance Due: ${money(balance)}` : `Change: ${money(change)}`}</p><p style="white-space:pre-line;text-align:center">${esc(footer || 'Thank you for your business!')}</p></div></body></html>`);
    win.document.close(); win.onload = () => win.print();
  };
  rows.addEventListener('click', e => { const sale = sales().find(s => s.invoice === e.target.dataset.receipt); if (sale) print(sale, e.target.dataset.format || 'RECEIPT'); });
  document.getElementById('printSelectedReceipt').addEventListener('click', () => { const sale = sales()[0]; if (sale) print(sale, 'RECEIPT'); });
  document.getElementById('receiptSearch').addEventListener('input', render);
  render();
})();