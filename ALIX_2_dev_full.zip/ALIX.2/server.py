from pathlib import Path
from datetime import datetime
import json, math, sqlite3
from flask import Flask, g, jsonify, request, send_from_directory, abort
import config
from paths import BUNDLE_DIR

ROOT=BUNDLE_DIR               # HTML/CSS/JS pages + schema.sql — read-only, safe to bundle into an .exe
DATABASE=config.DATABASE
app=Flask(__name__)          # no CORS: pages and API are served by this same server
import licensing
licensing.init(app)          # license gate first ...
import auth                  # ... then login/roles gate

def db():
    con=sqlite3.connect(DATABASE,timeout=5)
    con.row_factory=sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    return con
auth.init(app,db)
def body(): return request.get_json(silent=True) or {}
def many(rows): return [dict(x) for x in rows]
USERS_NEW=("CREATE TABLE users_new(id INTEGER PRIMARY KEY,username TEXT NOT NULL UNIQUE COLLATE NOCASE,full_name TEXT,business_name TEXT,phone TEXT,email TEXT,"
  "password_hash TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'cashier' CHECK(role IN ('admin','manager','cashier','customer')),"
  "can_see_all_products INTEGER NOT NULL DEFAULT 0,can_edit_all_products INTEGER NOT NULL DEFAULT 0,active INTEGER NOT NULL DEFAULT 1,"
  "created_at TEXT DEFAULT CURRENT_TIMESTAMP,last_login TEXT)")
PRODUCTS_NEW=("CREATE TABLE products_new(id INTEGER PRIMARY KEY,owner_id INTEGER REFERENCES users(id),name TEXT NOT NULL,sku TEXT NOT NULL,category TEXT NOT NULL,"
  "price REAL NOT NULL,cost REAL DEFAULT 0,stock INTEGER DEFAULT 0,low_stock_level INTEGER DEFAULT 5,barcode TEXT,active INTEGER DEFAULT 1,"
  "created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP,UNIQUE(owner_id,sku))")

def migrate():
    """Upgrade an older database in place (keeps users, logins, products). Safe to run every start."""
    con=sqlite3.connect(DATABASE,timeout=5,isolation_level=None)
    def cols(t): return {r[1] for r in con.execute(f"PRAGMA table_info({t})")}
    def ddl(t):
        r=con.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name=?",(t,)).fetchone(); return r[0] if r else None
    con.execute("PRAGMA foreign_keys=OFF")
    try:
        if ddl("users") and ("business_name" not in cols("users") or "'customer'" not in ddl("users")):
            con.execute("BEGIN")
            con.execute(USERS_NEW)
            con.execute("INSERT INTO users_new(id,username,full_name,password_hash,role,active,created_at,last_login,can_see_all_products,can_edit_all_products) "
                        "SELECT id,username,full_name,password_hash,role,active,created_at,last_login,1,CASE WHEN role IN('admin','manager') THEN 1 ELSE 0 END FROM users")
            con.execute("DROP TABLE users"); con.execute("ALTER TABLE users_new RENAME TO users"); con.execute("COMMIT")
        if ddl("products") and "owner_id" not in cols("products"):
            con.execute("BEGIN")
            con.execute(PRODUCTS_NEW)
            con.execute("INSERT INTO products_new(id,owner_id,name,sku,category,price,cost,stock,low_stock_level,barcode,active,created_at,updated_at) "
                        "SELECT id,(SELECT id FROM users WHERE role='admin' ORDER BY id LIMIT 1),name,sku,category,price,cost,stock,low_stock_level,barcode,active,created_at,updated_at FROM products")
            con.execute("DROP TABLE products"); con.execute("ALTER TABLE products_new RENAME TO products"); con.execute("COMMIT")
    finally:
        con.execute("PRAGMA foreign_keys=ON")
    con.execute("CREATE INDEX IF NOT EXISTS idx_products_owner ON products(owner_id)") if ddl("products") else None
    con.close()

def setup():
    migrate()
    con=db()
    con.execute("PRAGMA journal_mode=WAL")   # safer on power cuts, readers never block the till
    con.executescript((ROOT/"schema.sql").read_text())
    con.execute("CREATE INDEX IF NOT EXISTS idx_products_owner ON products(owner_id)")
    migrations = {
        "sales": ["receipt_number TEXT", "document_type TEXT DEFAULT 'INVOICE'", "payment_reference TEXT", "financial_year INTEGER"],
        "sale_items": ["item_type TEXT DEFAULT 'PRODUCT'", "cost_price REAL DEFAULT 0"]
    }
    for table, columns in migrations.items():
        existing = {row[1] for row in con.execute(f"PRAGMA table_info({table})")}
        for column in columns:
            if column.split()[0] not in existing:
                con.execute(f"ALTER TABLE {table} ADD COLUMN {column}")
    con.execute("INSERT OR IGNORE INTO business_profile(id,business_name,register_name,cashier_name,receipt_footer,invoice_footer,quotation_footer) VALUES(1,?,?,?,?,?,?)", (config.BUSINESS_NAME, config.REGISTER_NAME, "Admin", config.RECEIPT_FOOTER, config.RECEIPT_FOOTER, config.RECEIPT_FOOTER))
    con.execute("INSERT OR IGNORE INTO financial_years(year) VALUES(?)", (datetime.now().year,))
    if config.SEED_DEMO and not con.execute("SELECT 1 FROM products LIMIT 1").fetchone():
        con.executemany("INSERT INTO products(name,sku,category,price,cost,stock,low_stock_level) VALUES(?,?,?,?,?,?,?)",[
          ("LED Bulb 12W","LED-12W","Lighting",280,150,45,8),
          ("LED Floodlight 100W","LED-FL-100","Lighting",3200,1800,18,5),
          ("Copper Cable 2.5mm","CC-2.5","Cables",14500,8000,7,10),
          ("Double Socket Outlet","DSO-001","Electrical",850,400,42,8)])
        con.executemany("INSERT INTO customers(name,phone,email) VALUES(?,?,?)",[("Kamau Builders","+254 700 123 456","kamau@builders.com"),("Lakeview Hotel","+254 701 234 567","info@lakeview.com")])
    con.commit();con.close()

@app.get("/api/health")
def health(): return {"status":"ok","database":DATABASE.name}

# ---------- products: every product belongs to an owner (a customer account, a manager or the admin) ----------
def sees_all(u): return u["role"]=="admin" or bool(u["can_see_all_products"])
def edits_all(u): return u["role"]=="admin" or bool(u["can_edit_all_products"])
def can_add(u): return u["role"] in ("admin","manager","customer")
def is_editor(u,owner_id): return edits_all(u) or (owner_id==u["id"] and can_add(u))
PRODUCT_SELECT=("SELECT p.*,COALESCE(NULLIF(o.business_name,''),NULLIF(o.full_name,''),o.username,'') AS owner_name "
                "FROM products p LEFT JOIN users o ON o.id=p.owner_id")
def product_out(row,u):
    d=dict(row); d["can_edit"]=is_editor(u,d["owner_id"]); return d
def visible(u): return ("",[]) if sees_all(u) else (" AND p.owner_id=?",[u["id"]])

def clean_product(x,partial=False):
    """Validate product fields. Returns (fields, error)."""
    out={}
    for k,limit in (("name",120),("sku",60),("category",60)):
        if k in x:
            v=str(x[k] if x[k] is not None else "").strip()[:limit]
            if not v: return None,f"{k} cannot be empty"
            out[k]=v
    for k in ("price","cost"):
        if k in x:
            try: v=float(x[k])
            except (TypeError,ValueError): return None,f"{k} must be a number"
            if not math.isfinite(v) or v<0: return None,f"{k} must be 0 or more"
            out[k]=v
    for k in ("stock","low_stock_level"):
        if k in x:
            try: v=int(float(x[k]))
            except (TypeError,ValueError): return None,f"{k} must be a whole number"
            if v<0: return None,f"{k} must be 0 or more"
            out[k]=v
    if "barcode" in x: out["barcode"]=(str(x["barcode"]).strip()[:60] or None) if x["barcode"] is not None else None
    if not partial and any(k not in out for k in ("name","sku","price")): return None,"name, sku and price are required"
    return out,None

@app.route("/api/products",methods=["GET","POST"])
def products():
    u=g.user;con=db()
    if request.method=="GET":
        q=request.args.get("q","");extra,args=visible(u);owner=request.args.get("owner_id",type=int)
        sql=PRODUCT_SELECT+" WHERE p.active=1 AND (p.name LIKE ? OR p.sku LIKE ? OR p.barcode LIKE ?)"+extra
        args=["%"+q+"%"]*3+args
        if owner is not None: sql+=" AND p.owner_id=?";args.append(owner)
        out=[product_out(r,u) for r in con.execute(sql+" ORDER BY p.name",args)];con.close();return jsonify(out)
    if not can_add(u): con.close();return {"error":"Your account cannot add products."},403
    x=body();fields,err=clean_product(x)
    if err: con.close();return {"error":err},400
    owner=u["id"]
    if x.get("owner_id") not in (None,u["id"]):
        if not edits_all(u): con.close();return {"error":"You can only add products to your own account."},403
        if not con.execute("SELECT 1 FROM users WHERE id=? AND active=1 AND role!='cashier'",(x["owner_id"],)).fetchone(): con.close();return {"error":"Unknown owner."},400
        owner=int(x["owner_id"])
    try:
        cur=con.execute("INSERT INTO products(owner_id,name,sku,category,price,cost,stock,low_stock_level,barcode) VALUES(?,?,?,?,?,?,?,?,?)",
            (owner,fields["name"],fields["sku"],fields.get("category","General"),fields["price"],fields.get("cost",0),fields.get("stock",0),fields.get("low_stock_level",5),fields.get("barcode")))
        con.commit();out=product_out(con.execute(PRODUCT_SELECT+" WHERE p.id=?",(cur.lastrowid,)).fetchone(),u);con.close();return jsonify(out),201
    except sqlite3.IntegrityError: con.close();return {"error":f"SKU {fields['sku']} already exists for this owner."},409

@app.route("/api/products/<int:ident>",methods=["PATCH","DELETE"])
def update_product(ident):
    u=g.user;con=db();con.execute("BEGIN IMMEDIATE")
    row=con.execute(PRODUCT_SELECT+" WHERE p.id=? AND p.active=1",(ident,)).fetchone()
    if not row or (not sees_all(u) and row["owner_id"]!=u["id"]): con.rollback();con.close();return {"error":"Product not found"},404
    editor=is_editor(u,row["owner_id"])
    if request.method=="DELETE":
        if not editor: con.rollback();con.close();return {"error":"You cannot remove this product."},403
        con.execute("UPDATE products SET active=0,sku=sku||'#removed'||id,updated_at=CURRENT_TIMESTAMP WHERE id=?",(ident,));con.commit();con.close();return {"ok":True}
    x=body();delta=x.pop("stock_delta",None)
    fields,err=clean_product({k:v for k,v in x.items() if k in ("name","sku","category","price","cost","stock","low_stock_level","barcode")},partial=True)
    if err: con.rollback();con.close();return {"error":err},400
    if fields and not editor: con.rollback();con.close();return {"error":"You cannot edit this product."},403
    if "stock" in fields and delta is not None: con.rollback();con.close();return {"error":"Send stock or stock_delta, not both."},400
    if delta is not None:
        try: delta=int(delta)
        except (TypeError,ValueError): con.rollback();con.close();return {"error":"stock_delta must be a whole number"},400
        if not editor and u["role"]=="customer": con.rollback();con.close();return {"error":"You cannot change this stock."},403
        fields["stock"]=row["stock"]+delta
        if fields["stock"]<0: con.rollback();con.close();return {"error":f"Not enough stock of {row['name']} (only {row['stock']} left)."},409
    if not fields: con.rollback();con.close();return {"error":"No valid fields supplied"},400
    try:
        con.execute("UPDATE products SET "+",".join(k+"=?" for k in fields)+",updated_at=CURRENT_TIMESTAMP WHERE id=?",[*fields.values(),ident]);con.commit()
    except sqlite3.IntegrityError: con.rollback();con.close();return {"error":"That SKU already exists for this owner."},409
    out=product_out(con.execute(PRODUCT_SELECT+" WHERE p.id=?",(ident,)).fetchone(),u);con.close();return jsonify(out)

# ---------- shop records kept as JSON (what the pages used to keep in the browser) ----------
RECORDS={"alixCustomers":("cashier",False),"alixSales":("cashier",True),"alixQuotations":("cashier",True),
         "alixSuppliers":("manager",False),"alixExpenses":("manager",True),"alixInventoryMovements":("manager",True),"alixFinancialArchives":("manager",True)}
KV_KEYS={"alixSettings":("cashier","manager"),"alixInvoiceSequence":("cashier","cashier"),"alixReceiptSequence":("cashier","cashier"),"alixQuotationSequence":("cashier","cashier")}
SEQUENCES={"alixInvoiceSequence","alixReceiptSequence","alixQuotationSequence"}
def rank_ok(u,role): return auth.RANK[u["role"]]>=auth.RANK[role]

@app.get("/api/bootstrap")
def bootstrap():
    u=g.user;con=db();extra,args=visible(u)
    out={"user":auth._public(u),"products":[product_out(r,u) for r in con.execute(PRODUCT_SELECT+" WHERE p.active=1"+extra+" ORDER BY p.name",args)],"records":{},"kv":{}}
    if u["role"]!="customer":
        for coll,(role,newest) in RECORDS.items():
            out["records"][coll]=[json.loads(r["data"]) for r in con.execute("SELECT data FROM records WHERE coll=? ORDER BY seq "+("DESC" if newest else "ASC"),(coll,))] if rank_ok(u,role) else []
        for key,(read_role,_w) in KV_KEYS.items():
            r=con.execute("SELECT value FROM kv WHERE key=?",(key,)).fetchone()
            if r and rank_ok(u,read_role): out["kv"][key]=r["value"]
    con.close();return jsonify(out)

@app.post("/api/records/<coll>")
def sync_records(coll):
    u=g.user
    if coll not in RECORDS: return {"error":"Unknown collection"},404
    if not rank_ok(u,RECORDS[coll][0]): return {"error":"forbidden"},403
    x=body();ups=x.get("upserts") or [];dels=x.get("deletes") or []
    if not isinstance(ups,list) or not isinstance(dels,list) or len(ups)>5000 or len(dels)>5000: return {"error":"bad request"},400
    con=db()
    try:
        con.execute("BEGIN IMMEDIATE")
        for rid in dels: con.execute("DELETE FROM records WHERE coll=? AND rid=?",(coll,str(rid)[:200]))
        for it in ups:
            data=json.dumps(it["data"],separators=(",",":"))
            if len(data)>500000: raise ValueError("record too large")
            con.execute("INSERT INTO records(coll,rid,data) VALUES(?,?,?) ON CONFLICT(coll,rid) DO UPDATE SET data=excluded.data,updated_at=CURRENT_TIMESTAMP",(coll,str(it["rid"])[:200],data))
        con.commit();return {"ok":True}
    except (KeyError,TypeError,ValueError) as e:
        con.rollback();return {"error":"bad request: "+str(e)},400
    finally: con.close()

@app.post("/api/kv")
def set_kv():
    u=g.user;x=body();key=x.get("key");val=x.get("value")
    if key not in KV_KEYS: return {"error":"Unknown key"},404
    if not rank_ok(u,KV_KEYS[key][1]): return {"error":"forbidden"},403
    if not isinstance(val,str) or len(val)>200000: return {"error":"bad request"},400
    con=db()
    if key in SEQUENCES:   # counters only ever go up, so two tills can't reuse a number
        con.execute("INSERT INTO kv(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=CASE WHEN CAST(excluded.value AS INTEGER)>CAST(kv.value AS INTEGER) THEN excluded.value ELSE kv.value END,updated_at=CURRENT_TIMESTAMP",(key,val))
    else: con.execute("INSERT INTO kv(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=CURRENT_TIMESTAMP",(key,val))
    con.commit();out=con.execute("SELECT value FROM kv WHERE key=?",(key,)).fetchone()["value"];con.close();return {"ok":True,"value":out}

@app.route("/api/customers",methods=["GET","POST"])
def customers():
    con=db()
    if request.method=="GET":
        q=request.args.get("q","");out=con.execute("SELECT * FROM customers WHERE name LIKE ? OR phone LIKE ? ORDER BY name",("%"+q+"%","%"+q+"%")).fetchall();con.close();return jsonify(many(out))
    x=body()
    if not x.get("name"):con.close();return {"error":"name is required"},400
    cur=con.execute("INSERT INTO customers(name,phone,email) VALUES(?,?,?)",(x["name"],x.get("phone"),x.get("email")));con.commit();out=dict(con.execute("SELECT * FROM customers WHERE id=?",(cur.lastrowid,)).fetchone());con.close();return jsonify(out),201

@app.get("/api/invoices")
def invoices():
    con=db();out=con.execute("SELECT * FROM sales ORDER BY created_at DESC").fetchall();con.close();return jsonify(many(out))
@app.get("/api/invoices/<number>")
def invoice(number):
    con=db();out=con.execute("SELECT * FROM sales WHERE invoice_number=?",(number,)).fetchone()
    if not out:con.close();return {"error":"Invoice not found"},404
    sale=dict(out);sale["items"]=many(con.execute("SELECT * FROM sale_items WHERE sale_id=?",(sale["id"],)).fetchall());con.close();return jsonify(sale)

@app.route("/api/settings", methods=["GET", "PUT"])
def settings():
    con=db()
    if request.method == "PUT":
        x=body(); fields=["business_name","phone","email","address","tax_number","receipt_footer","invoice_footer","quotation_footer","register_name","cashier_name"]
        con.execute("INSERT OR IGNORE INTO business_profile(id) VALUES(1)")
        con.execute("UPDATE business_profile SET "+",".join(field+"=?" for field in fields)+",updated_at=CURRENT_TIMESTAMP WHERE id=1", [x.get(field, "") for field in fields])
        con.commit()
    row=con.execute("SELECT * FROM business_profile WHERE id=1").fetchone();con.close();return jsonify(dict(row))

@app.post("/api/sales")
def create_sale():
    order=body();items=order.get("items",[])
    if not items:return {"error":"At least one item is required"},400
    con=db()
    try:
        lines=[];subtotal=discount=tax=0
        for item in items:
            extra,vargs=visible(g.user);product=con.execute("SELECT p.* FROM products p WHERE p.id=? AND p.active=1"+extra,[item["product_id"],*vargs]).fetchone();qty=int(item.get("quantity",0))
            if not product or qty<1 or product["stock"]<qty:raise ValueError("Insufficient stock")
            base=product["price"]*qty;disc=min(float(item.get("discount_amount",0)),base);rate=float(item.get("tax_rate",16));vat=(base-disc)*rate/100
            lines.append((product,qty,disc,rate,vat,base-disc+vat));subtotal+=base;discount+=disc;tax+=vat
        total=subtotal-discount+tax;received=float(order.get("amount_received",total))
        if received<total:raise ValueError("Balance due: %.2f"%(total-received))
        now=datetime.now();number=order.get("invoice_number") or "INV-"+now.strftime("%y%m%d-%H%M%S");receipt=order.get("receipt_number") or "RC-"+now.strftime("%y%m%d-%H%M%S")
        con.execute("INSERT OR IGNORE INTO financial_years(year) VALUES(?)", (now.year,))
        cur=con.execute("INSERT INTO sales(invoice_number,receipt_number,document_type,customer_id,customer_name,payment_method,payment_reference,subtotal,discount_total,tax_total,grand_total,amount_received,change_due,financial_year) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",(number,receipt,order.get("document_type","INVOICE"),order.get("customer_id"),order.get("customer_name","Walk-in Customer"),order.get("payment_method","Cash"),order.get("payment_reference"),subtotal,discount,tax,total,received,received-total,now.year))
        for p,qty,disc,rate,vat,line in lines:
            con.execute("INSERT INTO sale_items(sale_id,product_id,product_name,sku,item_type,unit_price,cost_price,quantity,discount_amount,tax_rate,tax_amount,line_total) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",(cur.lastrowid,p["id"],p["name"],p["sku"],"PRODUCT",p["price"],p["cost"],qty,disc,rate,vat,line))
            con.execute("UPDATE products SET stock=stock-? WHERE id=?",(qty,p["id"]))
            con.execute("INSERT INTO inventory_movements(product_id,movement_type,quantity,reason,reference) VALUES(?,?,?,?,?)",(p["id"],"SALE",-qty,"Completed sale",number))
        con.commit();con.close();return {"invoice_number":number,"receipt_number":receipt,"subtotal":subtotal,"discount_total":discount,"tax_total":tax,"grand_total":total,"change_due":received-total},201
    except (ValueError,KeyError) as error:con.rollback();con.close();return {"error":str(error)},400

@app.route("/api/quotations",methods=["GET","POST"])
def quotations():
    con=db()
    if request.method=="GET":out=con.execute("SELECT * FROM quotations ORDER BY created_at DESC").fetchall();con.close();return jsonify(many(out))
    x=body();items=x.get("items",[])
    if not x.get("customer_name") or not items:con.close();return {"error":"customer_name and items are required"},400
    subtotal=sum(float(i["unit_price"])*int(i["quantity"]) for i in items);disc=sum(float(i.get("discount_amount",0)) for i in items);tax=sum((float(i["unit_price"])*int(i["quantity"])-float(i.get("discount_amount",0)))*float(i.get("tax_rate",16))/100 for i in items);number=x.get("quotation_number") or "QT-"+datetime.now().strftime("%y%m%d-%H%M%S")
    cur=con.execute("INSERT INTO quotations(quotation_number,customer_name,payment_method,subtotal,discount_total,tax_total,grand_total) VALUES(?,?,?,?,?,?,?)",(number,x["customer_name"],x.get("payment_method","Cash"),subtotal,disc,tax,subtotal-disc+tax))
    for i in items:con.execute("INSERT INTO quotation_items(quotation_id,product_id,product_name,sku,unit_price,stock_at_quote,quantity,discount_amount,tax_rate,line_total) VALUES(?,?,?,?,?,?,?,?,?,?)",(cur.lastrowid,i.get("product_id"),i["product_name"],i.get("sku"),i["unit_price"],i.get("stock_at_quote",0),i["quantity"],i.get("discount_amount",0),i.get("tax_rate",16),i["unit_price"]*i["quantity"]))
    con.commit();con.close();return {"quotation_number":number},201

@app.route("/api/expenses",methods=["GET","POST"])
def expenses():
    con=db()
    if request.method=="GET":out=con.execute("SELECT * FROM expenses ORDER BY expense_date DESC").fetchall();con.close();return jsonify(many(out))
    x=body()
    if any(not x.get(k) for k in ("category","description","payment_method","amount")):con.close();return {"error":"category, description, payment_method and amount are required"},400
    cur=con.execute("INSERT INTO expenses(category,description,payment_method,amount,expense_date) VALUES(?,?,?,?,?)",(x["category"],x["description"],x["payment_method"],x["amount"],x.get("expense_date",datetime.now().date().isoformat())));con.commit();con.close();return {"id":cur.lastrowid},201

@app.get("/api/inventory/movements")
def movements():
    con=db();out=con.execute("SELECT m.*,p.name product_name,p.sku FROM inventory_movements m JOIN products p ON p.id=m.product_id ORDER BY m.created_at DESC").fetchall();con.close();return jsonify(many(out))

@app.get("/")
def home(): return send_from_directory(ROOT,"index.html")
@app.get("/<path:name>")
def site_files(name):
    if Path(name).suffix.lower() not in {".html",".js",".css",".jpg",".png",".ico"}: abort(404)
    return send_from_directory(ROOT,name)

def run():
    setup()
    import backup
    backup.start_daily()                     # one copy now, then every 24h
    try:
        from waitress import serve           # light pure-Python production server
    except ImportError:
        print("waitress not installed - using Flask's built-in server (pip install waitress)")
        app.run(host=config.HOST,port=config.PORT,debug=False,threaded=True)
        return
    print(f"ALIX running on http://{config.HOST}:{config.PORT}  (Ctrl+C to stop)")
    serve(app,host=config.HOST,port=config.PORT,threads=config.THREADS)

if __name__=="__main__":
    run()
