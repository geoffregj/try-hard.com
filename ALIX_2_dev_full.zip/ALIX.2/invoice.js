/* Invoice module entry point.
   The shared application file supplies the invoice table, filters, receipt
   preview, print action, and CSV export using the POS sales stored locally. */
(() => {
  const app = document.createElement("script");
  app.src = "app.js";
  app.defer = true;
  document.head.appendChild(app);
})();

