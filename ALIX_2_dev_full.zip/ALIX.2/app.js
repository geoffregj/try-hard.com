/* ALIX Power Enterprise POS — application script */
(() => {
  "use strict";

  const K = { products: "alixProducts", customers: "alixCustomers", sales: "alixSales", cart: "alixCart", held: "alixHeldSales" };
  const demoProducts = [];  // no built-in sample data: products come from the database
  const demoCustomers = [];

  const get = (key, fallback) => { try { const value = localStorage.getItem(key); return value ? JSON.parse(value) : fallback; } catch { return fallback; } };
  const set = (key, value) => localStorage.setItem(key, JSON.stringify(value));
  const nextNumber = (prefix, storageKey) => {
    const next = Number(localStorage.getItem(storageKey) || 0) + 1;
    localStorage.setItem(storageKey, String(next));
    return `${prefix}-${String(next).padStart(6, "0")}`;
  };
  const cash = value => "KSh " + Number(value || 0).toLocaleString("en-KE", { minimumFractionDigits: 0, maximumFractionDigits: 2 });
  const clean = value => String(value ?? "").replace(/[&<>"']/g, x => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[x]));
  
  const toast = (message, error = false) => {
    const node = document.createElement("div");
    node.textContent = message;
    node.style.cssText = `position:fixed;right:20px;bottom:20px;z-index:99999;padding:14px 18px;border-radius:10px;color:white;background:${error ? "#be3e3e" : "#118566"};box-shadow:0 10px 25px #10234344;font-weight:700`;
    document.body.append(node);
    setTimeout(() => node.remove(), 2800);
  };

  // Printable HTML receipt generator
  function invoiceDocument(sale) {
    const lines = (sale.items || []).map(i => `<tr><td>${clean(i.name)}</td><td>${i.quantity}</td><td>${cash(i.price)}</td><td>${cash(i.price * i.quantity)}</td></tr>`).join("") || "<tr><td colspan='4'>Item details unavailable.</td></tr>";
    const logo = new URL("IMG-20260803-WA0008~2.jpg", window.location.href).href;
    const subtotal = sale.subtotal ?? (sale.items || []).reduce((sum, i) => sum + i.price * i.quantity, 0);
    const discount = sale.discount || 0, tax = sale.tax || 0, received = sale.received ?? sale.total, change = sale.change ?? Math.max(0, received - sale.total);
    const balance = sale.total > received ? sale.total - received : 0;

    return `<!doctype html><html><head><title>Invoice ${clean(sale.invoice)}</title><style>body{font-family:Arial,sans-serif;color:#122746;max-width:720px;margin:30px auto;padding:0 20px}header{display:flex;align-items:center;gap:15px;border-bottom:2px solid #1f5cad;padding-bottom:15px}header img{width:64px;height:64px;object-fit:contain}h1{margin:0;color:#123b75}table{width:100%;border-collapse:collapse;margin:20px 0}th,td{padding:9px;border-bottom:1px solid #dce5f0;text-align:left}.total{font-size:16px;font-weight:bold;text-align:right}.muted{color:#637b9d}</style></head><body><header><img src="${logo}" alt="ALIX logo"><div><h1>ALIX Power Enterprise</h1><p class='muted'>Sales Invoice · ${clean(sale.invoice)}</p></div></header><p><b>Customer:</b> ${clean(sale.customer)}<br><b>Payment:</b> ${clean(sale.payment)}<br><b>Date:</b> ${new Date(sale.createdAt).toLocaleString("en-KE")}</p><table><thead><tr><th>Item</th><th>Qty</th><th>Unit Price</th><th>Total</th></tr></thead><tbody>${lines}</tbody></table><p class='total'>Subtotal: ${cash(subtotal)}<br>Discount: ${cash(discount)}<br>VAT: ${cash(tax)}<br>Grand Total: ${cash(sale.total)}<br>Amount Received: ${cash(received)}<br>${balance > 0 ? `Balance Due: ${cash(balance)}` : `Change: ${cash(change)}`}</p><p class='muted' style='text-align:center;margin-top:30px'>Thank you for your business!</p></body></html>`;
  }

  // Receipt Preview Modal (Print, Share, Email, Save PDF)
  function showReceiptPreviewModal(sale) {
    const existing = document.getElementById("receiptModalOverlay");
    if (existing) existing.remove();

    const subtotal = sale.subtotal ?? (sale.items || []).reduce((sum, i) => sum + i.price * i.quantity, 0);
    const discount = sale.discount || 0, tax = sale.tax || 0;
    const received = sale.received ?? sale.total;
    const balance = sale.total > received ? sale.total - received : 0;
    const change = sale.change ?? Math.max(0, received - sale.total);

    const overlay = document.createElement("div");
    overlay.id = "receiptModalOverlay";
    overlay.className = "modal-overlay open";
    overlay.innerHTML = `
      <div class="modal-card">
        <div class="modal-header">
          <h3>Receipt Preview</h3>
          <button class="modal-close" id="closeReceiptModal">&times;</button>
        </div>
        <div class="receipt-paper" id="receiptContent">
          <header>
            <div style="display:flex;align-items:center;justify-content:center;gap:10px"><img src="${new URL("IMG-20260803-WA0008~2.jpg", window.location.href).href}" alt="ALIX logo" style="width:58px;height:58px;object-fit:contain"><h2>${clean(get("alixSettings", {}).businessName || "ALIX POWER ENTERPRISE")}</h2></div>
              <p style="white-space:pre-line;margin:4px 0;font-size:12px;color:#555">${clean(get("alixSettings", {})[sale.documentType === "INVOICE" ? "invoiceHeader" : sale.documentType === "QUOTATION" ? "quotationHeader" : "receiptHeader"] || "")}</p>
            <p style="margin:4px 0;font-size:13px;color:#555">Official Sales Receipt</p>
            <p style="margin:2px 0;font-size:12px;color:#777">${sale.documentType === "RECEIPT" ? "Receipt" : clean(sale.documentType || "Invoice")}: <b>${clean(sale.documentType === "RECEIPT" ? (sale.receipt || sale.invoice) : sale.invoice)}</b> | ${new Date(sale.createdAt).toLocaleString("en-KE")}</p>
          </header>
          <div style="font-size:13px;margin-bottom:12px">
            <p style="margin:3px 0"><b>Customer:</b> ${clean(sale.customer)}</p>
            <p style="margin:3px 0"><b>Payment Method:</b> ${clean(sale.payment)}</p>
            ${sale.paymentReference ? `<p style="margin:3px 0"><b>Payment Details:</b> ${clean(sale.paymentReference)}</p>` : ""}
          </div>
          <table style="width:100%;font-size:12px;border-collapse:collapse;margin-bottom:12px">
            <thead>
              <tr style="border-bottom:1px solid #102343">
                <th style="text-align:left;padding:4px 0">Item</th>
                <th style="text-align:center;padding:4px 0">Qty</th>
                <th style="text-align:right;padding:4px 0">Price</th>
                <th style="text-align:right;padding:4px 0">Total</th>
              </tr>
            </thead>
            <tbody>
              ${(sale.items || []).map(i => `
                <tr style="border-bottom:1px dashed #e0e0e0">
                  <td style="padding:6px 0">${clean(i.name)}</td>
                  <td style="text-align:center;padding:6px 0">${i.quantity}</td>
                  <td style="text-align:right;padding:6px 0">${cash(i.price)}</td>
                  <td style="text-align:right;padding:6px 0">${cash(i.price * i.quantity)}</td>
                </tr>
              `).join("")}
            </tbody>
          </table>
          <div style="font-size:13px;line-height:1.6;border-top:1px dashed #102343;padding-top:8px">
            <div style="display:flex;justify-content:space-between"><span>Subtotal:</span><span>${cash(subtotal)}</span></div>
            <div style="display:flex;justify-content:space-between"><span>Discount:</span><span>${cash(discount)}</span></div>
            <div style="display:flex;justify-content:space-between"><span>VAT:</span><span>${cash(tax)}</span></div>
            <div style="display:flex;justify-content:space-between;font-weight:bold;font-size:15px;margin-top:4px;border-top:1px solid #102343;padding-top:4px">
              <span>Grand Total:</span><span>${cash(sale.total)}</span>
            </div>
            <div style="display:flex;justify-content:space-between;margin-top:4px"><span>Amount Received:</span><span>${cash(received)}</span></div>
            ${balance > 0 ? `<div style="display:flex;justify-content:space-between;color:#c54040;font-weight:bold"><span>Outstanding Balance:</span><span>${cash(balance)}</span></div>` : `<div style="display:flex;justify-content:space-between;color:#138b68;font-weight:bold"><span>Change Due:</span><span>${cash(change)}</span></div>`}
          </div>
          <p style="white-space:pre-line;text-align:center;font-size:11px;color:#777;margin-top:15px">${clean(get("alixSettings", {})[sale.documentType === "INVOICE" ? "invoiceFooter" : sale.documentType === "QUOTATION" ? "quotationFooter" : "receiptFooter"] || "Thank you for shopping with us!")}</p>
        </div>
        <div class="receipt-actions">
          <button class="btn-print-action" id="btnReceiptPrint">🖨️ Print</button>
          <button id="btnReceiptShare">🔗 Share</button>
          <button id="btnReceiptEmail">✉️ Email</button>
        </div>
      </div>
    `;

    document.body.appendChild(overlay);

    const closeBtn = document.getElementById("closeReceiptModal");
    closeBtn.onclick = () => overlay.remove();

    // i. Print Action
    document.getElementById("btnReceiptPrint").onclick = () => {
      const win = window.open("", "_blank", "width=800,height=700");
      const preview = document.getElementById("receiptContent");
      win.document.write(`<!doctype html><html><head><title>${clean(sale.documentType || "Receipt")} ${clean(sale.invoice)}</title><style>body{font-family:monospace;color:#102343;max-width:600px;margin:30px auto;padding:0 20px}.receipt-paper{background:#fff;border:1px dashed #b8cbe5;border-radius:10px;padding:20px}.receipt-paper header{text-align:center;display:block;margin-bottom:15px;border-bottom:1px dashed #ccc;padding-bottom:10px}.receipt-paper header h2{margin:0;font-size:20px}table{width:100%;border-collapse:collapse}</style></head><body>${preview ? preview.outerHTML : invoiceDocument(sale)}</body></html>`);
      win.document.close();
      win.onload = () => win.print();
    };

    // ii. Share Action
    document.getElementById("btnReceiptShare").onclick = async () => {
      const text = `Receipt ${sale.invoice}\nCustomer: ${sale.customer}\nTotal: ${cash(sale.total)}\nDate: ${new Date(sale.createdAt).toLocaleString()}`;
      if (navigator.share) {
        try {
          await navigator.share({ title: `Receipt ${sale.invoice}`, text: text });
          toast("Receipt shared successfully.");
        } catch (e) {
          toast("Share cancelled.");
        }
      } else {
        navigator.clipboard.writeText(text);
        toast("Receipt details copied to clipboard!");
      }
    };

    // iii. Email Action
    document.getElementById("btnReceiptEmail").onclick = () => {
      const customers = get(K.customers, demoCustomers);
      const customerObj = customers.find(c => c.name.toLowerCase() === (sale.customer || "").toLowerCase());
      const emails = [...new Set(customers.map(c => String(c.email || "").trim()).filter(Boolean))];
      const chooser = document.createElement("div");
      chooser.className = "modal-overlay open";
      chooser.innerHTML = `<div class="modal-card" style="max-width:440px"><div class="modal-header"><h3>Email Receipt</h3><button class="modal-close" data-close-email>&times;</button></div><label style="display:block;margin-bottom:8px">Select saved email<select id="receiptEmailSelect" style="display:block;margin-top:7px;width:100%;padding:11px 13px;border:1px solid #d9e2f0;border-radius:9px"><option value="">Choose an email address</option>${emails.map(email => `<option value="${clean(email)}" ${email === customerObj?.email ? "selected" : ""}>${clean(email)}</option>`).join("")}</select></label><label style="display:block;margin-bottom:16px">Email address<input id="receiptEmailInput" type="email" value="${clean(customerObj?.email || "")}" placeholder="Enter email address" style="display:block;margin-top:7px;width:100%"></label><div style="display:flex;justify-content:flex-end;gap:10px"><button data-close-email>Cancel</button><button class="primary" id="sendReceiptEmail">Send Email</button></div></div>`;
      document.body.appendChild(chooser);
      const select = chooser.querySelector("#receiptEmailSelect");
      const input = chooser.querySelector("#receiptEmailInput");
      select.addEventListener("change", () => { input.value = select.value; input.focus(); });
      chooser.querySelectorAll("[data-close-email]").forEach(button => button.onclick = () => chooser.remove());
      chooser.querySelector("#sendReceiptEmail").onclick = () => {
        const email = input.value.trim();
        if (!email || !input.checkValidity()) return toast("Enter a valid customer email address.", true);
        const subject = encodeURIComponent(`Receipt ${sale.invoice} - ALIX Power Enterprise`);
        const body = encodeURIComponent(`Dear ${sale.customer},\n\nThank you for your business. Here are your transaction details:\n\nInvoice: ${sale.invoice}\nDate: ${new Date(sale.createdAt).toLocaleString()}\nTotal: ${cash(sale.total)}\nPayment Method: ${sale.payment}\n\nWarm regards,\nALIX Power Enterprise`);
        chooser.remove();
        window.location.href = `mailto:${email}?subject=${subject}&body=${body}`;
        toast(`Opened email client for ${email}`);
      };
    };
  }

  function setupDashboard() {
    const date = document.getElementById("currentDate");
    if (date) date.textContent = new Date().toLocaleDateString("en-KE", { weekday: "long", year: "numeric", month: "long", day: "numeric" });
    const products = get(K.products, demoProducts), customers = get(K.customers, demoCustomers), sales = get(K.sales, []);
    const today = new Date().toDateString();
    const total = sales.filter(s => new Date(s.createdAt).toDateString() === today).reduce((n, s) => n + s.total, 0);
    const metrics = document.querySelectorAll(".metrics article h2");
    if (metrics.length >= 4) {
      metrics[0].textContent = cash(total);
      metrics[1].textContent = products.length; metrics[2].textContent = customers.length;
      metrics[3].textContent = products.filter(p => p.stock <= (p.low || 5)).length;
      const notes = document.querySelectorAll(".metrics article small");
      if (notes.length >= 4) {
        const cats = new Set(products.map(p => p.category).filter(Boolean)).size;
        notes[1].textContent = `Across ${cats} categor${cats === 1 ? "y" : "ies"}`;
        notes[2].textContent = "Registered customers";
        notes[3].textContent = metrics[3].textContent === "0" ? "Everything in stock" : "Needs attention";
        const yesterday = new Date(Date.now() - 864e5).toDateString();
        const yTotal = sales.filter(s => new Date(s.createdAt).toDateString() === yesterday).reduce((n, s) => n + s.total, 0);
        notes[0].textContent = yTotal > 0 ? `${total >= yTotal ? "↑" : "↓"} ${Math.abs((total - yTotal) / yTotal * 100).toFixed(1)}% from yesterday` : "Today";
      }
    }
    const top = document.querySelector(".top-products");
    if (top) {
      const tally = {};
      sales.forEach(s => (s.items || []).forEach(i => { tally[i.name] = (tally[i.name] || 0) + Number(i.price || 0) * Number(i.quantity || 0); }));
      const best = Object.entries(tally).sort((a, b) => b[1] - a[1]).slice(0, 3);
      top.innerHTML = best.length ? best.map(([n, v]) => `<li>${clean(n)} <strong>${cash(v)}</strong></li>`).join("") : "<li>No sales yet</li>";
    }
    document.querySelectorAll(".metrics article").forEach(card => {
      const label = card.querySelector("p")?.textContent.toLowerCase() || "";
      const destination = label.includes("sales") ? "invoice.html"
        : label.includes("product") && !label.includes("low") ? "products.html"
        : label.includes("customer") ? "customers.html"
        : label.includes("low stock") ? "inventory.html" : "";
      if (!destination) return;
      card.style.cursor = "pointer";
      card.title = "Open related module";
      card.addEventListener("click", () => { window.location.href = destination; });
    });

    const rows = document.getElementById("recentTransactions");
    if (rows) {
      rows.innerHTML = sales.length ? sales.slice(0, 6).map(s => `
        <tr style="cursor:pointer" data-invoice-id="${s.invoice}">
          <td><b style="color:#1f5cad;text-decoration:underline">${clean(s.invoice)}</b></td>
          <td>${clean(s.customer)}</td>
          <td>${clean(s.payment)}</td>
          <td>${cash(s.total)}</td>
          <td>${new Date(s.createdAt).toLocaleTimeString("en-KE", { hour: "2-digit", minute: "2-digit" })}</td>
          <td><span style="background:#e6f4ea;color:#137333;padding:3px 8px;border-radius:12px;font-size:12px;font-weight:600">View Receipt</span></td>
        </tr>`).join("") : "<tr><td colspan='6'>No completed transactions yet.</td></tr>";

      rows.addEventListener("click", e => {
        const tr = e.target.closest("[data-invoice-id]");
        if (!tr) return;
        const sale = sales.find(s => s.invoice === tr.dataset.invoiceId);
        if (sale) showReceiptPreviewModal(sale);
      });
    }
  }

  function setupPOS() {
    const grid = document.getElementById("productsGrid");
    if (!grid) return;
    const posSettings = get("alixSettings", {});
    const registerLabel = document.getElementById("posRegisterLabel");
    if (registerLabel) registerLabel.textContent = `Register: ${posSettings.registerName || "Main Counter"} · Cashier: ${posSettings.cashierName || "Admin"}`;
    
    let cart = get(K.cart, []).map(item => ({ ...item, discount: Number(item.discount || 0), taxRate: Number(item.taxRate ?? 0) }));
    let category = "All", search = "", customer = null, paymentReceived = 0;
    const products = () => get(K.products, demoProducts);

    const totals = () => {
      const subtotal = cart.reduce((n, i) => n + i.price * i.quantity, 0);
      const discount = cart.reduce((n, i) => n + Math.min(i.price * i.quantity, Number(i.discount || 0)), 0);
      const tax = cart.reduce((n, i) => n + Math.max(0, (i.price * i.quantity - Math.min(i.price * i.quantity, Number(i.discount || 0))) * (Number(i.taxRate ?? 16) / 100)), 0);
      return { subtotal, discount, tax, total: subtotal - discount + tax };
    };

    const renderProducts = () => {
      const list = products().filter(p => (category === "All" || p.category === category) && (`${p.name} ${p.sku}`.toLowerCase().includes(search)));
      grid.innerHTML = list.map(p => `
        <article class="panel" data-product="${p.id}" style="margin:0;padding:16px;cursor:pointer">
          <b>${clean(p.name)}</b>
          <small style="display:block;margin:7px 0;color:#748bad">${clean(p.sku)} · ${p.stock} available</small>
          <strong>${cash(p.price)}</strong>
          ${p.stock < 1 ? "<small style='display:block;color:#be3e3e'>Out of stock</small>" : ""}
        </article>`).join("") || "<p>No products found.</p>";
    };

    const renderCart = () => {
      const list = document.getElementById("cartItemsList"); if (!list) return;
      list.innerHTML = cart.length ? cart.map(i => `
        <div style="padding:10px 0;border-bottom:1px solid #e4eaf3">
          <b>${clean(i.name)}</b>
          <small style="display:block;color:#748bad">${cash(i.price)} each · original line price ${cash(i.price * i.quantity)}</small>
          <div style="display:flex;justify-content:space-between;margin-top:7px">
            <span><button data-qty="-1" data-id="${i.id}">−</button> ${i.quantity} <button data-qty="1" data-id="${i.id}">+</button></span>
            <button data-remove="${i.id}" aria-label="Remove item">&times;</button>
          </div>
          <div style="display:flex;gap:8px;margin-top:8px">
            <label style="font-size:12px">Discount KSh<input data-discount="${i.id}" type="number" step="0.1" min="0" max="${i.price * i.quantity}" value="${i.discount || 0}" style="width:78px;margin-left:3px"></label>
            <label style="font-size:12px">VAT %<input data-tax="${i.id}" type="number" step="0.1" min="0" max="100" value="${i.taxRate ?? 16}" style="width:58px;margin-left:3px"></label>
          </div>
        </div>`).join("") : "<p class='empty-cart-msg'>No items in cart</p>";

      const t = totals();
      document.getElementById("subtotal").textContent = cash(t.subtotal);
      document.getElementById("discount").textContent = cash(t.discount);
      document.getElementById("tax").textContent = cash(t.tax);
      document.getElementById("grandTotal").textContent = cash(t.total);
      
      const totalPanel = document.querySelector(".totals-section");
      let paymentInfo = document.getElementById("paymentBalanceInfo");
      if (!paymentInfo) { paymentInfo = document.createElement("div"); paymentInfo.id = "paymentBalanceInfo"; paymentInfo.style.marginTop = "10px"; totalPanel.append(paymentInfo); }
      const difference = paymentReceived - t.total;
      paymentInfo.innerHTML = paymentReceived ? `<p style="display:flex;justify-content:space-between"><span>Amount received</span><b>${cash(paymentReceived)}</b></p><p style="display:flex;justify-content:space-between"><span>${difference >= 0 ? "Change" : "Balance due"}</span><b style="color:${difference >= 0 ? "#138b68" : "#c54040"}">${cash(Math.abs(difference))}</b></p>` : "<small>Enter an amount at checkout to see balance or change.</small>";
      
      document.getElementById("checkoutBtn").disabled = !cart.length;
    };

    const persist = () => set(K.cart, cart);

    const add = id => {
      const p = products().find(x => x.id === id); if (!p || p.stock < 1) return toast("This product is out of stock.", true);
      const item = cart.find(x => x.id === id);
      if (item) { if (item.quantity >= p.stock) return toast("Cannot exceed available stock.", true); item.quantity++; }
      else cart.push({ id: p.id, name: p.name, price: p.price, quantity: 1, discount: 0, taxRate: 0 });
      persist(); renderCart(); toast(p.name + " added to cart.");
    };

    grid.addEventListener("click", e => { const card = e.target.closest("[data-product]"); if (card) add(card.dataset.product); });

    // 2a. Product Search Autocomplete
    const productSearchInput = document.getElementById("productSearch");
    const productDropdown = document.getElementById("productAutocomplete");

    if (productSearchInput && productDropdown) {
      productSearchInput.addEventListener("input", e => {
        search = e.target.value.trim().toLowerCase();
        renderProducts();
        if (!search) {
          productDropdown.classList.remove("active");
          return;
        }
        const matches = products().filter(p => `${p.name} ${p.sku}`.toLowerCase().includes(search));
        if (!matches.length) {
          productDropdown.classList.remove("active");
          return;
        }
        productDropdown.innerHTML = matches.slice(0, 7).map(p => `
          <div class="autocomplete-item" data-auto-p="${p.id}">
            <div><strong>${clean(p.name)}</strong> <small>(${clean(p.sku)})</small></div>
            <div><b style="color:#2965bd">${cash(p.price)}</b> <small style="margin-left:6px">${p.stock} in stock</small></div>
          </div>
        `).join("");
        productDropdown.classList.add("active");
      });

      productDropdown.addEventListener("click", e => {
        const item = e.target.closest("[data-auto-p]");
        if (!item) return;
        const pId = item.dataset.auto-p;
        const p = products().find(x => x.id === pId);
        if (p) {
          productSearchInput.value = p.name;
          search = p.name.toLowerCase();
          renderProducts();
          add(pId);
        }
        productDropdown.classList.remove("active");
      });
    }

    // 2a & 2c. Customer Search Autocomplete
    const customerInput = document.getElementById("customerSearchInput");
    const customerDropdown = document.getElementById("customerAutocomplete");

    const selectCustomer = c => {
      customer = c;
      document.getElementById("selectedCustomer").textContent = c ? c.name : "Walk-in Customer";
      if (customerInput) customerInput.value = c ? c.name : "";
      if (customerDropdown) customerDropdown.classList.remove("active");
      toast(c ? `Customer selected: ${c.name}` : "Walk-in Customer selected.");
    };

    if (customerInput && customerDropdown) {
      customerInput.addEventListener("input", e => {
        const q = e.target.value.trim().toLowerCase();
        const customersList = get(K.customers, demoCustomers);
        const matches = customersList.filter(c => `${c.name} ${c.phone}`.toLowerCase().includes(q));
        
        let html = matches.map(c => `
          <div class="autocomplete-item" data-auto-c="${c.id}">
            <div><strong>${clean(c.name)}</strong></div>
            <div><small>${clean(c.phone || "")}</small></div>
          </div>
        `).join("");

        html += `
          <div class="autocomplete-item" data-add-new-c="true" style="background:#f0f6ff;color:#1f5cad;font-weight:bold">
            + Add "${clean(e.target.value)}" as New Customer
          </div>
        `;

        customerDropdown.innerHTML = html;
        customerDropdown.classList.add("active");
      });

      customerDropdown.addEventListener("click", e => {
        const item = e.target.closest(".autocomplete-item");
        if (!item) return;

        if (item.dataset.autoC) {
          const c = get(K.customers, demoCustomers).find(x => x.id === item.dataset.autoC);
          if (c) selectCustomer(c);
        } else if (item.dataset.addNewC) {
          const name = customerInput.value.trim() || prompt("Enter Customer Name:");
          if (!name) return;
          const phone = prompt("Enter Phone Number:", "+254 ");
          const allC = get(K.customers, demoCustomers);
          const newC = { id: "c" + Date.now(), name, phone: phone || "", email: "", credit: 0, points: 0 };
          allC.push(newC);
          set(K.customers, allC);
          selectCustomer(newC);
          toast(`Customer ${name} created.`);
        }
      });
    }

    document.addEventListener("click", e => {
      if (!e.target.closest(".pos-toolbar")) {
        productDropdown?.classList.remove("active");
        customerDropdown?.classList.remove("active");
      }
    });

    document.getElementById("changeCustomer")?.addEventListener("click", () => {
      const allC = get(K.customers, demoCustomers);
      const choice = prompt("Select Customer:\n" + allC.map((c, i) => `${i + 1}. ${c.name} (${c.phone})`).join("\n") + "\n\nEnter number or leave empty for Walk-in:");
      if (!choice) { selectCustomer(null); return; }
      const idx = Number(choice) - 1;
      if (allC[idx]) selectCustomer(allC[idx]);
    });

    document.getElementById("paymentMethodSelector")?.addEventListener("click", e => {
      const btn = e.target.closest(".btn-pm");
      if (!btn) return;
      document.querySelectorAll("#paymentMethodSelector .btn-pm").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      const method = btn.dataset.method;
      const input = document.getElementById("selectedPaymentMethodInput");
      if (input) input.value = method;
      toast(`Payment method set to ${method}`);
    });

    document.querySelectorAll(".product-tabs button").forEach(b => b.addEventListener("click", () => {
      document.querySelector(".product-tabs .active")?.classList.remove("active");
      b.classList.add("active");
      category = b.textContent.trim();
      renderProducts();
    }));

    document.getElementById("cartItemsList").addEventListener("click", e => {
      const id = e.target.dataset.id || e.target.dataset.remove; if (!id) return;
      if (e.target.dataset.remove) cart = cart.filter(i => i.id !== id);
      else {
        const i = cart.find(x => x.id === id), p = products().find(x => x.id === id);
        i.quantity += Number(e.target.dataset.qty);
        if (i.quantity < 1) cart = cart.filter(x => x.id !== id);
        else if (i.quantity > p.stock) { i.quantity = p.stock; toast("Cannot exceed available stock.", true); }
      }
      persist(); renderCart();
    });

    // 2b. Edit discount & VAT with decimal precision
    document.getElementById("cartItemsList").addEventListener("input", e => {
      const discId = e.target.dataset.discount;
      const taxId = e.target.dataset.tax;
      if (discId) {
        const item = cart.find(i => i.id === discId);
        if (item) item.discount = Math.max(0, Math.min(item.price * item.quantity, parseFloat(e.target.value) || 0));
      }
      if (taxId) {
        const item = cart.find(i => i.id === taxId);
        if (item) item.taxRate = Math.max(0, Math.min(100, parseFloat(e.target.value) || 0));
      }
      persist(); renderCart();
    });

    document.getElementById("clearCartBtn")?.addEventListener("click", () => {
      if (cart.length && confirm("Clear all items from this sale?")) { cart = []; paymentReceived = 0; persist(); renderCart(); }
    });

    document.getElementById("holdSaleBtn")?.addEventListener("click", () => {
      if (!cart.length) return toast("Cart is empty.", true);
      const held = get(K.held, []);
      held.unshift({ id: Date.now(), cart, customer: customer?.name || "Walk-in Customer" });
      set(K.held, held); cart = []; persist(); renderCart(); toast("Sale held.");
    });

    document.getElementById("heldSalesBtn")?.addEventListener("click", () => {
      const held = get(K.held, []);
      if (!held.length) return toast("No held sales.");
      const pick = Number(prompt(held.map((s, n) => `${n + 1}. ${s.customer} (${s.cart.length} items)`).join("\n") + "\n\nEnter sale number:")) - 1;
      if (!held[pick]) return;
      cart = held[pick].cart; held.splice(pick, 1); set(K.held, held); persist(); renderCart(); toast("Held sale restored.");
    });

    document.getElementById("shiftBtn")?.addEventListener("click", e => {
      const open = e.currentTarget.textContent.includes("Open");
      const settings = get("alixSettings", {});
      e.currentTarget.textContent = open ? "Close Shift" : "Open Shift";
      toast(open ? `Shift opened: ${settings.registerName || "Main Counter"} · Cashier: ${settings.cashierName || "Admin"}` : "Cashier shift closed.");
      const label = document.getElementById("posRegisterLabel");
      if (label) label.textContent = `Register: ${settings.registerName || "Main Counter"} · Cashier: ${settings.cashierName || "Admin"}`;
    });

    // 2c, 2d, 2e, 2f. Checkout & Print Flow with Payment Dropdown, Walk-in Balance Account Creation, and Receipt Modal
    document.getElementById("checkoutBtn").addEventListener("click", () => {
      if (!cart.length) return;
      const t = totals();

      // Payment Method Selector click handler
      document.getElementById("paymentMethodSelector")?.addEventListener("click", e => {
        const btn = e.target.closest(".btn-pm");
        if (!btn) return;
        document.querySelectorAll("#paymentMethodSelector .btn-pm").forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        const method = btn.dataset.method;
        const input = document.getElementById("selectedPaymentMethodInput");
        if (input) input.value = method;
        toast(`Payment method set to ${method}`);
      });

      // 2c. Real-time Payment Method Selection from selector bar
      const payment = document.getElementById("selectedPaymentMethodInput")?.value || "Cash";
      const paymentReference = document.getElementById("paymentReferenceInput")?.value.trim() || "";
      const documentType = document.getElementById("documentTypeInput")?.value || "RECEIPT";

      const receivedInput = prompt(`Amount Received (${cash(t.total)} due):`, String(Math.ceil(t.total)));
      if (receivedInput === null) return;
      const received = parseFloat(receivedInput);
      if (!Number.isFinite(received) || received < 0) return toast("Enter a valid received amount.", true);

      paymentReceived = received; renderCart();
      const allP = products();
      for (const item of cart) {
        const p = allP.find(x => x.id === item.id);
        if (!p || p.stock < item.quantity) return toast(item.name + " no longer has enough stock.", true);
      }

      // 2e. Outstanding Balance handling
      let activeCustomer = customer;
      const balanceDue = t.total - received;
      if (balanceDue > 0) {
        if (!activeCustomer || activeCustomer.name === "Walk-in Customer") {
          const createAcc = confirm(`This walk-in customer has an outstanding balance of ${cash(balanceDue)}. Would you like to create a customer account to track this balance?`);
          if (createAcc) {
            const newName = prompt("Enter Customer Name for Account Creation:");
            if (newName) {
              const newPhone = prompt("Enter Phone Number:") || "";
              const newEmail = prompt("Enter Email Address:") || "";
              const allC = get(K.customers, demoCustomers);
              activeCustomer = { id: "c" + Date.now(), name: newName, phone: newPhone, email: newEmail, credit: balanceDue, points: 0 };
              allC.push(activeCustomer);
              set(K.customers, allC);
              toast(`Account created for ${newName} with credit balance of ${cash(balanceDue)}.`);
            }
          }
        } else {
          const allC = get(K.customers, demoCustomers);
          const cIndex = allC.findIndex(c => c.id === activeCustomer.id);
          if (cIndex !== -1) {
            allC[cIndex].credit = Number(allC[cIndex].credit || 0) + balanceDue;
            set(K.customers, allC);
            toast(`Updated ${activeCustomer.name}'s credit balance by +${cash(balanceDue)}.`);
          }
        }
      }

      // Deduct stock
      cart.forEach(item => { const pr = allP.find(p => p.id === item.id); if (pr) pr.stock -= item.quantity; });
      set(K.products, allP);

      // Save sale
      const sales = get(K.sales, []);
      const invoice = nextNumber("INV", "alixInvoiceSequence");
      const receipt = nextNumber("RCPT", "alixReceiptSequence");
      const saleObj = {
        invoice,
        receipt,
        documentType,
        customer: activeCustomer ? activeCustomer.name : "Walk-in Customer",
        payment,
        paymentReference,
        total: t.total,
        subtotal: t.subtotal,
        discount: t.discount,
        tax: t.tax,
        received,
        change: Math.max(0, received - t.total),
        items: [...cart],
        createdAt: new Date().toISOString()
      };

      sales.unshift(saleObj);
      set(K.sales, sales);

      // Reset cart
      cart = []; customer = null; persist();
      document.getElementById("selectedCustomer").textContent = "Walk-in Customer";
      if (document.getElementById("paymentReferenceInput")) document.getElementById("paymentReferenceInput").value = "";
      if (customerInput) customerInput.value = "";
      renderProducts(); renderCart(); paymentReceived = 0;

      // 2f. Show Receipt Preview Modal after sale!
      showReceiptPreviewModal(saleObj);
    });

    document.addEventListener("keydown", e => {
      if (e.key === "F2") { e.preventDefault(); productSearchInput?.focus(); }
      if (e.key === "F4") { e.preventDefault(); customerInput?.focus(); }
      if (e.key === "F8") { e.preventDefault(); document.getElementById("holdSaleBtn")?.click(); }
      if (e.key === "F9") { e.preventDefault(); document.getElementById("checkoutBtn")?.click(); }
    });

    renderProducts(); renderCart();
  }

  function setupModules() {
    const table = document.querySelector("tbody[id]");
    const search = document.querySelector(".toolbar input");
    const addButton = document.querySelector("header .primary");
    const title = document.querySelector("h1")?.textContent;

    const records = key => get(key, []);
    const saveRecords = (key, data) => set(key, data);
    const render = (items, row) => { if (table) table.innerHTML = items.length ? items.map(row).join("") : "<tr><td colspan='9'>No records found.</td></tr>"; };

    // 3. Products Module: Edit button, remove category column
    if (title === "Products") {
      const me = () => window.ALIX_USER || {};
      const canAdd = () => ["admin", "manager", "customer"].includes(me().role);
      let ownerFilter = "";
      const show = () => {
        const q = (search?.value || "").toLowerCase();
        const all = get(K.products, []);
        const showOwner = all.some(p => p.owner_id !== me().id);      // someone else's products are visible to this user
        const headRow = document.querySelector("table thead tr");
        const th = headRow?.querySelector("th.owner-col");
        if (showOwner && headRow && !th) { const h = document.createElement("th"); h.className = "owner-col"; h.textContent = "Owner"; headRow.insertBefore(h, headRow.children[1]); }
        if (!showOwner && th) th.remove();
        let sel = document.getElementById("ownerFilter");
        if (showOwner && !sel && search) {
          sel = document.createElement("select"); sel.id = "ownerFilter"; sel.title = "Filter by owner"; sel.style.cssText = "margin-left:8px;padding:8px;border-radius:8px";
          sel.addEventListener("change", () => { ownerFilter = sel.value; show(); }); search.after(sel);
        }
        if (sel) {
          const owners = [...new Set(all.map(p => p.owner_name).filter(Boolean))].sort();
          if (sel.dataset.n !== String(owners.length)) { sel.innerHTML = `<option value="">All owners</option>` + owners.map(o => `<option>${clean(o)}</option>`).join(""); sel.dataset.n = owners.length; sel.value = ownerFilter; }
        }
        const items = all.filter(p => (!ownerFilter || p.owner_name === ownerFilter) && `${p.name} ${p.sku} ${p.owner_name}`.toLowerCase().includes(q)).sort((a, b) => a.name.localeCompare(b.name));
        render(items, p => `
          <tr>
            <td><b>${clean(p.name)}</b></td>
            ${showOwner ? `<td>${clean(p.owner_name || "—")}</td>` : ""}
            <td>${clean(p.sku)}</td>
            <td>${cash(p.price)}</td>
            <td>${p.stock}</td>
            <td>${p.stock <= (p.low || 5) ? "<span style='color:#d74b4b;font-weight:bold'>Low stock</span>" : "Active"}</td>
            <td>${p.canEdit ? `<button class="btn-edit-product" data-edit-p="${p.id}">Edit</button>` : "<span style='color:#7890b2'>View only</span>"}</td>
          </tr>`);
        if (!items.length && table) table.innerHTML = `<tr><td colspan="9">${all.length ? "No products match." : canAdd() ? "No products yet. Click “+ Add Product” to add your first one." : "No products to show."}</td></tr>`;
      };

      addButton?.addEventListener("click", () => {
        if (!canAdd()) return toast("Your account cannot add products.", true);
        const name = prompt("Product name:"); if (!name) return;
        const sku = prompt("SKU / code:", "SKU-" + Date.now().toString().slice(-4)) || "SKU-" + Date.now().toString().slice(-4);
        const category = prompt("Category:", "General") || "General";
        const price = parseFloat(prompt("Selling price (KSh):"));
        const stock = parseInt(prompt("Opening stock:"), 10);
        const low = parseInt(prompt("Low stock alert when stock reaches:", "5"), 10);
        if (!Number.isFinite(price) || !Number.isFinite(stock) || !Number.isFinite(low) || low < 0 || price < 0 || stock < 0) return toast("Enter valid numerical values.", true);
        const items = get(K.products, []);
        items.push({ id: "p" + Date.now(), name, sku, category, price, stock, low, owner_id: me().id, owner_name: me().business_name || me().full_name, canEdit: true });
        saveRecords(K.products, items); show(); toast("Product added.");
      });

      search?.addEventListener("input", show);
      document.addEventListener("alix:products-changed", show);

      table?.addEventListener("click", e => {
        const editId = e.target.dataset.editP;
        if (!editId) return;
        const items = get(K.products, []);
        const p = items.find(x => x.id === editId);
        if (!p) return;
        if (!p.canEdit) return toast("You can only view this product.", true);

        const newName = prompt("Product Name:", p.name); if (!newName) return;
        const newSku = prompt("SKU:", p.sku) || p.sku;
        const newPrice = parseFloat(prompt("Price (KSh):", p.price));
        if (!Number.isFinite(newPrice) || newPrice < 0) return toast("Invalid price.", true);
        const newStock = parseInt(prompt("Stock on hand:", p.stock), 10);
        if (!Number.isFinite(newStock) || newStock < 0) return toast("Invalid stock.", true);

        p.name = newName; p.sku = newSku; p.price = newPrice; p.stock = newStock;
        saveRecords(K.products, items); show(); toast(`Updated ${p.name}`);
      });
      show();
    }

    // 4. Customers Module: Edit button, Loyalty Points management
    if (title === "Customers") {
      const show = () => {
        const q = (search?.value || "").toLowerCase();
        render(get(K.customers, demoCustomers).filter(c => `${c.name} ${c.phone}`.toLowerCase().includes(q)), c => `
          <tr>
            <td><b>${clean(c.name)}</b></td>
            <td>${clean(c.phone)}</td>
            <td>${clean(c.email || "—")}</td>
            <td><b>${c.points || 0} pts</b></td>
            <td>${cash(c.credit || 0)}</td>
            <td>
              <button class="btn-edit-customer" data-edit-c="${c.id}">Edit</button>
              <button class="btn-payment-customer" data-payment-c="${c.id}">Make Payment</button>
              <button class="btn-points-customer" data-add-pts="${c.id}" style="font-size:12px;padding:4px 8px;margin-left:4px">+ Points</button>
            </td>
          </tr>`);
      };

      addButton?.addEventListener("click", () => {
        const name = prompt("Customer name:"); const phone = prompt("Phone number:"); if (!name || !phone) return;
        const email = prompt("Email address:") || "";
        const pointsInput = prompt("Initial Loyalty Points:", "0");
        const points = parseInt(pointsInput, 10) || 0;
        const all = get(K.customers, demoCustomers);
        all.push({ id: "c" + Date.now(), name, phone, email, points, credit: 0 });
        saveRecords(K.customers, all); show(); toast(`Customer ${name} added with ${points} points.`);
      });

      search?.addEventListener("input", show);

      table?.addEventListener("click", e => {
        const editId = e.target.dataset.editC;
        const ptsId = e.target.dataset.addPts;
        const paymentId = e.target.dataset.paymentC;
        const customers = get(K.customers, demoCustomers);

        if (editId) {
          const c = customers.find(x => x.id === editId);
          if (!c) return;

          const name = prompt("Customer Name:", c.name); if (!name) return;
          const phone = prompt("Phone Number:", c.phone) || c.phone;
          const email = prompt("Email:", c.email || "") || c.email;
          const pointsInput = prompt("Loyalty Points:", c.points || 0);
          const points = parseInt(pointsInput, 10);

          c.name = name; c.phone = phone; c.email = email;
          if (Number.isFinite(points)) c.points = points;

          saveRecords(K.customers, customers); show(); toast(`Updated ${c.name}`);
        } else if (ptsId) {
          const c = customers.find(x => x.id === ptsId);
          if (!c) return;

          const addInput = prompt(`Add Loyalty Points for ${c.name} (Current: ${c.points || 0} pts):`, "50");
          if (addInput === null) return;
          const addPts = parseInt(addInput, 10);
          if (!Number.isFinite(addPts) || addPts === 0) return toast("Invalid points value.", true);

          c.points = Math.max(0, Number(c.points || 0) + addPts);
          saveRecords(K.customers, customers); show(); toast(`Added ${addPts > 0 ? '+' + addPts : addPts} loyalty points to ${c.name}. Total: ${c.points} pts`);
        } else if (paymentId) {
          const c = customers.find(x => x.id === paymentId);
          if (!c) return;
          const amount = parseFloat(prompt(`Payment received from ${c.name} (Balance: ${cash(c.credit || 0)}):`, "0"));
          if (!Number.isFinite(amount) || amount <= 0) return toast("Enter a valid payment amount.", true);
          let remaining = amount;
          const sales = get(K.sales, []).filter(s => s.customer === c.name && Number(s.total || 0) > Number(s.received || 0))
            .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
          sales.forEach(s => {
            const due = Number(s.total || 0) - Number(s.received || 0);
            const applied = Math.min(remaining, due);
            s.received = Number(s.received || 0) + applied;
            remaining -= applied;
          });
          c.credit = Math.max(0, Number(c.credit || 0) - (amount - remaining));
          set(K.sales, get(K.sales, []).map(s => sales.find(updated => updated.invoice === s.invoice) || s));
          saveRecords(K.customers, customers); show(); toast(`Payment recorded for ${c.name}. Balance: ${cash(c.credit)}`);
        }
      });
      show();
    }

    // 5. Suppliers Module: Total Amount (Amount Paid - Balance) and Edit button
    if (title === "Suppliers") {
      const demoSuppliers = [];

      const show = () => {
        const q = (search?.value || "").toLowerCase();
        const suppliersList = records("alixSuppliers");
        const list = suppliersList.length ? suppliersList : demoSuppliers;
        if (!suppliersList.length) saveRecords("alixSuppliers", demoSuppliers);

        render(list.filter(s => `${s.name} ${s.phone}`.toLowerCase().includes(q)), s => {
          const paid = Number(s.paid || 0);
          const balance = Number(s.balance || 0);
          const totalAmount = Number(s.total || paid + balance);
          return `
            <tr>
              <td><b>${clean(s.name)}</b></td>
              <td>${clean(s.contact || "—")}</td>
              <td>${clean(s.phone || "—")}</td>
              <td>${clean(s.email || "—")}</td>
              <td>${cash(paid)}</td>
              <td style="color:${balance > 0 ? '#c54040' : 'inherit'}">${cash(balance)}</td>
              <td><b>${cash(totalAmount)}</b></td>
              <td><button class="btn-edit-supplier" data-edit-s="${s.id}">Edit</button></td>
            </tr>`;
        });
      };

      addButton?.addEventListener("click", () => {
        const name = prompt("Supplier name:"); if (!name) return;
        const contact = prompt("Contact Person:") || "";
        const phone = prompt("Supplier phone:") || "";
        const email = prompt("Email:") || "";
        const total = parseFloat(prompt("Total (KSh):", "0")) || 0;
        const paid = parseFloat(prompt("Amount Paid (KSh):", "0")) || 0;
        const balance = Math.max(0, total - paid);

        const all = records("alixSuppliers").length ? records("alixSuppliers") : demoSuppliers;
        all.push({ id: "s" + Date.now(), name, contact, phone, email, total, paid, balance });
        saveRecords("alixSuppliers", all); show(); toast("Supplier added.");
      });

      search?.addEventListener("input", show);

      table?.addEventListener("click", e => {
        const editId = e.target.dataset.editS;
        if (!editId) return;
        const all = records("alixSuppliers").length ? records("alixSuppliers") : demoSuppliers;
        const s = all.find(x => String(x.id) === String(editId));
        if (!s) return;

        const name = prompt("Supplier Name:", s.name); if (!name) return;
        const contact = prompt("Contact Person:", s.contact || "") || "";
        const phone = prompt("Phone Number:", s.phone || "") || "";
        const email = prompt("Email:", s.email || "") || "";
        const total = parseFloat(prompt("Total (KSh):", s.total || 0));
        const paid = parseFloat(prompt("Amount Paid (KSh):", s.paid || 0));

        s.name = name; s.contact = contact; s.phone = phone; s.email = email;
        if (Number.isFinite(total)) s.total = total;
        if (Number.isFinite(paid)) s.paid = paid;
        s.balance = Math.max(0, Number(s.total || 0) - Number(s.paid || 0));

        saveRecords("alixSuppliers", all); show(); toast(`Updated supplier ${s.name}`);
      });
      show();
    }

    // 6. Quotation Module: Save Quotation as PDF and Edit button
    if (title === "Quotations") {
      let quoteItems = [];
      let editingQuoteNumber = null;
      const productSelect = document.getElementById("quotationProduct");
      const customerInput = document.getElementById("quotationCustomer");
      const paymentSelect = document.getElementById("quotationPayment");
      const itemRows = document.getElementById("quotationItems");
      const quoteSearch = document.getElementById("quotationSearch");
      const quoteStatus = document.getElementById("quotationStatus");
      const number = () => nextNumber("QTN", "alixQuotationSequence");
      let quoteNumber = number();
      const products = () => get(K.products, demoProducts);

      const quoteTotals = () => {
        const subtotal = quoteItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
        const discount = quoteItems.reduce((sum, item) => sum + Math.min(item.price * item.quantity, item.discount), 0);
        const tax = quoteItems.reduce((sum, item) => sum + (item.price * item.quantity - Math.min(item.price * item.quantity, item.discount)) * item.taxRate / 100, 0);
        return { subtotal, discount, tax, total: subtotal - discount + tax };
      };

      if (productSelect) productSelect.innerHTML = "<option value=''>Select product</option>" + products().map(p => `<option value="${p.id}">${clean(p.name)} — ${clean(p.sku)}</option>`).join("");

      const renderBuilder = () => {
        if (!itemRows) return;
        itemRows.innerHTML = quoteItems.length ? quoteItems.map((item, idx) => `
          <tr draggable="true" data-q-index="${idx}" style="cursor:grab">
            <td style="font-weight:bold;color:#1f5cad"><span style="cursor:grab;margin-right:4px">⣿</span> ${idx + 1}</td>
            <td>${clean(item.name)}</td>
            <td>${clean(item.sku)}</td>
            <td>${cash(item.price)}</td>
            <td><input data-q-qty="${item.id}" type="number" min="1" value="${item.quantity}" style="width:58px"></td>
            <td><input data-q-discount="${item.id}" type="number" step="0.1" min="0" max="${item.price * item.quantity}" value="${item.discount}" style="width:70px"></td>
            <td><input data-q-tax="${item.id}" type="number" step="0.1" min="0" max="100" value="${item.taxRate}" style="width:54px"></td>
            <td>${cash(item.price * item.quantity - item.discount + ((item.price * item.quantity - item.discount) * item.taxRate / 100))}</td>
            <td><button data-q-remove="${item.id}">&times;</button></td>
          </tr>`).join("") : "<tr><td colspan='9'>Select a product to add it to the quotation.</td></tr>";

        const t = quoteTotals();
        document.getElementById("quotationSubtotal").textContent = cash(t.subtotal);
        document.getElementById("quotationDiscount").textContent = cash(t.discount);
        document.getElementById("quotationTax").textContent = cash(t.tax);
        document.getElementById("quotationGrandTotal").textContent = cash(t.total);
        document.getElementById("quotationNumber").textContent = editingQuoteNumber ? `${quoteNumber} (Editing)` : quoteNumber;
      };

      // 5b. Drag and drop reordering for quotation line items
      let dragSrcIndex = null;
      itemRows?.addEventListener("dragstart", e => {
        const tr = e.target.closest("tr[data-q-index]");
        if (!tr) return;
        dragSrcIndex = Number(tr.dataset.qIndex);
        e.dataTransfer.effectAllowed = "move";
        tr.style.opacity = "0.4";
      });
      itemRows?.addEventListener("dragend", e => {
        const tr = e.target.closest("tr[data-q-index]");
        if (tr) tr.style.opacity = "1";
      });
      itemRows?.addEventListener("dragover", e => {
        e.preventDefault();
        if (e.dataTransfer) e.dataTransfer.dropEffect = "move";
      });
      itemRows?.addEventListener("drop", e => {
        e.preventDefault();
        const tr = e.target.closest("tr[data-q-index]");
        if (!tr || dragSrcIndex === null) return;
        const dropTargetIndex = Number(tr.dataset.qIndex);
        if (dragSrcIndex !== dropTargetIndex) {
          const movedItem = quoteItems.splice(dragSrcIndex, 1)[0];
          quoteItems.splice(dropTargetIndex, 0, movedItem);
          renderBuilder();
          toast(`Moved line item to line ${dropTargetIndex + 1}`);
        }
      });

      const show = () => {
        const q = (quoteSearch?.value || "").toLowerCase(), status = quoteStatus?.value;
        const visible = records("alixQuotations").filter(x => (!status || x.status === status) && `${x.number} ${x.customer}`.toLowerCase().includes(q));
        const savedRows = document.getElementById("quotationsTable");
        if (savedRows) {
          savedRows.innerHTML = visible.length ? visible.map(x => `
            <tr>
              <td><b>${clean(x.number)}</b></td>
              <td>${clean(x.customer)}</td>
              <td>${new Date(x.date).toLocaleDateString("en-KE")}</td>
              <td>${clean(x.payment)}</td>
              <td>${cash(x.amount)}</td>
              <td>${clean(x.status)}</td>
              <td>
                <button data-q-print="${x.number}">Print</button>
                <button data-q-edit="${x.number}">Edit</button>
              </td>
            </tr>`).join("") : "<tr><td colspan='7'>No quotations found.</td></tr>";
        }
      };

      document.getElementById("addQuotationItem")?.addEventListener("click", () => {
        const product = products().find(p => p.id === productSelect.value);
        if (!product) return toast("Select a product first.", true);
        const found = quoteItems.find(i => i.id === product.id);
        if (found) { if (found.quantity < product.stock) found.quantity++; } else quoteItems.push({ ...product, quantity: 1, discount: 0, taxRate: 16 });
        renderBuilder();
      });

      itemRows?.addEventListener("input", e => {
        const id = e.target.dataset.qQty || e.target.dataset.qDiscount || e.target.dataset.qTax;
        const item = quoteItems.find(i => i.id === id);
        if (!item) return;
        if (e.target.dataset.qQty) item.quantity = Math.max(1, Math.min(item.stock, Number(e.target.value) || 1));
        if (e.target.dataset.qDiscount) item.discount = Math.max(0, Math.min(item.price * item.quantity, parseFloat(e.target.value) || 0));
        if (e.target.dataset.qTax) item.taxRate = Math.max(0, Math.min(100, parseFloat(e.target.value) || 0));
        renderBuilder();
      });

      itemRows?.addEventListener("click", e => { if (e.target.dataset.qRemove) { quoteItems = quoteItems.filter(i => i.id !== e.target.dataset.qRemove); renderBuilder(); } });

      const saveQuote = () => {
        if (!customerInput.value.trim() || !quoteItems.length) return toast("Enter a customer and add at least one product.", true);
        const t = quoteTotals(), all = records("alixQuotations");
        
        const quoteObj = {
          number: quoteNumber,
          customer: customerInput.value.trim(),
          payment: paymentSelect.value,
          date: new Date().toISOString(),
          amount: t.total,
          subtotal: t.subtotal,
          discount: t.discount,
          tax: t.tax,
          items: [...quoteItems],
          status: "Draft"
        };

        if (editingQuoteNumber) {
          const idx = all.findIndex(x => x.number === editingQuoteNumber);
          if (idx !== -1) all[idx] = quoteObj;
          editingQuoteNumber = null;
        } else {
          all.unshift(quoteObj);
        }

        saveRecords("alixQuotations", all); show(); toast(`Quotation ${quoteNumber} saved.`); return quoteObj;
      };

      const quotePrint = quote => {
        const logo = new URL("IMG-20260803-WA0008~2.jpg", window.location.href).href;
        const lines = quote.items.map(i => `<tr><td>${clean(i.name)}</td><td>${clean(i.sku)}</td><td>${i.quantity}</td><td>${cash(i.price)}</td><td>${cash(i.price * i.quantity - i.discount + ((i.price * i.quantity - i.discount) * i.taxRate / 100))}</td></tr>`).join("");
        const w = window.open("", "_blank", "width=820,height=760");
          const quoteSettings = get("alixSettings", {});
          w.document.write(`<!doctype html><html><head><title>Quotation ${clean(quote.number)}</title><style>body{font-family:Arial;color:#122746;max-width:720px;margin:35px auto;padding:0 25px}.brand{display:flex;align-items:center;gap:15px;border-bottom:2px solid #1f5cad;padding-bottom:15px}.brand img{width:65px;height:65px;object-fit:contain}h1{margin:0;color:#123b75}table{width:100%;border-collapse:collapse;margin:25px 0}th,td{padding:9px;border-bottom:1px solid #dce5f0;text-align:left}.total{text-align:right;font-size:18px;font-weight:bold}</style></head><body><div class="brand"><img src="${logo}" alt="ALIX logo"><div><h1>${clean(quoteSettings.businessName || "ALIX Power Enterprise")}</h1><p style="white-space:pre-line">${clean(quoteSettings.quotationHeader || "Customer Quotation") } · ${clean(quote.number)}</p></div></div><p><b>Customer:</b> ${clean(quote.customer)}<br><b>Payment method:</b> ${clean(quote.payment)}<br><b>Date:</b> ${new Date(quote.date).toLocaleString("en-KE")}</p><table><thead><tr><th>Product</th><th>SKU</th><th>Qty</th><th>Price</th><th>Total</th></tr></thead><tbody>${lines}</tbody></table><p class="total">Subtotal: ${cash(quote.subtotal)}<br>Discount: ${cash(quote.discount)}<br>VAT: ${cash(quote.tax)}<br>Grand Total: ${cash(quote.amount)}</p><p style="white-space:pre-line;text-align:center">${clean(quoteSettings.quotationFooter || "Thank you for your business!")}</p></body></html>`);
        w.document.close(); w.onload = () => w.print();
      };

      document.getElementById("saveQuotationBtn")?.addEventListener("click", saveQuote);
      
      // Save Quotation as PDF
      document.getElementById("savePdfQuotationBtn")?.addEventListener("click", () => {
        const quote = saveQuote();
        if (quote) {
          quotePrint(quote);
          toast("Select 'Save as PDF' in the print dialog.");
        }
      });

      document.getElementById("printQuotationBtn")?.addEventListener("click", () => { const quote = saveQuote(); if (quote) quotePrint(quote); });
      document.getElementById("newQuotationBtn")?.addEventListener("click", () => { quoteItems = []; customerInput.value = ""; quoteNumber = number(); editingQuoteNumber = null; renderBuilder(); });
      
      quoteSearch?.addEventListener("input", show); quoteStatus?.addEventListener("change", show);

      document.getElementById("quotationsTable")?.addEventListener("click", e => {
        const printNo = e.target.dataset.qPrint;
        const pdfNo = e.target.dataset.qPdf;
        const editNo = e.target.dataset.qEdit;

        const allQ = records("alixQuotations");
        if (printNo) {
          const q = allQ.find(x => x.number === printNo);
          if (q) quotePrint(q);
        } else if (pdfNo) {
          const q = allQ.find(x => x.number === pdfNo);
          if (q) { quotePrint(q); toast("Select 'Save as PDF' in the print dialog."); }
        } else if (editNo) {
          const q = allQ.find(x => x.number === editNo);
          if (q) {
            quoteItems = [...q.items];
            customerInput.value = q.customer;
            paymentSelect.value = q.payment;
            quoteNumber = q.number;
            editingQuoteNumber = q.number;
            renderBuilder();
            window.scrollTo({ top: 0, behavior: "smooth" });
            toast(`Loaded Quotation ${q.number} for editing.`);
          }
        }
      });
      renderBuilder(); show();
    }

    if (title === "Invoices") {
      let statusFilter = null; // null (all), 'completed', 'pending'
      const searchBox = document.getElementById("invoiceSearch");
      const paymentFilter = document.getElementById("invoicePaymentFilter");
      const rows = document.getElementById("invoicesTable");
      const allSales = () => get(K.sales, []);
      
      const cardCompleted = document.getElementById("cardCompletedTransactions");
      const cardPending = document.getElementById("cardPendingTransactions");
      const cardTotal = document.getElementById("cardTotalValue");

      const renderInvoices = () => {
        const query = (searchBox?.value || "").trim().toLowerCase();
        const payment = paymentFilter?.value;
        const sales = allSales();

        if (cardCompleted) cardCompleted.style.outline = statusFilter === "completed" ? "3px solid #137333" : "none";
        if (cardPending) cardPending.style.outline = statusFilter === "pending" ? "3px solid #e38800" : "none";

        const visible = sales.filter(s => {
          const matchesQuery = (!payment || s.payment === payment) && `${s.invoice} ${s.customer} ${s.payment}`.toLowerCase().includes(query);
          if (!matchesQuery) return false;

          const balanceDue = s.total - (s.received ?? s.total);
          const isPending = balanceDue > 0.01;
          const isCompleted = !isPending;

          if (statusFilter === "completed") return isCompleted;
          if (statusFilter === "pending") return isPending;
          return true;
        });

        if (rows) {
          rows.innerHTML = visible.length ? visible.map(s => {
            const balanceDue = s.total - (s.received ?? s.total);
            const isPending = balanceDue > 0.01;
            const statusBadge = isPending
              ? `<span style="padding:3px 8px;border-radius:12px;font-size:12px;font-weight:bold;background:#fef3d6;color:#b06000">Pending (Bal: ${cash(balanceDue)})</span>`
              : `<span style="padding:3px 8px;border-radius:12px;font-size:12px;font-weight:bold;background:#e6f4ea;color:#137333">Completed</span>`;

            return `
            <tr>
              <td><b>${clean(s.invoice)}</b></td>
              <td>${clean(s.customer)}</td>
              <td>${clean(s.payment)}</td>
              <td>${new Date(s.createdAt).toLocaleString("en-KE")}</td>
              <td>${cash(s.total)}</td>
              <td>${statusBadge}</td>
              <td><button data-view="${s.invoice}">View</button> <button data-print="${s.invoice}">Print</button></td>
            </tr>`;
          }).join("") : "<tr><td colspan='7'>No invoices match search.</td></tr>";
        }

        const completedCount = sales.filter(s => (s.received >= s.total) || !((s.total - (s.received ?? s.total)) > 0.01)).length;
        const pendingCount = sales.filter(s => (s.total - (s.received ?? s.total)) > 0.01).length;
        const totalValueSum = sales.reduce((sum, s) => sum + Number(s.total || 0), 0);

        if (document.getElementById("completedTransactionsCount")) document.getElementById("completedTransactionsCount").textContent = completedCount;
        if (document.getElementById("pendingTransactionsCount")) document.getElementById("pendingTransactionsCount").textContent = pendingCount;
        if (document.getElementById("totalInvoicesValue")) document.getElementById("totalInvoicesValue").textContent = sales.length;

        if (document.getElementById("invoicesToday")) document.getElementById("invoicesToday").textContent = completedCount;
        if (document.getElementById("invoiceValueToday")) document.getElementById("invoiceValueToday").textContent = cash(totalValueSum);
        if (document.getElementById("totalInvoices")) document.getElementById("totalInvoices").textContent = sales.length;
      };

      cardCompleted?.addEventListener("click", () => {
        statusFilter = statusFilter === "completed" ? null : "completed";
        renderInvoices();
        toast(statusFilter ? "Filtering: Completed Transactions" : "Showing: All Transactions");
      });

      cardPending?.addEventListener("click", () => {
        statusFilter = statusFilter === "pending" ? null : "pending";
        renderInvoices();
        toast(statusFilter ? "Filtering: Pending Transactions" : "Showing: All Transactions");
      });

      cardTotal?.addEventListener("click", () => {
        statusFilter = null;
        renderInvoices();
        toast("Showing: All Transactions");
      });

      rows?.addEventListener("click", event => {
        const invoice = event.target.dataset.view || event.target.dataset.print;
        if (!invoice) return;
        const sale = allSales().find(s => s.invoice === invoice);
        if (!sale) return toast("Invoice not found.", true);
        showReceiptPreviewModal(sale);
      });

      searchBox?.addEventListener("input", renderInvoices);
      paymentFilter?.addEventListener("change", renderInvoices);
      document.getElementById("clearInvoiceFilters")?.addEventListener("click", () => {
        if (searchBox) searchBox.value = "";
        if (paymentFilter) paymentFilter.value = "";
        statusFilter = null;
        renderInvoices();
      });
      document.getElementById("exportInvoicesBtn")?.addEventListener("click", () => downloadCSV("alix-invoices.csv", ["Invoice", "Customer", "Payment", "Date", "Total"], allSales().map(s => [s.invoice, s.customer, s.payment, new Date(s.createdAt).toLocaleString("en-KE"), s.total])));
      renderInvoices();
    }

    // 3. Inventory Module
    if (title === "Inventory") {
      let stockFilter = null; // null (all), 'instock', 'lowstock', 'outofstock'
      const demoMovements = [];
      const getMovements = () => get("alixInventoryMovements", demoMovements);
      const saveMovements = m => set("alixInventoryMovements", m);

      const renderInventory = () => {
        const productsList = get(K.products, demoProducts);
        const inStockProds = productsList.filter(p => p.stock > (p.low || 5));
        const lowStockProds = productsList.filter(p => p.stock > 0 && p.stock <= (p.low || 5));
        const outOfStockProds = productsList.filter(p => p.stock <= 0);

        if (document.getElementById("inStockCount")) document.getElementById("inStockCount").textContent = inStockProds.length;
        if (document.getElementById("lowStockCount")) document.getElementById("lowStockCount").textContent = lowStockProds.length;
        if (document.getElementById("outOfStockCount")) document.getElementById("outOfStockCount").textContent = outOfStockProds.length;

        // Visual selection indicator on cards
        const cardIn = document.getElementById("cardInStock");
        const cardLow = document.getElementById("cardLowStock");
        const cardOut = document.getElementById("cardOutOfStock");
        const resetBtn = document.getElementById("resetStockFilterBtn");
        const titleElem = document.getElementById("inventoryStockTitle");

        if (cardIn) cardIn.style.outline = stockFilter === "instock" ? "3px solid #118566" : "none";
        if (cardLow) cardLow.style.outline = stockFilter === "lowstock" ? "3px solid #e38800" : "none";
        if (cardOut) cardOut.style.outline = stockFilter === "outofstock" ? "3px solid #be3e3e" : "none";
        if (resetBtn) resetBtn.style.display = stockFilter ? "inline-block" : "none";

        // Filter products list based on active stockFilter
        let filteredProducts = productsList.slice().sort((a, b) => a.name.localeCompare(b.name));
        if (stockFilter === "instock") {
          filteredProducts = inStockProds.slice().sort((a, b) => a.name.localeCompare(b.name));
          if (titleElem) titleElem.textContent = "Inventory Stock Items (In Stock)";
        } else if (stockFilter === "lowstock") {
          filteredProducts = lowStockProds.slice().sort((a, b) => a.name.localeCompare(b.name));
          if (titleElem) titleElem.textContent = "Inventory Stock Items (Low Stock)";
        } else if (stockFilter === "outofstock") {
          filteredProducts = outOfStockProds.slice().sort((a, b) => a.name.localeCompare(b.name));
          if (titleElem) titleElem.textContent = "Inventory Stock Items (Out of Stock)";
        } else {
          if (titleElem) titleElem.textContent = "Inventory Stock Items (All Products)";
        }
        const stockQuery = (document.getElementById("inventoryStockSearch")?.value || "").toLowerCase();
        filteredProducts = filteredProducts.filter(p => `${p.name} ${p.sku} ${p.category || ""}`.toLowerCase().includes(stockQuery));

        // Render stock items table
        const stockTableBody = document.getElementById("inventoryStockTable");
        if (stockTableBody) {
          stockTableBody.innerHTML = filteredProducts.length ? filteredProducts.map(p => {
            const isLow = p.stock > 0 && p.stock <= (p.low || 5);
            const isOut = p.stock <= 0;
            const statusBadge = isOut ? `<span style="padding:3px 8px;border-radius:12px;font-size:12px;font-weight:bold;background:#fce8e8;color:#be3e3e">Out of stock</span>`
              : isLow ? `<span style="padding:3px 8px;border-radius:12px;font-size:12px;font-weight:bold;background:#fef3d6;color:#b06000">Low stock</span>`
              : `<span style="padding:3px 8px;border-radius:12px;font-size:12px;font-weight:bold;background:#e6f4ea;color:#137333">In stock</span>`;

            return `
              <tr>
                <td><b>${clean(p.name)}</b></td>
                <td>${clean(p.sku)}</td>
                <td>${clean(p.category || "General")}</td>
                <td>${cash(p.price)}</td>
                <td><b>${p.stock}</b></td>
                <td>${statusBadge}</td>
                <td><button data-adjust-stock="${p.id}">Adjust stock</button></td>
              </tr>
            `;
          }).join("") : "<tr><td colspan='7'>No products match this stock filter.</td></tr>";
        }

        // Filter inventory movements table
        const q = (document.getElementById("inventorySearch")?.value || "").toLowerCase();
        const typeFilter = document.getElementById("inventoryTypeFilter")?.value || "";
        const movements = getMovements().filter(m => (!typeFilter || m.type === typeFilter) && `${m.product} ${m.reason} ${m.user}`.toLowerCase().includes(q));

        const tableBody = document.getElementById("inventoryMovements");
        if (tableBody) {
          tableBody.innerHTML = movements.length ? movements.map(m => `
            <tr>
              <td>${new Date(m.date).toLocaleDateString("en-KE")}</td>
              <td><b>${clean(m.product)}</b></td>
              <td><span style="padding:3px 8px;border-radius:6px;font-size:12px;font-weight:bold;background:${m.type === 'RESTOCK' ? '#e6f4ea;color:#137333' : m.type === 'SALE' ? '#feefc3;color:#b06000' : '#e8f0fe;color:#1a73e8'}">${m.type}</span></td>
              <td><b>${m.qty > 0 ? '+' + m.qty : m.qty}</b></td>
              <td>${clean(m.reason)}</td>
              <td>${clean(m.user || "Administrator")}</td>
            </tr>`).join("") : "<tr><td colspan='6'>No inventory movements recorded.</td></tr>";
        }
      };

      // Card click handlers for stock status filtering
      document.getElementById("cardInStock")?.addEventListener("click", () => {
        stockFilter = stockFilter === "instock" ? null : "instock";
        renderInventory();
        toast(stockFilter ? "Filtering: In Stock Products" : "Showing: All Products");
      });

      document.getElementById("cardLowStock")?.addEventListener("click", () => {
        stockFilter = "lowstock";
        renderInventory();
        toast("Filtering: Low Stock Products");
      });

      document.getElementById("cardOutOfStock")?.addEventListener("click", () => {
        stockFilter = stockFilter === "outofstock" ? null : "outofstock";
        renderInventory();
        toast(stockFilter ? "Filtering: Out of Stock Products" : "Showing: All Products");
      });

      document.getElementById("resetStockFilterBtn")?.addEventListener("click", () => {
        stockFilter = null;
        renderInventory();
        toast("Filter reset to All Products");
      });

      const handleAdjustmentForProduct = pId => {
        const productsList = get(K.products, demoProducts);
        const product = productsList.find(x => x.id === pId);
        if (!product) return toast("Product not found.", true);

        const qtyInput = prompt(`Enter stock adjustment quantity for ${product.name} (Current Stock: ${product.stock}):\n(Use positive to add, negative to deduct)`, "10");
        if (qtyInput === null) return;
        const qty = parseInt(qtyInput, 10);
        if (!Number.isFinite(qty) || qty === 0) return toast("Invalid adjustment quantity.", true);

        const reason = prompt("Enter reason for stock adjustment:", qty > 0 ? "Supplier Restock / Purchase" : "Damaged / Stock Audit Correction") || "Stock Adjustment";

        product.stock = Math.max(0, Number(product.stock || 0) + qty);
        set(K.products, productsList);

        const movements = getMovements();
        movements.unshift({
          date: new Date().toISOString(),
          product: product.name,
          type: qty > 0 ? "RESTOCK" : "ADJUSTMENT",
          qty,
          reason,
          user: "Administrator"
        });
        saveMovements(movements);
        renderInventory();
        toast(`Adjusted ${product.name} stock by ${qty > 0 ? '+' + qty : qty}. New stock: ${product.stock}`);
      };

      document.getElementById("inventoryStockSearch")?.addEventListener("input", renderInventory);

      document.getElementById("inventoryStockTable")?.addEventListener("click", e => {
        const id = e.target.dataset.adjustStock;
        if (id) handleAdjustmentForProduct(id);
      });

      document.getElementById("btnStockCount")?.addEventListener("click", () => {
        const productsList = get(K.products, demoProducts);
        const summary = productsList.map(p => `• ${p.name} (${p.sku}): ${p.stock} in stock`).join("\n");
        alert(`=== INVENTORY STOCK COUNT SUMMARY ===\nTotal Items: ${productsList.length}\n\n${summary}`);
      });

      document.getElementById("exportInventoryBtn")?.addEventListener("click", () => {
        const productsList = get(K.products, demoProducts);
        downloadCSV("alix-inventory-stock.csv", ["Product", "SKU", "Category", "Stock", "Price"], productsList.map(p => [p.name, p.sku, p.category || "General", p.stock, p.price]));
      });

      document.getElementById("inventorySearch")?.addEventListener("input", renderInventory);
      document.getElementById("inventoryTypeFilter")?.addEventListener("change", renderInventory);
      renderInventory();
    }

    // 6. Expenses Module
    if (title === "Expenses") {
      const demoExpenses = [];
      const getExpenses = () => get("alixExpenses", demoExpenses);
      const saveExpenses = exp => set("alixExpenses", exp);

      const renderExpenses = () => {
        const q = (document.getElementById("expenseSearch")?.value || "").toLowerCase();
        const catFilter = document.getElementById("expenseCategoryFilter")?.value || "";
        const all = getExpenses();
        const filtered = all.filter(e => (!catFilter || e.category === catFilter) && `${e.description} ${e.category} ${e.method}`.toLowerCase().includes(q));

        const now = new Date();
        const thisMonthStr = now.toISOString().slice(0, 7);
        const todayStr = now.toISOString().slice(0, 10);

        const monthlySum = all.filter(e => (e.date || "").startsWith(thisMonthStr)).reduce((sum, e) => sum + Number(e.amount || 0), 0);
        const todaySum = all.filter(e => (e.date || "").startsWith(todayStr)).reduce((sum, e) => sum + Number(e.amount || 0), 0);

        if (document.getElementById("monthlyExpenses")) document.getElementById("monthlyExpenses").textContent = cash(monthlySum);
        if (document.getElementById("todayExpenses")) document.getElementById("todayExpenses").textContent = cash(todaySum);

        const tableBody = document.getElementById("expensesTable");
        if (tableBody) {
          tableBody.innerHTML = filtered.length ? filtered.map(e => `
            <tr>
              <td>${e.date}</td>
              <td><b>${clean(e.category)}</b></td>
              <td>${clean(e.description)}</td>
              <td>${clean(e.method || "Cash")}</td>
              <td><b>${cash(e.amount)}</b></td>
              <td>
                <button data-edit-expense="${e.id}">Edit</button>
                <button data-delete-expense="${e.id}" style="color:#d74b4b;margin-left:4px">Delete</button>
              </td>
            </tr>`).join("") : "<tr><td colspan='6'>No expenses recorded.</td></tr>";
        }
      };

      document.getElementById("btnAddExpense")?.addEventListener("click", () => {
        const category = prompt("Expense Category (Rent, Transport, Utilities, Salaries, Supplies, Other):", "Utilities");
        if (!category) return;
        const description = prompt("Description:", "Electricity payment") || category;
        const method = prompt("Payment Method (Cash, M-Pesa, Card, Bank Transfer):", "M-Pesa") || "Cash";
        const amountInput = prompt("Amount (KSh):", "1500");
        if (amountInput === null) return;
        const amount = parseFloat(amountInput);
        if (!Number.isFinite(amount) || amount <= 0) return toast("Enter a valid expense amount.", true);

        const all = getExpenses();
        all.unshift({
          id: "exp_" + Date.now(),
          date: new Date().toISOString().slice(0, 10),
          category,
          description,
          method,
          amount
        });
        saveExpenses(all);
        renderExpenses();
        toast(`Added expense: ${description} (${cash(amount)})`);
      });

      document.getElementById("exportExpensesBtn")?.addEventListener("click", () => {
        const all = getExpenses();
        downloadCSV("alix-expenses.csv", ["Date", "Category", "Description", "Payment Method", "Amount"], all.map(e => [e.date, e.category, e.description, e.method, e.amount]));
      });

      document.getElementById("expensesTable")?.addEventListener("click", e => {
        const editId = e.target.dataset.editExpense;
        const deleteId = e.target.dataset.deleteExpense;
        const all = getExpenses();

        if (editId) {
          const item = all.find(x => x.id === editId);
          if (!item) return;
          const desc = prompt("Edit Description:", item.description); if (!desc) return;
          const amt = parseFloat(prompt("Edit Amount (KSh):", item.amount));
          if (!Number.isFinite(amt)) return toast("Invalid amount.", true);
          item.description = desc; item.amount = amt;
          saveExpenses(all); renderExpenses(); toast("Expense updated.");
        } else if (deleteId) {
          if (confirm("Delete this expense record?")) {
            const next = all.filter(x => x.id !== deleteId);
            saveExpenses(next); renderExpenses(); toast("Expense deleted.");
          }
        }
      });

      document.getElementById("expenseSearch")?.addEventListener("input", renderExpenses);
      document.getElementById("expenseCategoryFilter")?.addEventListener("change", renderExpenses);
      renderExpenses();
    }

    if (title === "Reports") {
      const sales = () => get(K.sales, []);
      const products = () => get(K.products, demoProducts).slice().sort((a, b) => a.name.localeCompare(b.name));
      const customers = () => get(K.customers, demoCustomers).slice().sort((a, b) => a.name.localeCompare(b.name));
      const expenses = () => get("alixExpenses", []);
      const movements = () => get("alixInventoryMovements", []);
      const render = () => {
        const from = document.getElementById("salesDateFrom")?.value || "";
        const to = document.getElementById("salesDateTo")?.value || "";
        const payment = document.getElementById("salesPaymentFilter")?.value || "";
        const filteredSales = sales().filter(s => {
          const date = String(s.createdAt || "").slice(0, 10);
          return (!from || date >= from) && (!to || date <= to) && (!payment || s.payment === payment);
        });
        const salesRows = document.getElementById("salesReportTable");
        if (salesRows) salesRows.innerHTML = filteredSales.map(s => `<tr><td>${clean(s.invoice)}</td><td>${clean(s.customer)}</td><td>${clean(s.payment)}</td><td>${new Date(s.createdAt).toLocaleDateString("en-KE")}</td><td>${cash(s.total)}</td><td>${Number(s.received || 0) >= Number(s.total || 0) ? "Completed" : "Pending"}</td></tr>`).join("") || "<tr><td colspan='6'>No sales found.</td></tr>";
        const productRows = document.getElementById("productsReportTable");
        if (productRows) productRows.innerHTML = products().map(p => `<tr><td>${clean(p.name)}</td><td>${clean(p.sku)}</td><td>${clean(p.category || "General")}</td><td>${cash(p.price)}</td><td>${p.stock}</td><td>${p.stock <= (p.low || 5) ? "Low stock" : "Active"}</td></tr>`).join("");
        const inventoryRows = document.getElementById("inventoryReportTable");
        if (inventoryRows) inventoryRows.innerHTML = movements().map(m => `<tr><td>${new Date(m.date).toLocaleDateString("en-KE")}</td><td>${clean(m.product)}</td><td>${clean(m.type)}</td><td>${m.qty}</td><td>${clean(m.reason)}</td><td>${clean(m.user || "Administrator")}</td></tr>`).join("") || "<tr><td colspan='6'>No inventory movements found.</td></tr>";
        const expenseRows = document.getElementById("expensesReportTable");
        if (expenseRows) expenseRows.innerHTML = expenses().map(e => `<tr><td>${clean(e.date)}</td><td>${clean(e.category)}</td><td>${clean(e.description)}</td><td>${clean(e.method || "Cash")}</td><td>${cash(e.amount)}</td></tr>`).join("") || "<tr><td colspan='5'>No expenses found.</td></tr>";
        const customerRows = document.getElementById("customersReportTable");
        if (customerRows) customerRows.innerHTML = customers().map(c => `<tr><td>${clean(c.name)}</td><td>${clean(c.phone)}</td><td>${clean(c.email || "-")}</td><td>${c.points || 0}</td><td>${cash(c.credit)}</td></tr>`).join("");
        const cashierRows = document.getElementById("cashierReportTable");
        if (cashierRows) cashierRows.innerHTML = filteredSales.map(s => `<tr><td>${clean(s.invoice)}</td><td>${clean(s.customer)}</td><td>${clean(s.payment)}</td><td>${new Date(s.createdAt).toLocaleDateString("en-KE")}</td><td>${cash(s.total)}</td></tr>`).join("") || "<tr><td colspan='5'>No cashier transactions found.</td></tr>";
      };
      document.getElementById("applySalesFilter")?.addEventListener("click", render);
      document.getElementById("clearSalesFilter")?.addEventListener("click", () => { ["salesDateFrom", "salesDateTo"].forEach(id => { const el = document.getElementById(id); if (el) el.value = ""; }); const filter = document.getElementById("salesPaymentFilter"); if (filter) filter.value = ""; render(); });
      const exportRows = (id, filename, headers, values) => document.getElementById(id)?.addEventListener("click", () => downloadCSV(filename, headers, values()));
      exportRows("exportSalesBtn", "alix-sales-report.csv", ["Invoice", "Customer", "Payment", "Date", "Total", "Status"], () => sales().map(s => [s.invoice, s.customer, s.payment, s.createdAt, s.total, Number(s.received || 0) >= Number(s.total || 0) ? "Completed" : "Pending"]));
      exportRows("exportProductsBtn", "alix-products-report.csv", ["Product", "SKU", "Category", "Price", "Stock", "Status"], () => products().map(p => [p.name, p.sku, p.category, p.price, p.stock, p.stock <= (p.low || 5) ? "Low stock" : "Active"]));
      exportRows("exportInventoryRptBtn", "alix-inventory-report.csv", ["Date", "Product", "Type", "Quantity", "Reason", "User"], () => movements().map(m => [m.date, m.product, m.type, m.qty, m.reason, m.user || "Administrator"]));
      exportRows("exportExpensesRptBtn", "alix-expenses-report.csv", ["Date", "Category", "Description", "Method", "Amount"], () => expenses().map(e => [e.date, e.category, e.description, e.method, e.amount]));
      exportRows("exportCustomersRptBtn", "alix-customers-report.csv", ["Customer", "Phone", "Email", "Points", "Credit"], () => customers().map(c => [c.name, c.phone, c.email, c.points || 0, c.credit || 0]));
      exportRows("exportCashierRptBtn", "alix-cashier-report.csv", ["Invoice", "Customer", "Payment", "Date", "Total"], () => sales().map(s => [s.invoice, s.customer, s.payment, s.createdAt, s.total]));
      render();
    }

    // 7. Settings Module
    if (title === "Settings") {
      const demoSettings = {
        businessName: "ALIX Power Enterprise",
        phone: "",
        email: "",
        vatRate: 16,
        receiptFooter: "Thank you for your business!",
        registerName: "Main Counter",
        defaultPayment: "Cash"
      };
      const getSettings = () => get("alixSettings", demoSettings);
      const saveSettings = s => set("alixSettings", s);
      const ensureDocumentHeaders = () => {
        const panel = document.querySelector(".settings-grid article:nth-child(2)");
        if (!panel || document.getElementById("settingReceiptHeader")) return;
        [
          ["settingReceiptHeader", "Receipt header"],
          ["settingInvoiceHeader", "Invoice header"],
          ["settingQuotationHeader", "Quotation header"]
        ].forEach(([id, label]) => {
          const wrapper = document.createElement("label");
          wrapper.textContent = label;
          const field = document.createElement("textarea");
          field.id = id;
          field.placeholder = label;
          wrapper.append(field);
          panel.append(wrapper);
        });
      };

      const loadForm = () => {
        ensureDocumentHeaders();
        const s = getSettings();
        if (document.getElementById("settingBusinessName")) document.getElementById("settingBusinessName").value = s.businessName || "ALIX Power Enterprise";
        if (document.getElementById("settingPhone")) document.getElementById("settingPhone").value = s.phone || "";
        if (document.getElementById("settingEmail")) document.getElementById("settingEmail").value = s.email || "";
        if (document.getElementById("settingAddress")) document.getElementById("settingAddress").value = s.address || "";
        if (document.getElementById("settingTaxNumber")) document.getElementById("settingTaxNumber").value = s.taxNumber || "";
        if (document.getElementById("settingVatRate")) document.getElementById("settingVatRate").value = s.vatRate ?? 16;
        if (document.getElementById("settingReceiptFooter")) document.getElementById("settingReceiptFooter").value = s.receiptFooter || "";
        if (document.getElementById("settingReceiptHeader")) document.getElementById("settingReceiptHeader").value = s.receiptHeader || "";
        if (document.getElementById("settingInvoiceHeader")) document.getElementById("settingInvoiceHeader").value = s.invoiceHeader || "";
        if (document.getElementById("settingQuotationHeader")) document.getElementById("settingQuotationHeader").value = s.quotationHeader || "";
        if (document.getElementById("settingInvoiceFooter")) document.getElementById("settingInvoiceFooter").value = s.invoiceFooter || "";
        if (document.getElementById("settingQuotationFooter")) document.getElementById("settingQuotationFooter").value = s.quotationFooter || "";
        if (document.getElementById("settingRegisterName")) document.getElementById("settingRegisterName").value = s.registerName || "Main Counter";
        if (document.getElementById("settingCashierName")) document.getElementById("settingCashierName").value = s.cashierName || "Admin";
        if (document.getElementById("settingDefaultPayment")) document.getElementById("settingDefaultPayment").value = s.defaultPayment || "Cash";
      };

      document.getElementById("btnSaveSettings")?.addEventListener("click", () => {
        const current = getSettings();
        current.businessName = document.getElementById("settingBusinessName")?.value || current.businessName;
        current.phone = document.getElementById("settingPhone")?.value || current.phone;
        current.email = document.getElementById("settingEmail")?.value || current.email;
        current.address = document.getElementById("settingAddress")?.value || "";
        current.taxNumber = document.getElementById("settingTaxNumber")?.value || "";
        current.vatRate = parseFloat(document.getElementById("settingVatRate")?.value) || 16;
        current.receiptFooter = document.getElementById("settingReceiptFooter")?.value || current.receiptFooter;
        current.receiptHeader = document.getElementById("settingReceiptHeader")?.value || "";
        current.invoiceHeader = document.getElementById("settingInvoiceHeader")?.value || "";
        current.quotationHeader = document.getElementById("settingQuotationHeader")?.value || "";
        current.invoiceFooter = document.getElementById("settingInvoiceFooter")?.value || current.receiptFooter;
        current.quotationFooter = document.getElementById("settingQuotationFooter")?.value || current.receiptFooter;
        current.registerName = document.getElementById("settingRegisterName")?.value || current.registerName;
        current.cashierName = document.getElementById("settingCashierName")?.value || "Admin";
        current.defaultPayment = document.getElementById("settingDefaultPayment")?.value || current.defaultPayment;

        saveSettings(current);
        toast("Settings saved successfully!");
      });

      document.getElementById("btnManageUsers")?.addEventListener("click", () => { window.location.href = "users.html"; });

      loadForm();
    }
  }

  // 8. Global Club button click handler on top right of dashboard & header
  document.addEventListener("click", e => {
    const isClubBtn = e.target.closest("button[aria-label='Notifications'], .club-btn, #clubBtn") || (e.target.textContent && e.target.textContent.trim() === "♧");
    if (isClubBtn) {
      const settings = get("alixSettings", {});
      alert(`${settings.businessName || "ALIX Power Enterprise"}\n${settings.address || ""}\n${settings.email || ""}\n${settings.phone || ""}`);
      return;
    }

    if (e.target.textContent && e.target.textContent.includes("+ Purchase Order")) {
      toast("Purchase Order feature ready.");
    }
    if (e.target.closest("button[aria-label='Search']")) {
      const q = prompt("Global System Search:");
      if (q) toast(`Searching for "${q}"...`);
    }
  });

  function downloadCSV(filename, headers, rows) {
    const quote = value => `"${String(value ?? "").replace(/"/g, '""')}"`;
    const csv = [headers, ...rows].map(row => row.map(quote).join(",")).join("\r\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
    const link = document.createElement("a"); link.href = url; link.download = filename; link.click();
    URL.revokeObjectURL(url);
    toast(`${filename} downloaded.`);
  }

  function migrateDocumentNumbers() {
    const sales = get(K.sales, []);
    const quotations = get("alixQuotations", []);
    const highest = (items, field, prefix) => items.reduce((max, item) => {
      const match = String(item[field] || "").match(new RegExp(`^${prefix}-(\\d+)$`));
      return match ? Math.max(max, Number(match[1])) : max;
    }, 0);
    let invoiceSequence = Math.max(Number(localStorage.getItem("alixInvoiceSequence") || 0), highest(sales, "invoice", "INV"));
    let receiptSequence = Math.max(Number(localStorage.getItem("alixReceiptSequence") || 0), highest(sales, "receipt", "RCPT"));
    let quotationSequence = Math.max(Number(localStorage.getItem("alixQuotationSequence") || 0), highest(quotations, "number", "QTN"));
    let changed = false;
    sales.forEach(sale => {
      if (!/^INV-\d{6}$/.test(String(sale.invoice || ""))) { sale.invoice = `INV-${String(++invoiceSequence).padStart(6, "0")}`; changed = true; }
      if (!/^RCPT-\d{6}$/.test(String(sale.receipt || ""))) { sale.receipt = `RCPT-${String(++receiptSequence).padStart(6, "0")}`; changed = true; }
    });
    quotations.forEach(quotation => {
      if (!/^QTN-\d{6}$/.test(String(quotation.number || ""))) { quotation.number = `QTN-${String(++quotationSequence).padStart(6, "0")}`; changed = true; }
    });
    localStorage.setItem("alixInvoiceSequence", String(invoiceSequence));
    localStorage.setItem("alixReceiptSequence", String(receiptSequence));
    localStorage.setItem("alixQuotationSequence", String(quotationSequence));
    if (changed) { set(K.sales, sales); set("alixQuotations", quotations); }
  }

  const boot = () => {
    migrateDocumentNumbers();
    setupDashboard(); setupPOS(); setupModules();
  };

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else boot();
})();
