/* ALIX data layer — loaded FIRST on every data page.
   The pages were written to keep their data in localStorage. Instead of rewriting them, this file makes
   localStorage.getItem/setItem for the shop's data keys read from, and write to, the server database:
     - one blocking request to /api/bootstrap fills an in-memory copy before any page script runs
     - every later setItem is diffed against what the server already has and only the changes are sent
   Products are special: each belongs to an owner and the server decides who may see/edit them.
   Device-only keys (cart, held sales) stay in the real localStorage. */
(function () {
  "use strict";
  var LS = window.localStorage, P = Storage.prototype;
  var rawGet = P.getItem, rawSet = P.setItem, rawRemove = P.removeItem;
  var PRODUCTS = "alixProducts";
  var ARRAYS = { alixCustomers: 1, alixSales: 1, alixQuotations: 1, alixSuppliers: 1, alixExpenses: 1, alixInventoryMovements: 1, alixFinancialArchives: 1 };
  var KV = { alixSettings: 1, alixInvoiceSequence: 1, alixReceiptSequence: 1, alixQuotationSequence: 1 };
  var cache = {}, known = {}, snap = {}, chain = Promise.resolve(), timers = {}, failed = false;

  function banner(text, color) {
    function add() {
      var b = document.getElementById("alixStoreBanner");
      if (!b) { b = document.createElement("div"); b.id = "alixStoreBanner"; document.body.prepend(b); }
      b.style.cssText = "position:fixed;left:0;right:0;bottom:0;z-index:99999;padding:10px 16px;color:#fff;font:600 14px Arial,sans-serif;text-align:center;background:" + (color || "#be3e3e");
      b.textContent = text;
    }
    document.body ? add() : document.addEventListener("DOMContentLoaded", add);
  }
  function fail(text) { failed = true; banner(text + " Changes are NOT being saved."); }

  // ---------- load everything once, synchronously ----------
  var boot = null;
  try {
    var x = new XMLHttpRequest(); x.open("GET", "/api/bootstrap", false); x.send();
    if (x.status === 401) { location.replace("login.html"); }
    else if (x.status === 403 && /license_locked/.test(x.responseText)) { location.replace("license.html"); }
    else if (x.status === 200) boot = JSON.parse(x.responseText);
    else fail("Could not load data from the server (" + x.status + ").");
  } catch (e) { fail("Cannot reach the ALIX server."); }
  if (!boot) boot = { user: null, products: [], records: {}, kv: {} };
  window.ALIX_USER = boot.user;

  // ---------- products ----------
  function toClient(p) {
    return { id: "p" + p.id, name: p.name, sku: p.sku, category: p.category, price: p.price, cost: p.cost, stock: p.stock,
             low: p.low_stock_level, lowStockLevel: p.low_stock_level, barcode: p.barcode || "",
             owner_id: p.owner_id, owner_name: p.owner_name || "", canEdit: !!p.can_edit };
  }
  function setProducts(list) { cache[PRODUCTS] = JSON.stringify(list); snap = {}; list.forEach(function (p) { snap[p.id] = JSON.parse(JSON.stringify(p)); }); }
  setProducts(boot.products.map(toClient));
  var num = function (v) { return Number(v); };

  function api(method, url, body) {
    var json = JSON.stringify(body || {});
    return fetch(url, { method: method, credentials: "same-origin", headers: { "Content-Type": "application/json" }, body: json, keepalive: json.length < 60000 })
      .then(function (r) { return r.json().catch(function () { return {}; }).then(function (d) { if (!r.ok) { var e = new Error(d.error || ("Server error " + r.status)); e.status = r.status; throw e; } return d; }); });
  }
  function toast(msg) {
    var n = document.createElement("div"); n.textContent = msg;
    n.style.cssText = "position:fixed;right:20px;bottom:56px;z-index:99999;padding:14px 18px;border-radius:10px;color:#fff;background:#be3e3e;font:700 14px Arial,sans-serif;box-shadow:0 10px 25px #10234344;max-width:80vw";
    (document.body || document.documentElement).append(n); setTimeout(function () { n.remove(); }, 5000);
  }
  function changed() { try { document.dispatchEvent(new CustomEvent("alix:products-changed")); } catch (e) {} }
  function reloadSoon() { setTimeout(function () { location.reload(); }, 1800); }

  // snap = what the server will hold once everything queued so far has been sent (so two quick sales don't double-count)
  function syncProducts() {
    if (failed) return;
    var list; try { list = JSON.parse(cache[PRODUCTS] || "[]"); } catch (e) { return; }
    var seen = {}, ops = [];
    list.forEach(function (p) {
      seen[p.id] = 1; var s = snap[p.id];
      if (!s) { ops.push({ kind: "create", p: p }); snap[p.id] = JSON.parse(JSON.stringify(p)); return; }
      var patch = {};
      ["name", "sku", "category", "barcode"].forEach(function (f) { if (String(p[f] == null ? "" : p[f]) !== String(s[f] == null ? "" : s[f])) patch[f] = p[f]; });
      ["price", "cost"].forEach(function (f) { if (num(p[f]) !== num(s[f])) patch[f] = num(p[f]); });
      var low = p.low != null ? p.low : p.lowStockLevel; if (num(low) !== num(s.low)) patch.low_stock_level = num(low);
      if (num(p.stock) !== num(s.stock)) patch.stock_delta = num(p.stock) - num(s.stock);
      if (Object.keys(patch).length) { ops.push({ kind: "patch", id: p.id, patch: patch }); snap[p.id] = JSON.parse(JSON.stringify(p)); }
    });
    Object.keys(snap).forEach(function (id) { if (!seen[id]) { ops.push({ kind: "delete", id: id }); delete snap[id]; } });
    ops.forEach(function (op) {
      chain = chain.then(function () {
        if (op.kind === "create") {
          var p = op.p;
          return api("POST", "/api/products", { name: p.name, sku: p.sku, category: p.category || "General", price: num(p.price), cost: num(p.cost || 0),
            stock: num(p.stock), low_stock_level: num(p.low != null ? p.low : 5), barcode: p.barcode || null }).then(function (d) {
            var fresh = toClient(d), cur = JSON.parse(cache[PRODUCTS]);
            cache[PRODUCTS] = JSON.stringify(cur.map(function (q) { return q.id === p.id ? fresh : q; }));
            delete snap[p.id]; snap[fresh.id] = JSON.parse(JSON.stringify(fresh)); changed();
          });
        }
        if (op.kind === "patch") return api("PATCH", "/api/products/" + op.id.slice(1), op.patch);
        return api("DELETE", "/api/products/" + op.id.slice(1));
      }).catch(function (e) { toast(e.message); reloadSoon(); });
    });
  }

  // ---------- record collections + key/value settings ----------
  function hash(s) { var h = 5381; for (var i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return (h >>> 0).toString(36); }
  function ident(it, used) {
    var id = null;
    if (it && typeof it === "object") { var v = it.id != null ? it.id : it.invoice != null ? it.invoice : it.number; if (v != null) id = "k:" + v; }
    if (!id) id = "h:" + hash(JSON.stringify(it));
    var n = (used[id] = (used[id] || 0) + 1); return n > 1 ? id + "#" + n : id;
  }
  function index(list) { var used = {}, m = {}; list.forEach(function (it) { m[ident(it, used)] = JSON.stringify(it); }); return m; }
  Object.keys(ARRAYS).forEach(function (k) {
    var list = boot.records[k] || []; cache[k] = JSON.stringify(list); known[k] = index(list);
  });
  Object.keys(KV).forEach(function (k) { if (boot.kv[k] != null) { cache[k] = boot.kv[k]; known[k] = boot.kv[k]; } });

  function syncArray(k) {
    if (failed) return;
    var list; try { list = JSON.parse(cache[k] || "[]"); } catch (e) { return; }
    if (!Array.isArray(list)) return;
    var now = index(list), ups = [], dels = [];
    Object.keys(now).forEach(function (rid) { if (known[k][rid] !== now[rid]) ups.push({ rid: rid, data: JSON.parse(now[rid]) }); });
    Object.keys(known[k]).forEach(function (rid) { if (!(rid in now)) dels.push(rid); });
    if (!ups.length && !dels.length) return;
    var before = known[k]; known[k] = now;
    chain = chain.then(function () { return api("POST", "/api/records/" + k, { upserts: ups, deletes: dels }); })
      .catch(function (e) { known[k] = before; toast("Not saved: " + e.message); if (e.status === 403 || e.status === 401) reloadSoon(); });
  }
  function syncKV(k) {
    if (failed || cache[k] == null || known[k] === cache[k]) return;
    var val = cache[k]; known[k] = val;
    chain = chain.then(function () { return api("POST", "/api/kv", { key: k, value: val }); })
      .then(function (d) { if (d && d.value != null) { cache[k] = d.value; known[k] = d.value; } })
      .catch(function (e) { toast("Not saved: " + e.message); });
  }
  function schedule(k) {
    clearTimeout(timers[k]);
    timers[k] = setTimeout(function () { k === PRODUCTS ? syncProducts() : ARRAYS[k] ? syncArray(k) : syncKV(k); }, 0);
  }
  window.addEventListener("pagehide", function () { Object.keys(timers).forEach(function (k) { clearTimeout(timers[k]); k === PRODUCTS ? syncProducts() : ARRAYS[k] ? syncArray(k) : syncKV(k); }); });

  // ---------- the switch: shared keys go to the server, everything else stays in the browser ----------
  var shared = function (k) { return k === PRODUCTS || ARRAYS[k] || KV[k]; };
  P.getItem = function (k) { return (this === LS && shared(k)) ? (cache[k] == null ? null : cache[k]) : rawGet.call(this, k); };
  P.setItem = function (k, v) {
    if (this === LS && shared(k)) { cache[k] = String(v); schedule(k); return; }
    return rawSet.call(this, k, v);
  };
  P.removeItem = function (k) {
    if (this === LS && shared(k)) { cache[k] = k === PRODUCTS || ARRAYS[k] ? "[]" : null; schedule(k); return; }
    return rawRemove.call(this, k);
  };
  window.ALIX_STORE = { flush: function () { return chain; } };   // tests / debugging
})();
