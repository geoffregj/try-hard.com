(() => { const s = document.createElement("script"); s.src = "app.js"; document.head.appendChild(s); })();
