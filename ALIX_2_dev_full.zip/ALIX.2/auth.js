/* ALIX auth helper — loaded on every page except login/setup/license.
   The SERVER decides who may see a page or call the API; this file only
   shows the logged-in user, wires Logout, and hides menu links the role can't use. */
(function () {
  var HIDE = { customer: ["index.html", "dashboard.html", "pos.html", "receipt.html", "sales.html", "invoice.html", "inventory.html", "customers.html", "suppliers.html", "quotations.html", "expenses.html", "reports.html", "settings.html", "users.html"],
               cashier: ["settings.html", "reports.html", "expenses.html", "suppliers.html", "inventory.html", "sales.html", "users.html"],
               manager: ["users.html"], admin: [] };

  function go(url) { window.location.href = url; }

  fetch("/api/me", { credentials: "same-origin" }).then(function (r) {
    if (r.status === 401) { go("login.html"); return null; }
    return r.json();
  }).then(function (u) {
    if (!u) return;
    window.ALIX_USER = u;
    var name = document.getElementById("profileName"), role = document.getElementById("profileRole"),
        ini = document.getElementById("profileInitials"), av = document.getElementById("avatarBtn");
    var label = { admin: "Administrator", manager: "Manager", cashier: "Cashier", customer: "Customer" }[u.role] || u.role;
    if (name) { name.textContent = u.full_name; name.style.cursor = "pointer"; name.title = "My account"; name.onclick = function () { go("account.html"); }; }
    if (role) role.textContent = label;
    var letters = u.full_name.split(/\s+/).map(function (w) { return w[0]; }).join("").slice(0, 2).toUpperCase();
    if (ini) ini.textContent = letters;
    if (av) av.textContent = letters.slice(0, 1);

    (HIDE[u.role] || []).forEach(function (page) {
      document.querySelectorAll('a[href="' + page + '"]').forEach(function (a) { a.style.display = "none"; });
    });
    if (u.role === "admin") {
      var settings = document.querySelector('nav a[href="settings.html"], aside a[href="settings.html"]');
      if (settings && !document.querySelector('a[href="users.html"]')) {
        var a = settings.cloneNode(true); a.href = "users.html"; a.classList.remove("active");
        a.innerHTML = a.innerHTML.replace(/Settings/, "Users"); settings.parentNode.insertBefore(a, settings.nextSibling);
      }
    }
    if (u.role === "customer" && !document.getElementById("acctLinks")) {      // customer pages have no sidebar: give them account + sign-out links
      var head = document.querySelector("header");
      if (head) {
        var box = document.createElement("div"); box.id = "acctLinks"; box.style.cssText = "font:600 13px Arial,sans-serif;text-align:right";
        box.innerHTML = '<div style="color:#566f92;margin-bottom:4px"></div><a href="account.html" style="color:#2965bd;margin-right:12px">My account</a><a href="#" id="logoutBtn" style="color:#2965bd">Sign out</a>';
        box.firstChild.textContent = (u.business_name || u.full_name);
        head.appendChild(box);
      }
    }
    document.dispatchEvent(new CustomEvent("alix:user", { detail: u }));
  }).catch(function () { /* server down: page keeps working from local data */ });

  document.addEventListener("click", function (e) {
    if (e.target.closest && e.target.closest("#logoutBtn")) {
      fetch("/api/logout", { method: "POST", credentials: "same-origin" }).finally(function () { go("login.html"); });
    }
  });
})();
