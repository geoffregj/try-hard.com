"""ALIX licensing — verifies a signed license.json issued by the owner (see license_tool.py).

States: active -> warning (last `warn_days` before expiry) -> grace (after expiry) -> locked.
Set ALIX_LICENSE_URL to a URL hosting the signed license.json and the POS will pick up
renewals/suspensions from it automatically (checked at start-up and every few hours).
"""
import base64, json, os, threading, time, urllib.request
from datetime import date, datetime
from flask import jsonify, redirect, request
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from paths import DATA_DIR

PUBLIC_KEY_PEM = b"""-----BEGIN PUBLIC KEY-----
MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEsC2QHOQn/LlNDNh9Djp39Nb9E5S7
Yc+bjElcuf6vOOVJQmn1MhzVB37sYxu03IXQUjYldu26R5z3WfatmITFAA==
-----END PUBLIC KEY-----
"""
ROOT = DATA_DIR                             # license.json must persist across restarts — see paths.py
LICENSE_FILE = ROOT / "license.json"
SEEN_FILE = ROOT / ".license_seen"          # latest date seen: blunts "set the clock back" tricks
OPEN_PATHS = {"/license.html", "/license.js", "/api/license", "/api/health", "/style.css",
              "/IMG-20260803-WA0008~2.jpg"}
_pub = serialization.load_pem_public_key(PUBLIC_KEY_PEM)
_lock = threading.Lock()


def _canon(payload):
    return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()


def verify(lic):
    """Return the payload if lic carries a valid owner signature, else None."""
    try:
        _pub.verify(base64.b64decode(lic["signature"]), _canon(lic["payload"]), ec.ECDSA(hashes.SHA256()))
        date.fromisoformat(lic["payload"]["expires"]); date.fromisoformat(lic["payload"]["issued"])
        return lic["payload"]
    except (InvalidSignature, KeyError, TypeError, ValueError):
        return None


def _load():
    try:
        lic = json.loads(LICENSE_FILE.read_text())
        return lic if verify(lic) else None
    except (OSError, ValueError):
        return None


def _today():
    today = date.today()
    try:
        seen = date.fromisoformat(SEEN_FILE.read_text().strip())
    except (OSError, ValueError):
        seen = today
    latest = max(today, seen)
    if latest != seen or not SEEN_FILE.exists():
        try: SEEN_FILE.write_text(latest.isoformat())
        except OSError: pass
    return latest


def status():
    lic = _load()
    if not lic:
        return {"state": "locked", "reason": "No valid license found.", "days_left": None,
                "customer": None, "expires": None, "message": ""}
    p = lic["payload"]
    days_left = (date.fromisoformat(p["expires"]) - _today()).days
    warn, grace = int(p.get("warn_days", 7)), int(p.get("grace_days", 3))
    if p.get("status") == "suspended":
        state, reason = "locked", "This license has been suspended."
    elif days_left < -grace:
        state, reason = "locked", "The subscription has expired."
    elif days_left < 0:
        state, reason = "grace", "Subscription expired — please renew now."
    elif days_left <= warn:
        state, reason = "warning", "Subscription is due for renewal soon."
    else:
        state, reason = "active", ""
    return {"state": state, "reason": reason, "days_left": days_left, "grace_left": grace + days_left if days_left < 0 else grace,
            "customer": p.get("customer"), "expires": p["expires"], "message": p.get("message", "")}


def install(lic):
    """Save a new license if it is validly signed and not older than the current one."""
    p = verify(lic) if isinstance(lic, dict) else None
    if not p:
        return False, "That is not a valid ALIX license file."
    cur = _load()
    if cur and p["issued"] < cur["payload"]["issued"]:
        return False, "That license is older than the one already installed."
    with _lock:
        LICENSE_FILE.write_text(json.dumps(lic, indent=2))
    return True, "License updated."


def _remote_loop(url, hours):
    while True:
        try:
            with urllib.request.urlopen(url, timeout=5) as r:
                install(json.loads(r.read().decode()))
        except Exception:
            pass                                  # offline: keep using the local license
        time.sleep(hours * 3600)


def init(app):
    @app.before_request
    def gate():
        if request.path in OPEN_PATHS or status()["state"] != "locked":
            return None
        if request.path.startswith("/api/"):
            return jsonify(error="license_locked"), 403
        return redirect("/license.html")

    @app.get("/api/license")
    def license_status():
        return jsonify(status())

    @app.post("/api/license")
    def license_upload():
        ok, msg = install(request.get_json(silent=True))
        return jsonify({**status(), "ok": ok, "result": msg}), (200 if ok else 400)

    url = os.environ.get("ALIX_LICENSE_URL")
    if url:
        threading.Thread(target=_remote_loop, args=(url, float(os.environ.get("ALIX_LICENSE_HOURS", 6))),
                         daemon=True).start()
