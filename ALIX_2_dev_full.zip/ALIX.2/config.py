"""ALIX settings — one place, no secrets in code.

Values come from environment variables or a `.env` file next to this file
(copy `.env.example` to `.env`). Nothing else in the project hardcodes them.
The signing key for login cookies is generated on first run and saved to `.env`.
"""
import os, secrets
from pathlib import Path
from paths import DATA_DIR

ROOT = DATA_DIR                    # where the database/.env/backups actually live (see paths.py)
ENV_FILE = ROOT / ".env"


def _read_env_file():
    out = {}
    try:
        for line in ENV_FILE.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                out[k.strip()] = v.strip().strip('"').strip("'")
    except OSError:
        pass
    return out


_file = _read_env_file()


def get(name, default=None):
    return os.environ.get(name, _file.get(name, default))


def _secret_key():
    key = get("ALIX_SECRET_KEY")
    if key:
        return key
    key = secrets.token_hex(32)
    try:                                   # remember it so logins survive a restart
        with open(ENV_FILE, "a") as f:
            f.write(f"\nALIX_SECRET_KEY={key}\n")
        ENV_FILE.chmod(0o600)
    except OSError:
        pass                               # read-only disk: key lasts until restart
    return key


SECRET_KEY = _secret_key()
HOST = get("ALIX_HOST", "0.0.0.0")         # reachable from other devices on the LAN; set ALIX_HOST=127.0.0.1 in .env to restrict to this PC only
PORT = int(get("ALIX_PORT", 5000))
THREADS = int(get("ALIX_THREADS", 4))      # small on purpose: cheap PCs
DATABASE = Path(get("ALIX_DB", ROOT / "alix_pos.db"))
BACKUP_DIR = Path(get("ALIX_BACKUP_DIR", ROOT / "backups"))
BACKUP_KEEP = int(get("ALIX_BACKUP_KEEP", 14))
SESSION_HOURS = int(get("ALIX_SESSION_HOURS", 12))
LOGIN_MAX_FAILS = int(get("ALIX_LOGIN_MAX_FAILS", 5))
LOGIN_LOCK_SECONDS = int(get("ALIX_LOGIN_LOCK_SECONDS", 300))
SEED_DEMO = get("ALIX_SEED_DEMO", "0") == "1"   # demo products/customers, off by default

# Defaults for the very first business profile row (editable later in Settings)
BUSINESS_NAME = get("ALIX_BUSINESS_NAME", "ALIX Power Enterprise")
REGISTER_NAME = get("ALIX_REGISTER_NAME", "Main Counter")
RECEIPT_FOOTER = get("ALIX_RECEIPT_FOOTER", "Thank you for your business!")
