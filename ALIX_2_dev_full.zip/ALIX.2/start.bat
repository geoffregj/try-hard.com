@echo off
REM ALIX launcher for Windows. First run installs what it needs, then starts the server.
cd /d "%~dp0"
if not exist venv python -m venv venv
venv\Scripts\pip install -q -r requirements.txt
venv\Scripts\python server.py
pause
