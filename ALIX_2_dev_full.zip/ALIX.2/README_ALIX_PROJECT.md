# ALIX Power Enterprise — Project README

A POS (point-of-sale) system Geoffrey is building for a friend's business.
Runs on one PC as the server; staff and the friend's customers connect from
any phone/tablet/PC on the same network via a browser.

This file consolidates everything worked out during setup: how to run it,
what actually went wrong along the way (and the fix), how licensing works,
and what's still worth improving before it handles real money.

---

## 1. What this actually is

- **One PC = the server.** It runs `server.py`, which holds the real
  database (`alix_pos.db`) — every product, customer, sale, and setting.
- **Everyone else just uses a browser.** No install needed on their end —
  they go to `http://<server-PC's-IP>:5000` and log in with their own
  account.
- **It doesn't need the internet to run.** Everything is local to that PC
  and the shop's own Wi-Fi/LAN. The only thing that needs internet is
  optional automatic license renewal (`ALIX_LICENSE_URL`) — without that,
  licensing is entirely manual.

## 2. Installing & starting it

```bash
cd ALIX.2
python3 -m venv venv        # first time only
source venv/bin/activate    # every time you open a new terminal
pip install -r requirements.txt
python server.py
```
(Or just run `./start.sh` / double-click `start.bat` — they do the same
three steps automatically.)

You'll see:
```
ALIX running on http://0.0.0.0:5000  (Ctrl+C to stop)
```
Open `http://127.0.0.1:5000` on that same PC, or `http://<its-LAN-IP>:5000`
from any other device on the network.

First run ever: no accounts exist yet, so you land on a setup page and
create the first account — it becomes admin automatically. No default
password is baked in.

## 3. Accounts — who can do what

| Role | Can see/do | Can't do | How they log in |
|---|---|---|---|
| **Admin** | Everything — POS, all products/customers, reports, settings, manage users, licensing | — | Own username/password |
| **Manager** | Same as admin except user management | Can't add/edit/deactivate staff accounts | Own username/password |
| **Cashier** | POS (ring up sales), see products/customers, sees all products by default | Can't edit products, can't open Settings, can't see Reports/Expenses | Own username/password |
| **Customer** (a business hosted on the server) | Only their own products page + their own account page | Can't see POS, other menus, or anyone else's products — redirected if they try the URL directly | Own username/password |

**Adding one:** log in as admin → **Users** page → fill name/username/
password → pick role → Add. Customer accounts get two extra switches,
off by default: **See all products** and **Edit all products** — turn
these on if that account should see/edit everyone's stock instead of just
their own. Changes apply immediately, no re-login needed.

## 4. How the POS actually works

1. **Products** — your inventory: name, price, cost, stock count. Every
   product remembers who added it ("owner"), which is what lets several
   customer-businesses share one server without seeing each other's stock.
2. **POS** — where a sale happens. Tap products to add to cart, pick/add a
   customer, hit Checkout, enter cash received. This prints a receipt,
   saves the sale, and subtracts stock — all in the real database,
   instantly visible to every device.
3. **Customers** — phone, email, loyalty points, running credit balance
   for pay-later customers.
4. **Settings** — the business's own info (name, address, tax number,
   receipt footer). Set once early on.
5. **Inventory** — manual stock adjustments (restocks, damage write-offs),
   logged with who did it, why, and how much.

Everything above writes straight to `alix_pos.db` on the server PC —
there's no "sync later," it's live the moment you save.

## 5. Test data

**Fast (fake demo data):**
```bash
cp .env.example .env
nano .env
```
Add the line `ALIX_SEED_DEMO=1`, save, restart the server. Fills Products/
Customers with sample rows automatically. **Set it back to `0` (or delete
the line) before this becomes the friend's real shop** — don't ship demo
data into production.

**Better (teaches you the real flow):** log in as admin → Products → Add
Product a few times → Customers → Add Customer a few times → ring up a
sale on POS. This is exactly what staff will actually do day to day.

## 6. Letting other devices connect (LAN access)

Already the default — the server binds `0.0.0.0`, so any device on the
same Wi-Fi/LAN reaches it at `http://<server-PC's-LAN-IP>:5000`. Find that
IP with `hostname -I` (Linux) on the server PC.

**Every device must use the exact same address** — `127.0.0.1`,
`localhost`, and the LAN IP are treated as different sites for login
cookies. Pick the LAN IP and have every device use that one.

## 7. Problem we actually hit: firewall blocking the port

**Symptom:** server showed "running on http://0.0.0.0:5000," but no other
device on the network could load it in a browser — just hung or failed to
connect.

**Cause:** Ubuntu's `ufw` firewall was blocking port 5000 by default, even
though the app itself was listening fine.

**Fix:**
```bash
sudo ufw status              # check if it's even active
sudo ufw allow 5000          # open the POS's port
```
Then retry from another device. This was the actual fix that got the
phone browser connecting during setup — if a device on the same network
can't load the page, **check the firewall before anything else.**

## 8. Other problems hit during setup, and the fix

| Symptom | What it actually was | Fix |
|---|---|---|
| `OSError: Address already in use` on `python server.py` | The server was **already running** in another terminal — this isn't an error, it means it's up | Just use the existing one; don't start a second one. If you truly need to restart, find and stop the old process first |
| `python: command not found` in some terminals | The venv wasn't activated in that particular terminal/tab | `source venv/bin/activate` (or `bin/activate` depending on your venv layout) before running anything |
| `ssh: connect to host ... Software caused connection abort` | No SSH server was running on the target machine yet | `sudo apt install openssh-server -y && sudo systemctl enable --now ssh` on the machine being connected *to* |
| Server stopped unexpectedly after closing the phone's SSH app | Running `python server.py` directly inside an interactive SSH session — closing that session kills the process it started | Use the systemd service (§10) so it runs independently of any terminal session |
| License stopped verifying after generating a new signing key | The old `license.json` was signed by a *different* key than the new one just pasted into `licensing.py` — signatures only verify against the exact matching key | Issue a fresh license with `license_tool.py issue` right after swapping keys — see §9 |
| Random Termux startup noise (`lolcat` gem errors, ASCII art banners) | Cosmetic terminal customization (oh-my-zsh-style plugins), unrelated to ALIX entirely | Safe to ignore |

## 9. Licensing — how it works and how to operate it

**The model:** `license.json` is a small signed file stating who it's
for, when it expires, and warning/grace periods. `licensing.py` (shipped
with the app) verifies that signature using a public key baked into the
file. The *private* key that can create valid signatures should live only
on the developer's own machine — **never on the machine running the
POS.** `license_tool.py` is that signing tool.

> **Important correction from earlier in this build:** `license_tool.py`
> was accidentally bundled into the zip sent to the deployed machine. That
> tool (and the `license_private.pem` it creates) should be removed from
> any copy of the project that leaves the developer's own PC — see §11.

**One-time setup (on the developer's PC only):**
```bash
python3 license_tool.py genkey
```
Writes `license_private.pem` (back it up somewhere safe, never share/
commit it) and prints a `PUBLIC_KEY_PEM` block. Paste that block into
`licensing.py`, replacing the existing one, in the copy of the project
that goes to the deployed machine.

**Issue/renew a license:**
```bash
python3 license_tool.py issue --customer "Friend's Shop" --days 30
```
Writes `license.json`. Options: `--warn 7` (days of warning banner before
expiry), `--grace 3` (days it still works after expiry before locking),
`--message "..."` (shown on the lock screen), `--out somefile.json`.

**Lock someone out immediately:**
```bash
python3 license_tool.py suspend --in license.json
```

**Reactivate after testing a lockout:**
```bash
python3 license_tool.py issue --customer "Friend's Shop" --days 30
```

**Check status anytime, no tool needed:**
```
http://<server-IP>:5000/api/license
```
or on the server PC: `cat license.json` and look at `"expires"`.

**States:** `active` → `warning` (inside the warn window) → `grace`
(expired, still working) → `locked` (blocked entirely).

## 10. Auto-start & crash recovery (do this before going live)

Running the server inside a terminal means it dies the moment that
terminal/SSH session closes — a real risk for a live shop. Fix: a systemd
service, already included at `deploy/alix.service`.

```bash
sudo cp deploy/alix.service /etc/systemd/system/alix.service
sudo nano /etc/systemd/system/alix.service   # replace CHANGE_ME (x2) with the real username/path
sudo systemctl daemon-reload
sudo systemctl enable --now alix
sudo systemctl status alix                   # should say "active (running)"
```
After this, the server survives SSH disconnects, terminal closures, and
restarts itself automatically if it ever crashes.

## 11. Improvements worth making before real money is on the line

Roughly in priority order:

1. **Remove `license_tool.py` and `license_private.pem` from anything sent
   to the deployed machine.** Only `license.json` (the result) should ever
   leave the developer's PC. This was a packaging mistake made earlier in
   this build — fix it in the next zip.
2. **Set up the systemd auto-start service (§10)** — the single biggest
   reliability gap right now.
3. **Server-side sale totals.** Currently the till (browser) computes the
   total and the server just records it — a cashier with dev tools open
   could in theory send a fake number. The server should recompute
   price/tax/total itself from product IDs + quantities.
4. **HTTPS**, even self-signed, so passwords don't cross the Wi-Fi in
   plain text. Lower urgency on a trusted private network, worth doing
   before scaling up.
5. **Receipts should show the actual logged-in cashier's name**, not
   always "Admin."
6. **Auto-refresh on shared screens** (e.g. every 30s) so two devices open
   at once don't show stale stock/data until manually reloaded.
7. **Off-machine backups.** `backups/` currently lives on the same PC as
   the live database — if that disk fails, backups die with it. Periodic
   copy to a USB drive, cloud storage, or similar is worth automating.

## 12. Challenges to expect once this is a real, live shop

- **The server PC has to stay on and connected, basically all the time.**
  If it's off, nothing works anywhere, for anyone. Disable sleep/hibernate
  on it; consider a small UPS if power is unreliable.
- **Router restarts can change the server's LAN IP**, breaking every
  device's bookmark. Set a static/reserved IP for that PC in the router
  settings (DHCP reservation) once, permanently.
- **No real "forgot password" flow yet** — only another admin can reset a
  password via Users. Make sure at least two people have admin access.
- **Hardware failure = data loss without a working backup habit.** Test a
  real restore at least once, before it's needed under pressure.
- **Protecting the licensing model has real limits.** Any app running
  entirely on hardware the customer controls, in a readable language like
  Python, can eventually be bypassed by someone technical enough with
  access to that machine (e.g. editing `licensing.py` to always return
  "active"). Technical measures (key separation, compiling the app,
  phone-home checks) raise the bar for casual bypass; they don't make it
  impossible. The strongest long-term protection is usually putting real
  ongoing value on infrastructure *you* control (cloud backup, multi-shop
  dashboard, hosted reporting) rather than relying purely on a local
  license check — plus, since this is for a friend, a plain conversation
  about what a bypassed license means for continued support is not
  nothing.

---

*This file is a summary of decisions made during setup, not a replacement
for `STATUS.md` (the technical build log) or `GET_STARTED.md` (the original
quick-start). Keep all three in the project folder.*
