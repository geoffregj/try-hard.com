# Status

**If you're an AI picking up work on this project: read this whole file
before touching any code.** If you're about to make a change, update the
relevant section below as part of *that same delivery* — not as an
afterthought, not "next time." An out-of-date STATUS.md is worse than no
STATUS.md, because it makes a stale state look current.

**If you're Geoffrey starting a new session (with either AI):** paste this
file in first, before describing what you want done.

---

## Last updated

- **When:** 2026-09-25
- **By:** Claude (Sonnet 5), this thread
- **What changed:** Phases 3/4 (shop data into the database) + customer accounts.
  (1) **Customer accounts:** new role `customer` = a business Geoffrey hosts. It signs in, sees only the
  Products page and its own account, and adds/edits only its own products. (2) **Product ownership:** every
  product has an `owner_id`; the admin sees everyone's with an Owner column + filter. Two per-user switches on
  the Users page, `can_see_all_products` and `can_edit_all_products`, decide who else may see/edit (defaults:
  admin/manager both on, cashier see-only, customer neither). SKU is unique per owner, not global.
  (3) **Everything else is in the database too:** `store.js` makes the pages' localStorage calls read from /
  write to the server (tables `products`, `records`, `kv`), so customers, sales, quotations, suppliers, expenses,
  movements, settings and invoice/receipt counters are stored server-side, backed up, and visible from any
  browser. Cart and held sales stay per-device. (4) **All hardcoded sample data removed** (demo products,
  customers, suppliers, expenses, movements, dashboard numbers, chart values, top sellers, fake phone/email).
  (5) Old databases upgrade in place (`server.migrate()`): users, logins and products kept.
  (6) Bug fixed: stock can no longer go negative on the server; two quick sales no longer double-count.

## Current known-good state

Confidence noted per feature — "confirmed" means there's real output from an
actual run in the sandbox (`tests/test_backend.py` 46/46, `tests/test_products.py` 77/77,
`tests/test_browser.py` 67/67 in real Chromium 141), not just that the code looks right on review.
Nothing here has been run on Geoffrey's own PC yet.

| Feature | Status | Evidence |
|---|---|---|
| First-run admin setup page, no default password | confirmed | browser test: fresh DB → setup.html → dashboard |
| Login / logout / session | confirmed | browser + backend tests; live waitress server via curl |
| Old `Admin`/`admin123` login rejected | confirmed | browser test |
| Weak passwords refused (`admin123`, <8 chars) | confirmed | backend + browser tests |
| Login lock-out (5 fails → 429) | confirmed | backend test (limit set to 3 in test) |
| Roles: page gating (cashier can't open settings/users) | confirmed | browser test, server redirects |
| Roles: API gating (401 logged out, 403 wrong role) | confirmed | backend test |
| Users page (add, role change, deactivate, reset pw, last-admin guard) | confirmed (add/duplicate via browser; role/deactivate/reset via API) | tests; the role dropdown and buttons on the page were not clicked in a browser |
| Change own password (account.html) | confirmed | browser test |
| Deactivated user's live session dies immediately | confirmed | backend test |
| Product edit blocked for cashier, allowed for manager | confirmed **UI-level only** | browser test — see "Standing risks": data is still in localStorage |
| Receipt preview shows title/logo once | confirmed | browser test + screenshot |
| Printed receipt / printed quotation duplicate fix | untested | code change reviewed, print windows never opened in a browser |
| All 15 pages load with no JS errors | confirmed | browser test |
| waitress server, idle memory | confirmed | ~44 MB RSS, 6 threads (python 3.12, Linux). **Idle only — never measured under load** |
| Daily backup + `python3 backup.py` | confirmed | file created and readable, users table inside |
| Licence gate with the new login | untested for locked/expired/grace states | only the *active* state was exercised (licence valid until 2026-10-24) |
| `start.bat` / Windows | untested | never run |
| `deploy/alix.service` (systemd) | untested | never run |
| LAN mode (now the default: binds `0.0.0.0`) | confirmed | server logs "Running on all addresses (0.0.0.0)"; reachable via both 127.0.0.1 and the machine's LAN IP |
| Python 3.10 / 3.11, Firefox, Safari | untested | only 3.12 + Chromium |
| Customer accounts: only Products + own account, pages/APIs fenced | confirmed | backend + browser tests |
| Product ownership, per-owner SKUs, admin sees all with Owner column/filter | confirmed | backend + browser tests |
| Permission switches (see all / edit all) on Users page, take effect immediately | confirmed | backend + browser tests |
| Products, sales, customers, settings, counters stored in the DB; survive restart; visible in a brand-new browser profile | confirmed | browser test |
| Upgrade of a v2 database in place (users, logins, products kept) | confirmed | backend test built from the real v2 schema |
| No hardcoded sample data anywhere | confirmed | browser test on a fresh install |
| Cashier name on receipts | not done | still comes from Settings ("Admin"), not the logged-in user |

## In progress / do not touch

- Shop data lives in the DB as **JSON documents** (`records`, `kv`) that the existing pages read through `store.js`,
  not as the relational tables in `schema.sql` (`sales`, `customers`, `expenses`, ...). Those tables and their
  endpoints (`/api/sales`, `/api/customers`, `/api/invoices`, `/api/quotations`, `/api/expenses`, ...) are **unused
  by the pages**. Don't mix the two models; the next phase is to pick one (see decisions).
- `licensing.py`, `license.js`, `license.html`, `license.json`: **do not edit.**
  They belong to whoever sells the subscription.

## Open decisions waiting on Geoffrey

- **Sales totals are still computed in the browser.** The server stores what the till sends. A cashier who
  can use the console could send a false total. Fix = server-side sales (POS sends product ids + quantities;
  server prices and numbers them). Recommended next.
- **Two data models** (see "In progress"): keep JSON documents, or migrate each page to the relational tables.

- **Next phase:** server-side sales first (POS sends product ids + quantities;
  server sets prices/VAT/totals/receipt numbers), then products/customers/
  settings to the DB. Recommended order — say if you want a different one.
- Old localStorage data in a browser is **ignored**, not imported (Geoffrey confirmed it was test data).
- **Licensing:** is this project yours to change, or your friend's product?
  If it's your friend's, confirm they meant to give you `ALIX_owner_tools.zip`
  (it contains the licence signing key) — see Standing risks.
- **Replace `prompt()`/`confirm()` dialogs** (POS "Amount Received", product
  add/edit) with proper forms? They work but are clumsy and hard to test.

## Standing risks (don't re-litigate these without new evidence)

- **Pages load data once.** Two devices open at the same time see each other's changes after a reload. Stock
  changes are sent as deltas (safe); other edits are last-write-wins per record.
- **Role limits:** products are enforced on the server per owner and per permission switch. The other collections
  are enforced per role (cashier: sales/customers/quotations; manager: expenses/suppliers/movements/settings).
  Content inside a record (e.g. a sale's total) is not validated yet.
- **`store.js` uses one synchronous request at page load** so the old pages keep working unchanged. Fine on a
  LAN / same PC; would feel slow over a poor internet link.
- **Every browser must use the same address** for the login cookie (127.0.0.1 vs localhost vs the LAN IP are different sites — since the server now listens on 0.0.0.0, pick one address per device and stick to it).
- **The old credentials were shown in chat:** `Admin`/`admin123` and
  `ALIX2026`. They no longer work in this version, but any older copy of the
  project (the original ccc.zip) still accepts them.
- **The licence signing key (`license_private.pem`) was delivered inside
  `ALIX_owner_tools.zip`.** It was deliberately not copied into this repo and
  is in `.gitignore`. Whoever holds it can issue licences; if the subscription
  is the friend's revenue, the friend decides whether to rotate the key.
- **No HTTPS, and it now listens on `0.0.0.0` by default** — reachable from any device on the same network,
  not just this PC. Fine on a private shop network; never expose the port to the internet or a router's port
  forwarding. Passwords cross the LAN in clear text. Set `ALIX_HOST=127.0.0.1` in `.env` to restrict it back
  to this PC only.
- **`.env` contains the key that signs login cookies.** Anyone who can read it
  can forge a login. Don't share it or commit it (already in `.gitignore`).
- **Login lock-out is in memory:** it resets when the server restarts, and it
  keys on IP + username.
