# ALIX Power Enterprise POS

Point-of-sale for a small shop (also lets you host customer accounts that manage their own products): sales, receipts, invoices, quotations, products, stock, customers, expenses, reports.
Runs on one cheap PC (about 45 MB of RAM when idle). Python + Flask + SQLite, no other services.

## Run it

- **Linux/macOS:** `./start.sh`   **Windows:** double-click `start.bat`
- It listens on `0.0.0.0` by default, so it's reachable from any device on the shop Wi-Fi at `http://<this PC's IP>:5000`. On this PC itself, open <http://127.0.0.1:5000>. **First run** shows a page to create the admin account — there is no default password.
- Stop with Ctrl+C.
- Find this PC's IP with `hostname -I` (Linux) or `ipconfig` (Windows). To restrict it to this PC only, set `ALIX_HOST=127.0.0.1` in `.env`.

## Who can do what

| Role | Can |
|---|---|
| Customer | A business you host: sign in, add and edit **only its own products** (Products page + own account) |
| Cashier | Sell, print receipts/invoices, view products, add customers |
| Manager | + change products, stock, expenses, suppliers, reports, settings |
| Admin | + add/deactivate users, reset passwords, see and edit **every** product (Users page) |

On the Users page two ticks per person — **See all products** / **Edit all products** — decide whose products they can see or change. Defaults: admin and manager both, cashier see-only, customer neither.

Change who reaches what in `auth.py` (`PAGE_MIN_ROLE`, `API_RULES`). Everyone can change their own password (click their name).

## Settings live in `.env`, not in code

Copy `.env.example` to `.env`. Everything is optional; the login-cookie key is generated automatically on first run.
Never share or commit `.env`, `*.db` or `backups/`.

## Hosting on a cheap PC

1. Install Python 3.10+, copy this folder, run `start.sh` / `start.bat` once.
2. **Other devices on the shop Wi-Fi:** already works out of the box — browse to `http://<that PC's IP>:5000`.
   There is no HTTPS, so keep it on the shop's private network — never expose the port to the internet or a router's port forwarding.
3. **Start on boot:** Linux → `deploy/alix.service`. Windows → put a shortcut to `start.bat` in `shell:startup`.
4. **Backups:** `backups/` gets a copy of the database at every start and every 24 h (newest 14 kept).
   Copy that folder to a USB stick regularly — a backup on the same disk won't survive a dead disk.
   Manual backup any time: `python3 backup.py`.

## Files

| File | What it is |
|---|---|
| `server.py` | Web server + API (Flask, served by waitress) |
| `auth.py` | Login, roles, who may open which page/API |
| `config.py` | Reads `.env` / environment variables |
| `licensing.py`, `license.*` | Subscription licence check (do not edit; `license.json` is signed) |
| `backup.py` | SQLite backups |
| `schema.sql` | Database tables |
| `app.js` + page `.js/.html` | The pages |
| `store.js` | Makes the pages read/write the shop's data in the database instead of the browser |
| `auth.js` | Shows the logged-in user, Logout, hides menu items the role can't use |

`STATUS.md` = current state and next steps. `CHANGELOG.md` = what changed and why.
