#!/usr/bin/env bash
# ALIX launcher for Linux/macOS. First run installs what it needs (~15 MB), then starts the server.
cd "$(dirname "$0")"
[ -d venv ] || python3 -m venv venv
./venv/bin/pip install -q -r requirements.txt
exec ./venv/bin/python server.py
