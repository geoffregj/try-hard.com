"""Builds a single executable for THIS operating system.

Run it on the machine you actually want the .exe for — a Windows build
has to be built ON Windows (same for Mac/Linux). PyInstaller doesn't
cross-compile: building on Linux gives you a Linux binary, not a .exe.

Usage:
    pip install pyinstaller
    python build_exe.py

Output lands in dist/ALIX/ (folder build — faster startup, easier to
inspect than a single-file build, and matches the "everything writable
sits next to the exe" model in paths.py).
"""
import glob, os, subprocess, sys

SEP = ";" if os.name == "nt" else ":"   # PyInstaller's --add-data separator differs by OS
ASSET_PATTERNS = ["*.html", "*.js", "*.css", "*.jpg", "*.png", "schema.sql", ".env.example"]

datas = []
for pattern in ASSET_PATTERNS:
    for path in glob.glob(pattern):
        datas += ["--add-data", f"{path}{SEP}."]

cmd = [
    sys.executable, "-m", "PyInstaller",
    "--name", "ALIX",
    "--onedir",            # NOT --onefile: keeps startup fast and _MEIPASS extraction simple
    "--console",           # keep the terminal window so you can see "ALIX running on http://..." and Ctrl+C works
    "--clean",
    "--noconfirm",
    *datas,
    "server.py",
]

print("Running:", " ".join(cmd))
subprocess.run(cmd, check=True)
print("\nDone. The runnable app is in dist/ALIX/ — copy that whole folder")
print("to wherever it'll live permanently; alix_pos.db, license.json, .env")
print("and backups/ will all appear next to ALIX.exe inside it on first run.")
