"""SQLite backups — safe to run while the server is running.

    python3 backup.py          # make one backup now
Also started automatically by server.py (once at startup, then every 24h).
Keeps the newest ALIX_BACKUP_KEEP files (default 14). Copy the backups/ folder
to a USB stick now and then: a backup on the same disk won't survive a dead disk.
"""
import sqlite3, threading, time
from datetime import datetime
import config


def make_backup():
    if not config.DATABASE.exists():
        return None
    config.BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    dest = config.BACKUP_DIR / f"alix_pos_{datetime.now():%Y%m%d_%H%M%S}.db"
    src = sqlite3.connect(config.DATABASE)
    dst = sqlite3.connect(dest)
    with dst:
        src.backup(dst)                      # consistent snapshot even mid-write
    src.close(); dst.close()
    for old in sorted(config.BACKUP_DIR.glob("alix_pos_*.db"))[:-config.BACKUP_KEEP]:
        old.unlink()
    return dest


def start_daily():
    def loop():
        while True:
            try:
                make_backup()
            except Exception as e:           # never let a backup problem stop the shop
                print("backup failed:", e)
            time.sleep(24 * 3600)
    threading.Thread(target=loop, daemon=True, name="alix-backup").start()


if __name__ == "__main__":
    print("Backup written:", make_backup())
